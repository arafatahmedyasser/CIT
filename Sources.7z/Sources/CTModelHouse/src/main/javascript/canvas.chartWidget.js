/**************************************************************************

 * These materials are confidential and proprietary to Intellect Design Arena Limited
 
 *  and no part of these materials should be reproduced, 

 * published, transmitted or distributed  in any form or by any means, 

 * electronic, mechanical, photocopying, recording or otherwise, or 

 * stored in any information storage or retrieval system of any nature 

 * nor should the materials be disclosed to third parties or used in any 

 * other manner for which this is not authorized, without the prior express 

 * written authorization of Intellect Design Arena Limited.

 *

 * Copyright 2010. Intellect Design Arena Limited. All rights reserved.

 *************************************************************************/

cbx.ns("canvas");
canvas.multiSeriesChartWidget = Ext.extend(iportal.Widget, {
  constructor: function(config){
		canvas.multiSeriesChartWidget.superclass.constructor.call(this, config);
		cbx.apply(this,config);
	this.mv = new iportal.view.MultiView({
			id:'CT_MULTI_CHART_WGT'
		});
    }
});

canvas.singleSeriesChartWidget = Ext.extend(iportal.Widget, {
	  constructor: function(config){
			canvas.singleSeriesChartWidget.superclass.constructor.call(this, config);
			cbx.apply(this,config);
		this.mv = new iportal.view.MultiView({
				id:'CT_SINGLE_CHART_WGT'
			});
	    }
	});

canvas.t7ChartWidget = Ext.extend(iportal.Widget, {
	  constructor: function(config){
			canvas.t7ChartWidget.superclass.constructor.call(this, config);
			cbx.apply(this,config);
		this.mv = new iportal.view.MultiView({
				id:'CT_T7_CHART_WGT'
			});
	    }
	});



canvas.pieChartWidget = Ext.extend(iportal.Widget, {
	  constructor: function(config){
			canvas.pieChartWidget.superclass.constructor.call(this, config);
			cbx.apply(this,config);
		this.mv = new iportal.view.MultiView({
				id:'CT_PIE_CHART_WGT'
			});
	    }
	});

canvas.gaugeChartWidget = Ext.extend(iportal.Widget, {
	  constructor: function(config){
			canvas.gaugeChartWidget.superclass.constructor.call(this, config);
			cbx.apply(this,config);
		this.mv = new iportal.view.MultiView({
				id:'CT_GAUGE_CHART_WGT'
			});
	    }
	});

canvas.dualAxisChartWidget = Ext.extend(iportal.Widget, {
	  constructor: function(config){
			canvas.dualAxisChartWidget.superclass.constructor.call(this, config);
			cbx.apply(this,config);
		this.mv = new iportal.view.MultiView({
				id:'CT_DUAL_CHART_WGT'
			});
	    }
	});
canvas.pyramidChartWidget = Ext.extend(iportal.Widget, {
	  constructor: function(config){
		  canvas.pyramidChartWidget.superclass.constructor.call(this, config);
			cbx.apply(this,config);
		this.mv = new iportal.view.MultiView({
				id:'REC_SUMM_PYRMD_WGT'
			});
	    }
	});
canvas.dailyTrendLineChartWidget = Ext.extend(iportal.Widget, {
	  constructor: function(config){
		  canvas.dailyTrendLineChartWidget.superclass.constructor.call(this, config);
			cbx.apply(this,config);
		this.mv = new iportal.view.MultiView({
				id:'DAILYTREND_CHART_WGT'
			});
	    }
	});
canvas.dailySpendSumChartWidget = Ext.extend(iportal.Widget, {
	  constructor: function(config){
		  canvas.dailySpendSumChartWidget.superclass.constructor.call(this, config);
			cbx.apply(this,config);
		this.mv = new iportal.view.MultiView({
				id:'DAILY_SPEND_SUMM_WGT'
			});
	    }
	});
canvas.recDueDateTypeChartWidget = Ext.extend(iportal.Widget, {
	  constructor: function(config){
		  canvas.recDueDateTypeChartWidget.superclass.constructor.call(this, config);
			cbx.apply(this,config);
		this.mv = new iportal.view.MultiView({
				id:'REC_DUEDATE_CHART_WGT'
			});
	    }
	});
canvas.DailySummWidget = Ext.extend(iportal.Widget, {
	  constructor: function(config){
			canvas.DailySummWidget.superclass.constructor.call(this, config);
			cbx.apply(this,config);
		this.mv = new iportal.view.MultiView({
				id:'DAILYSUMM_WGT'
			});
	    }
	});
