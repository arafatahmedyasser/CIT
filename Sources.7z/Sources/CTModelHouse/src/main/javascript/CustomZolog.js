// Sample Test data. This block of codes have to be write by the app(product)team to register the custom space in MenuPanel.

Ext.namespace('iportal.workspace');

CMSHR.registerHandler(function() {
	var  zolog =  new Ext.Panel({
		cls:'zologCenter',
		items : []
	});
	
	CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getMergedArray(["ZOLOG_SEARCH"]),function(){
		
		 zolog.add(new cbx.zologsearch.zologSearchBar().getSearchComp())
		 ;
	});
	
	return zolog; 	
});