/**************************************************************************

 * These materials are confidential and proprietary to Intellect Design Arena Limited
 
 *  and no part of these materials should be reproduced, 

 * published, transmitted or distributed  in any form or by any means, 

 * electronic, mechanical, photocopying, recording or otherwise, or 

 * stored in any information storage or retrieval system of any nature 

 * nor should the materials be disclosed to third parties or used in any 

 * other manner for which this is not authorized, without the prior express 

 * written authorization of Intellect Design Arena Limited.

 *

 * Copyright 2010. Intellect Design Arena Limited. All rights reserved.

 *************************************************************************/

/**
 * 
=======================================================================================================
CHANGE CODE     		AUTHOR      		DESCRIPTION			 								DATE
CH002_ONDEMAND_JSLOAD	Murali R			CellClickHandler register issue fix					04/07/2012
====================================================================================================
 */


// Define the namespace for the widget
Ext.ns("canvas.widget");

/**
 * Intended to handle all context based actions related to Instruction List View/ Cash concentration Inquiry view	
 * @class canvas.widget.listCellClickHandler
 * @extends iportal.Widget
 */
canvas.widget.listCellClickHandler=Ext.extend(Ext.util.Observable, {
	// Intended to hold resource bundle object
	rb:null,
	/* This constructor will be called when you do
	* new canvas.widget.listCellClickHandler();
	*/
	constructor: function(config){
		canvas.widget.listCellClickHandler.superclass.constructor.call(this, config);
		Ext.apply(this,config);
		this.rb =CRB.getBundle("COMMON"); 
    },
    /**
	 * Setter API to set MultiView object.
	 */
	setMultiView : function (ob){
		this.mv = ob;
	},
	/**
	 *Setter API to set View definition object.
	 */ 
	setVdf : function (ob){ 
		this.vdf = ob;
	},

    /**
    * This will be called as and when user clicks on CONTEXT column in Instruction List View/ Cash concentration Inquiry view.
    * Intended to create context menu items and display. 
    */
    generateContext:function(domid,colId,colVal,record,evt){
    	CBXCONTEXTMENU.getContextMenu(this.mv, record, evt);
    },
    	  
    /** DON'T DELETE this API
    * This will be called as and when user clicks any column apart from CONTEXT, in InterCompany Loan Inquiry/List View
    * Intended to check Column Id and do necessary.
    */

	processCellClick : function(colId,colVal,scope,record){
    	cbx.CommManager.raiseEvent('showProperty',record.json);
    }  
    
	    
});
/*  Framework Enhancement - CH002_ONDEMAND_JSLOAD - Starts */
ICCHF.registerHandler('CT_PAGING_VIEW', canvas.widget.listCellClickHandler);
/*  Framework Enhancement - CH002_ONDEMAND_JSLOAD - End */