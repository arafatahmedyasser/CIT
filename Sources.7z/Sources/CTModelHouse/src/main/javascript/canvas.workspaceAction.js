

var onWorkspaceSwitch = function(data){/*
				var common = CRB.getBundle("common");
				 var confWin = new iportal.Dialog({
						dialogType : 'MESSAGE',
						bundleKey: "common",
						scope : this,
						title: common['LBL_WORKSPACE_SWITCH'],
						message : [data.CURRENT_WORKSPACE_ID,data.PREV_WORKSPACE_ID],
						okHandler : function(){
							confWin.close();					
						}
				});
				confWin.show();*/
			};
	
	
	cbx.CommManager.registerHandler('onWorkspaceSwitch', 'canvas.workspaceAction', this, this.onWorkspaceSwitch);
