

CLHFR.registerContent("jqui","header","<h1>Hello World</h1><button>Click Me!</button>");

CLHFR.registerContent("jqui","footer","<h1>Footer</h1><button>Canvas Tech</button>");