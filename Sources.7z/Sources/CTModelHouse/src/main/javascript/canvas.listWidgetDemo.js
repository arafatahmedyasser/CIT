/**************************************************************************

 * These materials are confidential and proprietary to Intellect Design Arena Limited
 
 *  and no part of these materials should be reproduced, 

 * published, transmitted or distributed  in any form or by any means, 

 * electronic, mechanical, photocopying, recording or otherwise, or 

 * stored in any information storage or retrieval system of any nature 

 * nor should the materials be disclosed to third parties or used in any 

 * other manner for which this is not authorized, without the prior express 

 * written authorization of Intellect Design Arena Limited.

 * Copyright 2010. Intellect Design Arena Limited. All rights reserved.

 *************************************************************************/

// Define the namespace for the widget

cbx.ns("canvas");



/**

 * 

 * @class iportal.widget.RULWidget

 * @extends iportal.Widget

 */

canvas.listWidget = Ext.extend(iportal.Widget, {

    /* This constructor will be called when you do

	* new iportal.widget.AccountPropertyWidget();

	*/

	constructor: function(config){

		this.svcch = null;//System view cell click handler

		// Call the superclass constructor, so that all widget's common methods will be available

		// for this widget

		canvas.listWidget.superclass.constructor.call(this, config);

		cbx.apply(this,config);

		//Gagan: initializing MuliView Object to mv
		
		var that = this;
		this.mv = new iportal.view.MultiView({

			id:'CT_WIDGET_ONE',
			listeners : {
				'cellclick' 	: that.cellHandler,
				}
		});
    },
	cellHandler : function (colId, colVal, record){		
		CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getMergedArray(["FORM_CONTAINER"]),function(){
			//CBXFORMCONTAINER.getWindow("CANVAS_FORM_CUST_PREF");
			
			CBXFORMCONTAINER.getWindow("CANVAS_FORM_CNTNR_MANL_TXN");
			//alert("VSDLVKS");
			
		});
		
	}
});


cbx.ns('ct.listeners');
ct.listeners.manualTxnForm = Ext.extend(Ext.util.Observable, {
	/**
	 * 
	 */
	constructor : function(config) {
		this.fm = config.fm;
		ct.listeners.manualTxnForm.superclass.constructor.call(this, config);
	},

	registerHandlers : function() {}
});

CFLR.registerListener("FORM_MANUAL_TXN", ct.listeners.manualTxnForm);