cbx.ns("canvas.view");

canvas.view.appRegisterMap = {/*
		
		"CT_MULTI_CHART_WGT" : function(){
			return new canvas.multiSeriesChartWidget();
		},"CT_SINGLE_CHART_WGT" : function(){
			return new canvas.singleSeriesChartWidget();
		},"CT_PIE_CHART_WGT" : function(){
			return new canvas.pieChartWidget();
		},"CT_GAUGE_CHART_WGT" : function(){
			return new canvas.gaugeChartWidget();
		},"CT_DUAL_CHART_WGT" : function(){
			return new canvas.dualAxisChartWidget();
		},
	"CT_LIST_WGT" : function(){
		return new canvas.listWidget();
	},
	"CT_CLASSIC_GRID_WGT" : function(){
		return new canvas.classicGridWidget();
	},
	"CT_PAGING_WGT" : function(){
		return new canvas.pagingWidget();
	},
	"CT_CALENDER_WGT": function(){
		return new canvas.calenderWidget();
	},
	"CT_PROPERTY_WGT" : function(){
		return new canvas.propertyWidget();
	},
	"CT_ADS_WGT" : function(){
		return new canvas.adsWidget();
	},
	"WGT_STRUC_LIST" : function(){
		return new canvas.structgroupWidget();
	},
	"CT_IFRAME_WGT" : function(){
		return new canvas.iframeWidget();
	},
	"CT_EMTPY_WGT" : function(){
		return new canvas.emptyWidget();
	},
	"CT_MAP_WGT": function(){
		return new canvas.mapWidget();
	},
	"CT_ADVGROUP_WGT":function(){
		return new canvas.advanceGroupWidget();
	},
	"CT_TREE_WGT": function(){
		return new canvas.treeWidget();
	},
	"CT_ORG_WGT": function(){
		return new canvas.orgWidget();
	},
	"CT_APP_WGT":function(){
		return new canvas.appWidget();
	},
	"CT_MULTI_WGT_EXPLORER" : function(){
		var config={
				compId:'CT_MULTI_WGT_EXPLORER'
					};
		return new iportal.widget.MultiWidget(config);
	},
	"CT_MULTI_WGT_CARD" : function(){
		var config={
				compId:'CT_MULTI_WGT_CARD'
					};
		return new iportal.widget.MultiWidget(config);
	},
	"CT_MULTI_WGT_INDEXED" : function(){
		var config={
				compId:'CT_MULTI_WGT_INDEXED'
					};
		return new iportal.widget.MultiWidget(config);
	},
	"CT_MULTI_WGT_TAB" : function(){
		var config={
				compId:'CT_MULTI_WGT_TAB'
					};
		return new iportal.widget.MultiWidget(config);
	},
	"CT_MULTI_WGT_SWITCH" : function(){
		var config={
				compId:'CT_MULTI_WGT_SWITCH'
					};
		return new iportal.widget.MultiWidget(config);
	},
	"CT_FORM_WGT":function(){
		return new canvas.formWidget();
	},
	"WGT_ALERT_NOT_MSG_MULTI":function(){
		var config={
					compId:'WGT_ALERT_NOT_MSG_MULTI'
						};
			return new iportal.widget.MultiWidget(config);
	},
	"SMA_MULTI":function(){
		var config={
					compId:'SMA_MULTI'
						};
			return new iportal.widget.MultiWidget(config);
	},
	"WGT_ACTIVITY_SUMMARY":function(){
		var config={
					compId:'WGT_ACTIVITY_SUMMARY'
						};
			return new iportal.widget.MultiWidget(config);
	},
	"REC_MULTI":function(){
		var config={
					compId:'REC_MULTI'
						};
			return new iportal.widget.MultiWidget(config);
	},
	"WGT_ALERT":function(){
		var config={
					compId:'WGT_ALERT'
						};
		return new canvas.widget.AlertListWidget();
	},
	"WGT_NOTIFY":function(){
		var config={
					compId:'WGT_NOTIFY'
						};
		return new canvas.widget.NotificationListWidget();
	},
	"WGT_DEPOSIT_SUMMARY":function(){
		return new canvas.depositSummaryWidget();
	},
	"WGT_TRAN_SUMMARY":function(){
		return new canvas.transactionSummaryWidget();
	},
	"REC_SUMM_PYRMD_WGT":function(){
		return new canvas.pyramidChartWidget();
	},
	"DAILYTREND_CHART_WGT":function(){
		return new canvas.dailyTrendLineChartWidget();
	},
	"DAILY_SPEND_SUMM_WGT":function(){
		return new canvas.dailySpendSumChartWidget();
	},
	"REC_DUEDATE_CHART_WGT":function(){
		return new canvas.recDueDateTypeChartWidget();
	},
	"CT_LOAN_SUMMARY_WGT":function(){
		return new canvas.loanSummaryWidget();
	},
	"CT_ACC_SUMMARY_WGT":function(){
		return new canvas.accountSummaryWidget();
	},
	"REC_DUEDATE_CHART_WGT":function(){
		return new canvas.recDueDateTypeChartWidget();
	},
	"WGT_CFFC":function(){
		return new canvas.CFFCSummaryWidget();
	},
	"REC_SUMM_PYRMD_WGT":function(){
		return new canvas.pyramidChartWidget();
	},
	"DAILYTREND_CHART_WGT":function(){
		return new canvas.dailyTrendLineChartWidget();
	},
	"REC_LIST_WGT":function(){
		return new canvas.RecListWidget();
	},"DAILYSUMM_WGT":function(){
		return new canvas.DailySummWidget();
	},	
	"WGT_READY":function(){
		return new canvas.processedWidget();
	},
	"WGT_ALERT":function(){
		return new canvas.widget.AlertListWidget();
	},	
	"WGT_NOTIFY":function(){
		return new canvas.widget.NotificationListWidget();
	},
	"WGT_REJECTED":function(){
		return new canvas.rejectedWidget();
	},
	"WGT_PENDING":function(){
		return new canvas.pendingWidget();
	},"WGT_DRAFT":function(){
		return new canvas.draftWidget();
	}	
	
	,
	"ACC_SUMMARY_WGT":function(){
		return new canvas.accountSummaryClassicWidget();
	},
	"CT_CARD_SUMMARY_WGT":function(){
		return new canvas.cardSummaryWidget();
	},"INVEST_SUMMARY_WGT":function(){
		return new canvas.investmentSummaryWidget();
	}
*/
"CT_ACC_SUMMARY_WGT":function(){
	return new canvas.accountSummaryWidget();
}
};
CWEH.registerHandler('WGT_TRAN_SUMMARY',CWEC.CELL_CLICK,function(record){
	LOGGER.info('fired dbl click');
});
CWEH.registerHandler('WGT_TRAN_SUMMARY',CWEC.SINGLE_CLICK,function(record){
	LOGGER.info('fired single');
});
CWEH.registerHandler('CT_COMM_MGR_TEST_WGT',CWEC.FORM_BEFORE_INITIALIZE,function(fm){
	LOGGER.info('fired form before init');
});
CWEH.registerHandler('CT_COMM_MGR_TEST_WGT',CWEC.FORM_INITIALIZE,function(fm){
	LOGGER.info('fired form init');
});



CWEH.registerHandler('CT_ACC_SUMMARY_WGT1','beforeDataLoad',function(widgetId,paramss,netState,callback){
	var params={
	
	"response": {
	    "data": {
	        "ALL_RECORDS": [
	             {
	                "UNCLEARED_FUND": "10.0",
	                "ACCOUNT_NO": "1105926174623",
	                "CURRENCY": "USD",
	                "TOTAL_COUNT": "5",
	                "ACCOUNT_NAME": "TWO",
	                "OVER_DRAFT_LMT": "0.0",
	                "AVAI_BALANCE": "571140.12",
	                "STATUS": "ACTIVE",
	                ACCOUNT_TYPE: "VIKI ACCOUNT"
	            },
	            {
	                "UNCLEARED_FUND": "10.0",
	                "ACCOUNT_NO": "1105926174662",
	                "CURRENCY": "USD",
	                "TOTAL_COUNT": "5",
	                "ACCOUNT_NAME": "ONE",
	                "OVER_DRAFT_LMT": "0.0",
	                "AVAI_BALANCE": "571140.12",
	                "STATUS": "ACTIVE",
	                ACCOUNT_TYPE: "VIKI ACCOUNT1"
	            }
	        ],
	        'ADDITIONAL_DATA':{
	        	'MODIFIED_COLUMN_NAMES':{
	        		CURRENCY: "Currency"
	        	}
	        }
	     },
		 //syncMode:false,
		cancelLoad:false,
		dataMerge:true,
		uniqueColumn: "ACCOUNT_NO"
		
		}
	};
  if(paramss.start==5 || paramss.start==10){
     params.response.cancelLoad=false;
	params.response.dataMerge=true;
	params.response.data.ALL_RECORDS.push({
	                 "UNCLEARED_FUND": "10.0",
	                 "ACCOUNT_NO": "007",
	                 "CURRENCY": "USD",
	                 "TOTAL_COUNT": "5",
	                 "ACCOUNT_NAME": "ONE",
	                "OVER_DRAFT_LMT": "0.0",
	                 "AVAI_BALANCE": "571140.12",
	                 "STATUS": "ACTIVE",
	                 ACCOUNT_TYPE: "VIKI ACCOUNT1"
	            });
	 }
	
	callback.apply(this,[params]);
});


CWEH.registerHandler('CT_ACC_SUMMARY_WGT','afterDataLoad',function(widgetId,params,netState,response){
	LOGGER.info('response' ,response)
});

CWEH.registerHandler('CT_ACC_SUMMARY_WGT',CWEC.SINGLE_CLICK,function(record,columnid){
	LOGGER.info('fired single click',[record,columnid]);
});
CWEH.registerHandler('CT_ACC_SUMMARY_WGT',CWEC.CELL_DATA_CHANGE,function(record,columnid,val){
	LOGGER.info('fired CELL_DATA_CHANGE click',[record,columnid,val]);
});
CWEH.registerHandler('CT_ACC_SUMMARY_WGT',CWEC.AFTER_TEMPLATE_LOAD,function(elem){
	LOGGER.info('fired AFTER_TEMPLATE_LOAD click',[elem]);
});

CWEH.registerHandler('CT_ACC_SUMMARY_WGT',CWEC.BEFORE_TEMPLATE_LOAD,function(elem){
	LOGGER.info('fired BEFORE_TEMPLATE_LOAD click',[elem]);
	elem.test="ss";
});



CWEH.registerHandler('WGT_STRUC_LIST','beforeDataLoad',function(widgetId,paramss,netState,callback){
	var params={
	
	"response": {
	    "data": {
	        "ALL_RECORDS": [
	             {
	               "AMOUNT": "25000.0",
					"CONTRA_ACC_CCY": "USD",
					"CONTRA_ACC_NO": "4324617483242",
					"CONTROL_ACC_CCY": "USD",
					"CONTROL_ACC_NO": "1000125623751",
					"EXEC_FREQ": "Daily",
					"INSTR_END_DATE": "24/01/2015",
					"INSTR_ID": "1.0",
					"INSTR_START_DATE": "25/01/2014",
					"NEXT_EXEC_DATE": "04/10/2014",
					"STATUS": "Active",
					"STR_ID": "10532.0",
					"STR_NAME": "GSD A CORP",
					"STR_TYPE": "Cross Currency Sweep",
					"SWEEP_TYPE": "Range Balance"
	            },
	            {
	                "AMOUNT": "25000.0",
					"CONTRA_ACC_CCY": "USD",
					"CONTRA_ACC_NO": "7397862340148",
					"CONTROL_ACC_CCY": "USD",
					"CONTROL_ACC_NO": "103456623751",
					"EXEC_FREQ": "Daily",
					"INSTR_END_DATE": "24/01/2015",
					"INSTR_ID": "1.0",
					"INSTR_START_DATE": "25/01/2014",
					"NEXT_EXEC_DATE": "04/10/2014",
					"STATUS": "Active",
					"STR_ID": "10532.0",
					"STR_NAME": "GSD A CORP",
					"STR_TYPE": "Cross Border Sweep",
					"SWEEP_TYPE": "Range Balance"
	            }
	        ],
	        'ADDITIONAL_DATA':{
	        	'LAST_UPDATED_DT_TM': "16/12/2015 16:20:36"
	        }
	     },
		 //syncMode:false,
		cancelLoad:false,
		dataMerge:true,
		uniqueColumn: "CONTRA_ACC_NO"
		
		}
	};

	
	callback.apply(this,[params]);
});


CWEH.registerHandler('WGT_STRUC_LIST','afterDataLoad',function(widgetId,params,netState,response){
	LOGGER.info('response' ,response)
});