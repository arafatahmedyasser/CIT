/**************************************************************************

 * These materials are confidential and proprietary to Intellect Design Arena Limited
 
 *  and no part of these materials should be reproduced, 

 * published, transmitted or distributed  in any form or by any means, 

 * electronic, mechanical, photocopying, recording or otherwise, or 

 * stored in any information storage or retrieval system of any nature 

 * nor should the materials be disclosed to third parties or used in any 

 * other manner for which this is not authorized, without the prior express 

 * written authorization of Intellect Design Arena Limited.

 *

 * Copyright 2010. Intellect Design Arena Limited. All rights reserved.

 *************************************************************************/

// Define the namespace for the widget

cbx.ns("canvas");



/**

 * 

 * @class iportal.widget.RULWidget

 * @extends iportal.Widget

 */

canvas.accountSummaryClassicWidget = Ext.extend(iportal.Widget, {

    /* This constructor will be called when you do

	* new iportal.widget.AccountPropertyWidget();

	*/

	constructor: function(config){

		this.svcch = null;//System view cell click handler

		// Call the superclass constructor, so that all widget's common methods will be available

		// for this widget

		canvas.accountSummaryClassicWidget.superclass.constructor.call(this, config);

		cbx.apply(this,config);

		//Gagan: initializing MuliView Object to mv
		
		var that = this;
		this.mv = new iportal.view.MultiView({

			id:'ACC_SUMMARY_WGT',
			listeners : {
				'cellclick' 	: that.cellHandler,
				'contextclick'  : that.processContext
				}
		});				

    },
	cellHandler : function (colId, colVal, record){

		this.svcch ? this.svcch.processCellClick(colId, colVal, this, record) : Ext.emptyFn;

	},

	processContext : function (domid, colId, colVal, record, evt){

		this.svcch ? this.svcch.generateContext(domid, colId, colVal, record, evt) : Ext.emptyFn;

	},
	viewChangeHandler : function (svid, vdef){

		var hander = ICCHF.getHandler(svid);

		if (hander) {

			this.svcch = new hander();

			if (Ext.isFunction(this.svcch.setMultiView)) {

				this.svcch.setMultiView(this.mv);

			}

			if (Ext.isFunction(this.svcch.setVdf)) {

				vdef.VIEW_MD.WIDGET_ID = 'ACC_SUMMARY_WGT',

				this.svcch.setVdf(vdef);

			} else {

				this.svcch = null;

			}



		}

	}



});
