/**************************************************************************

 * These materials are confidential and proprietary to Intellect Design Arena Limited
 
 *  and no part of these materials should be reproduced, 

 * published, transmitted or distributed  in any form or by any means, 

 * electronic, mechanical, photocopying, recording or otherwise, or 

 * stored in any information storage or retrieval system of any nature 

 * nor should the materials be disclosed to third parties or used in any 

 * other manner for which this is not authorized, without the prior express 

 * written authorization of Intellect Design Arena Limited.

 *

 * Copyright 2010. Intellect Design Arena Limited. All rights reserved.

 *************************************************************************/

// Define the namespace for the widget

cbx.ns("canvas");



/**

 * 

 * @class iportal.widget.RULWidget

 * @extends iportal.Widget

 */

canvas.appWidget = Ext.extend(iportal.Widget, {

    /* This constructor will be called when you do

	* new iportal.widget.AccountPropertyWidget();

	*/

	constructor: function(config){

		this.svcch = null;//System view cell click handler

		// Call the superclass constructor, so that all widget's common methods will be available

		// for this widget

		canvas.appWidget.superclass.constructor.call(this, config);

		cbx.apply(this,config);

		//Gagan: initializing MuliView Object to mv
		
		var that = this;
		this.mv = new iportal.view.MultiView({

			id:'CT_APP_WGT',
			listeners : {

				'bbuttonclick'  : that.bButtonClick,
				'cellclick' 	: that.cellHandler,
				'contextclick'  : that.processContext

				}


		});

				

    },
    bButtonClick : function (buttonId, record){
		var grid = this.mvh.getGridCmp();
		var commbun = CRB.getBundle("COMMON");
		if (buttonId == "UTL_DEL") {
			var sRecord=record;
			if(sRecord==''||Ext.isEmpty(sRecord)||sRecord==undefined)	{
				var widObj = this;
				  var confDlWin = new iportal.Dialog({
						dialogType : 'MESSAGE',
						bundleKey: "COMMON",
						scope : this,
						title: commbun['LBL_DELETE_WIN_VALID'],
						message : commbun['LBL_DELETE_VALID'],
						okHandler : function(){
							confDlWin.close();					
						}
				});
				confDlWin.show();
			}else{ 
				var widObj = this;
				  var confWin = new iportal.Dialog({
						dialogType : 'USERDEFINED',
						dialogStyle : 'YES_NO',
						bundleKey: "COMMON",
						scope : this,
						title: commbun['LBL_DELETE_WIN_TITLE'], //BUG_ID_46
						message : commbun['LBL_DELETE_CONFRIMATION'],
						yesHandler : function(){
							var selRecord=record[0].data;						
							var utilObj=new cbx.form.listeners.registeredUtility();
							utilObj.utilRegisteredDelete(selRecord);
							//BUG_ID_44 Starts
						/*	var widContainer=iportal.workspace.metadata.getCurrentWorkspace().getWidgetContainer();
							var widgetArr =widContainer.find("itemId","WGT_REGISTER_UTILITY");
							widgetArr[0].refreshWidgetData();*/
							//BUG_ID_44 Ends
					//		widObj.mvh.refresh();
						confWin.close();					
						},
						noHandler : function(){
						confWin.close();
						}
				});
					confWin.show();
			}	
		}		
		if (buttonId == "UTL_ADD") {
			CBXFORMCONTAINER.getWindow("CONTAINER_REGIS_UTIL");
		}
		
		
	},
	cellHandler : function (colId, colVal, record){

		this.svcch ? this.svcch.processCellClick(colId, colVal, this, record) : Ext.emptyFn;

	},

	processContext : function (domid, colId, colVal, record, evt){

		this.svcch ? this.svcch.generateContext(domid, colId, colVal, record, evt) : Ext.emptyFn;

	},
	viewChangeHandler : function (svid, vdef){

		var hander = ICCHF.getHandler(svid);

		if (hander) {

			this.svcch = new hander();

			if (Ext.isFunction(this.svcch.setMultiView)) {

				this.svcch.setMultiView(this.mv);

			}

			if (Ext.isFunction(this.svcch.setVdf)) {

				vdef.VIEW_MD.WIDGET_ID = 'CT_APP_WGT',

				this.svcch.setVdf(vdef);

			} else {

				this.svcch = null;

			}



		}

	}



});
