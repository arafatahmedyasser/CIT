Ext.namespace('iportal.jsfiles.framework.alerts');

iportal.jsfiles.framework.alerts.alertview = function (record, widgetObj)
{

	var rb = CRB.getBundle('common');
	var cmnrb = CRB.getBundle('common');
	var con = iportal.jsfiles.framework.inbox.messageListViewConstants;
	var widgetId = widgetObj.itemId;

	if (record != null)
	{
		var message_id = record.json.MESSAGE_ID;
		var readInd = record.json.READ_INDICATOR;
		var param_obj = {
			"PAGE_CODE_TYPE" : "ALERT_CODE",
			"INPUT_ACTION" : "GET_ALERT_DETAIL_MESSAGE",
			"PRODUCT_NAME" : "ALERTS",
			"MESSAGE_ID" : message_id,
			"INPUT_FUNCTION_CODE" : "VSBLTY",
			"INPUT_LANGUAGE_ID" : iportal.preferences.getPrimaryLang(),
			"INPUT_SUB_PRODUCT" : "ALERTS"

		};
		Ext.Ajax.request({
			params : param_obj,
			success : function (responseP, optionsP)
			{
				var respObj = Ext.decode(responseP.responseText);
				if (respObj.ALL_RECORDS)
				{
					respData = respObj.ALL_RECORDS;
					showDetailsMsg(respData, message_id, widgetObj, widgetId);
				}
			}
		});
	}

	function showDetailsMsg (rec_data, msg_id, widgetObj, widgetId, severity)
	{

		if (rec_data.ALERT_DATE_TIME_ID)
		{
			var alert_datetime = rec_data.ALERT_DATE_TIME_ID;
			var datetime_to_set = iportal.jsutil.getFormattedDateAndTimeNoTZ(alert_datetime);
			rec_data[con.ALERT_DATE_TIME_ID] = datetime_to_set;

		}

		var disable_flg;
		if (rec_data.HAS_ATTACHMENT == 'Y')
		{
			disable_flg = false;
		} else
		{
			disable_flg = true;
		}

		CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getMergedArray([ "FORM_CONTAINER" ]), function ()
		{
			var fm = new cbx.form.FormManager({
				formId : "ALERTS_DETAIL_FORM",
				additionalConfig : {
					'record' : record,
					'rec_data' : rec_data,
					'widgetObj' : widgetObj
				}

			});
			CBXFORMCONTAINER.getWindowByFormObj(fm, "ALERT_FORM_CONTAINER", null);
		});

	}
	;

};
