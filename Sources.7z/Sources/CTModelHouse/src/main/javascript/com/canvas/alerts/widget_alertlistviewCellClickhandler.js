Ext.ns("canvas.widget");
canvas.widget.alertlistviewCellClickhandler = Ext.extend(Ext.util.Observable, {
	// Intended to hold resource bundle object
	rb : null,
	// This constructor will be called when you do
	// new canvas.widget.alertlistviewCellClickhandler();

	constructor : function (config)
	{

		canvas.widget.alertlistviewCellClickhandler.superclass.constructor.call(this, config);
		Ext.apply(this, config);
		this.rb = CRB.getBundle('common');

	},
	/**
	 * Setter API to set MultiView object.
	 */
	setMultiView : function (ob)
	{
		this.mv = ob;
	},
	/**
	 * Setter API to set View definition object.
	 */
	setVdf : function (ob)
	{
		this.vdf = ob;
	},
	/**
	 * This will be called as and when user double clicks any record in Alert List View.
	 */
	processCellClick : function (widObj, record)
	{
		iportal.jsfiles.framework.alerts.alertview(record, widObj);
	},
	generateContext : function (widObj, record, evt)
	{
		CBXCONTEXTMENU.getContextMenu(widObj, record, evt);
	}

});

ICCHF.registerHandler('ALERT_VIEW', canvas.widget.alertlistviewCellClickhandler);


CMHR.registerHandler("DELETE_ALERT", function (config)
{
				iportal.jsfiles.framework.alerts.deleteAlert(widObj, record);
});

