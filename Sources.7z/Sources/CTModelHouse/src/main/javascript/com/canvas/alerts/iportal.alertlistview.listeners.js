Ext.namespace('iportal.jsfiles.framework.alerts');

iportal.jsfiles.framework.alerts.deleteAlert = function (widObj, selRec)
{

	var rb = CRB.getBundle('common');
	var respObj;
	var messageId = selRec.json.MESSAGE_ID;
	var severity = selRec.json.SEVERITY;

	var param = {
		"PAGE_CODE_TYPE" : 'ALERT_CODE',
		"INPUT_ACTION" : 'DELETE_ACTION',
		"INPUT_PRODUCT" : 'ALERTS',
		"INPUT_SUB_PRODUCT" : 'ALERTS',
		'PRODUCT_NAME' : 'ALERTS',
		"INPUT_FUNCTION_CODE" : 'VSBLTY',
		"SEVERITY_SELECTED" : severity,
		"MSG_ID" : messageId

	};

	var deleteWin = new iportal.Dialog({
		title : rb['LBL_CONFIRMATION'],
		basecls : 'k-window',

		dialogType : 'USERDEFINED',
		dialogStyle : 'YES_NO',
		message : rb['ALERT_DEL_CONFIRM_MSG'],
		yesHandler : function ()
		{
			deleteWin.close();
			Ext.Ajax.request({
				params : param,
				success : function (responseP, optionsP)
				{
					var respObj = Ext.decode(responseP.responseText);

					showMsgOkWin();

				}
			});

		},
		noHandler : function ()
		{
			deleteWin.close();
		}
	});
	deleteWin.show();

	function showMsgOkWin ()
	{

		var Confirmation_Win = new iportal.Dialog({
			title : rb['LBL_MESSAGE_TITLE'],
			dialogType : 'MESSAGE',
			message : (widObj.itemId == 'WGT_ALERT' ? rb['ALERT_DEL_SUC_MSG'] : rb['NOTIFY_DEL_SUC_MSG']),

			okHandler : function ()
			{
				widObj.refreshWidgetData();
				Confirmation_Win.close();
			}
		});
		Confirmation_Win.show();
	}

};
