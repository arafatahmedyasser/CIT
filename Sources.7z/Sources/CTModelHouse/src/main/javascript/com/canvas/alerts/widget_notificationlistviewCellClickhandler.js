Ext.ns("canvas.widget");

/**
 * Intended to handle double click action on Notification List View
 * 
 * @class canvas.widget.notificationlistviewCellClickhandler
 * @extends canvas.widget
 */

canvas.widget.notificationlistviewCellClickhandler = Ext.extend(Ext.util.Observable, {
	// Intended to hold resource bundle object
	rb : null,
	// This constructor will be called when you do
	// new canvas.widget.notificationlistviewCellClickhandler();

	constructor : function (config)
	{

		canvas.widget.notificationlistviewCellClickhandler.superclass.constructor.call(this, config);
		Ext.apply(this, config);
		this.rb = CRB.getBundle('common');

	},
	/**
	 * Setter API to set MultiView object.
	 */
	setMultiView : function (ob)
	{
		this.mv = ob;
	},
	/**
	 * Setter API to set View definition object.
	 */
	setVdf : function (ob)
	{
		this.vdf = ob;
	},
	/**
	 * This will be called as and when user double clicks any record in Notification List View.
	 */
	processCellClick : function (widObj, record)
	{
		iportal.jsfiles.framework.alerts.alertview(record, widObj);
	},
	generateContext : function (widObj, record, evt)
	{
		CBXCONTEXTMENU.getContextMenu(widObj, record, evt);
	}
});

ICCHF.registerHandler('NOTIFY_VIEW', canvas.widget.notificationlistviewCellClickhandler);


CMHR.registerHandler("DELETE_NOTIFICATION", function (config)
{
				iportal.jsfiles.framework.alerts.deleteAlert(widObj, record);
});