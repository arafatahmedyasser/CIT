cbx.ns("cbx.form.listeners");

cbx.form.listeners.paymentForm = Class(cbx.Observable, {
	constructor : function (config)
	{
		this.fm = config.fm;
	},
	registerHandlers : function ()
	{

		this.fm.registerHandler("cbxpreinitialize", function (fm, event, fieldName, value)
		{
			return;
		});
		this.fm.registerHandler('cbxpremodelload', function (fm, record){
		    fm.setMinValue('TRAN_DATE',this.getCurrentDate());
		    if(!cbx.isEmpty(fm.additionalConfig.txnMode) && (fm.additionalConfig.txnMode=="edit"||fm.additionalConfig.txnMode=="view")){
		    	LOGGER.info("about to request data");
		    	return {
		    		"INPUT_ACTION"			: "GET_TXN",
					"INPUT_FUNCTION_CODE"	: "VSBLTY",
					"INPUT_PRODUCT"			: "CUSER",
					"INPUT_SUB_PRODUCT"		: "CUSER",
					"PAGE_CODE_TYPE"		: "GET_TXN",
					"PRODUCT_NAME"			: "CUSER",
					"REFERENCE_NO"			: fm.additionalConfig['reference_no']
		    	};
		    }
		});
		this.fm.registerHandler('cbxpostmodelload', function (fm, record){
			LOGGER.info("about to set data");
			fm.model.setValue("ACC_NO",record.ACC_NO);
			fm.model.setValue("BENE_ACC_NO",record.BENE_ACC_NO);
			this.setDebtorDetails(record);
			this.setBeneDetails(record);
			fm.model.setValue("TRANSACTION_AMT",record.TRANSACTION_AMT);
			fm.model.setValue("TRAN_DATE",record.TRAN_DATE);
		});
		this.fm.registerHandler("cbxchange","ACC_NO", function (fm, event,fieldName, value){
			if(!cbx.isEmpty (value)){
				var paramsOb ={
							"INPUT_ACTION"			: "GET_ACC_DTLS",
							"INPUT_FUNCTION_CODE"	: "VSBLTY",
							"INPUT_PRODUCT"			: "CUSER",
							"INPUT_SUB_PRODUCT"		: "CUSER",
							"PAGE_CODE_TYPE"		: "ACC_CODE",
							"PRODUCT_NAME"			: "CUSER",
							"ACCOUNT_NO"			: value
				};
				this.requestData(paramsOb, this.setDebtorDetails);
			}
		});
		this.fm.registerHandler("cbxchange","BENE_ACC_NO", function (fm, event,fieldName, value){
			if(!cbx.isEmpty (value)){
				var paramsOb ={
							"INPUT_ACTION"			: "GET_BENE_DTLS",
							"INPUT_FUNCTION_CODE"	: "VSBLTY",
							"INPUT_PRODUCT"			: "CUSER",
							"INPUT_SUB_PRODUCT"		: "CUSER",
							"PAGE_CODE_TYPE"		: "BENE_CODE",
							"PRODUCT_NAME"			: "CUSER",
							"BENE_ACC_NO"			:value
				};
				this.requestData(paramsOb, this.setBeneDetails);
			}
		});
	},
	getCurrentDate : function(){
		var today = new Date();
	    var dd = today.getDate();
	    var mm = today.getMonth()+1; //January is 0!

	    var yyyy = today.getFullYear();
	    if(dd<10){
	        dd='0'+dd;
	    } 
	    if(mm<10){
	        mm='0'+mm;
	    } 
	    return dd+'/'+mm+'/'+yyyy;
	},
	setBeneDetails : function(response){
		var fm = this.scope?this.scope.fm:this.fm;
		fm.model.setValue('BENE_NAME',response.BENE_NAME);
		fm.model.setValue('BENE_CCY',(response.CURRENCY||response.BENE_CCY));
		fm.model.setValue('BENE_BANK',(response.BANK_NAME||response.BENE_BANK));
		fm.model.setValue('BENE_BRANCH',(response.BRANCH_NAME||response.BENE_BRANCH));
		fm.model.setValue('BENE_CITY',response.BENE_CITY||"");
		fm.model.setValue('BENE_ADDRESS',response.BENE_ADDRESS||"");
	},
	setDebtorDetails : function(response){
		var fm = this.scope?this.scope.fm:this.fm;
		fm.model.setValue('ACC_CCY',(response.CURRENCY||response.ACC_CCY));
		fm.model.setValue('ACC_TYPE',(response.ACCOUNT_TYPE||response.ACC_TYPE));
		fm.model.setValue('ACC_NAME',(response.ACC_NAME||response.ACCOUNT_NAME||""));
	},
	requestData: function(params,callBack){
		cbx.ajax({
			params : params,
			success : callBack,
			scope:this
		});
	}

});
CFLR.registerListener("CT_PAYMENT_FORM", cbx.form.listeners.paymentForm);
CABR.registerHandler('PAY_SUMBIT','PAYMENTS_FORM_CONTAINER', function (config){
	
	var fm = config.formObj;
	var refNo = fm.additionalConfig['reference_no']||'';
	if(cbx.isEmpty(fm.model.getValue('ACC_NO'))){
		fm.markInvalid("ACC_NO");
		return;
	}
	else if(cbx.isEmpty(fm.model.getValue('BENE_ACC_NO'))){
		fm.markInvalid("BENE_ACC_NO");
		return;
	}
	else if(cbx.isEmpty(fm.model.getValue('TRANSACTION_AMT'))){
		fm.markInvalid("TRANSACTION_AMT");
		return;
	}
	else if(cbx.isEmpty(fm.model.getValue('TRAN_DATE'))){
		fm.markInvalid("TRAN_DATE");
		return;
	}
	var ajaxParams = {
				"INPUT_ACTION"			: "SUBMIT",
				"INPUT_FUNCTION_CODE"	: "VSBLTY",
				"INPUT_PRODUCT"			: "CUSER",
				"INPUT_SUB_PRODUCT"		: "CUSER",
				"PAGE_CODE_TYPE"		: "TXN_CODE",
				"PRODUCT_NAME"			: "CUSER",
				"REFERENCE_NO"			:  refNo
	};
	cbx.apply(ajaxParams,fm.getModelData());
	cbx.ajax({
		params : ajaxParams,
		success : function(response){
			var referenceNo = response.REFERENCE_NO;
			var text = response.STATUS=="SUCCESS"?CRB.getBundleValue("common","LBL_TRAN_SUCCESS"):CRB.getBundleValue("common","LBL_TRAN_FAILURE");
			text = String.format(text,referenceNo);
			var successDialog = new iportal.Dialog({
				dialogType:"ERROR",
				title : "Confirmation Window", 
				message : text,
				okHandler : function(){
					successDialog.close();
					if(window.transactionComplete){
						window.dispatchEvent(window.transactionComplete);
						return true;
					}
					else{
						CBXFORMCONTAINER.exit(config);
						if(fm.additionalConfig['widgetObj']){
							widget = fm.additionalConfig['widgetObj'];
							widget.refreshWidgetData();
						}
					}
				}
			});
			successDialog.show();
		}
	});
	
});
CABR.registerHandler('PAY_DRAFT','PAYMENTS_FORM_CONTAINER', function (config){
	var fm = config.formObj;
	if(cbx.isEmpty(fm.model.getValue('ACC_NO'))){
		fm.markInvalid("ACC_NO");
		return;
	}
	var refNo = fm.additionalConfig['reference_no']||'';
	var modelValueArray = fm.model.getModelData();

	if(cbx.isEmpty(fm.model.getValue('TRANSACTION_AMT'))){
		fm.model.setValue('TRANSACTION_AMT','0.00');
	}
	for (var key in modelValueArray) {
		  if (modelValueArray.hasOwnProperty(key) && cbx.isEmpty(modelValueArray[key])) {
			  modelValueArray[key] = '';
		  }
		}
	var ajaxParams = {
				"INPUT_ACTION"			: "DRAFT",
				"INPUT_FUNCTION_CODE"	: "VSBLTY",
				"INPUT_PRODUCT"			: "CUSER",
				"INPUT_SUB_PRODUCT"		: "CUSER",
				"PAGE_CODE_TYPE"		: "TXN_CODE",
				"PRODUCT_NAME"			: "CUSER",
				"REFERENCE_NO"			:  refNo
	};
	cbx.apply(ajaxParams,fm.getModelData());
	cbx.ajax({
		params : ajaxParams,
		success : function(response){
			var referenceNo = response.REFERENCE_NO;
			var text = response.STATUS=="SUCCESS"?CRB.getBundleValue("common","LBL_DRAFT_TRAN_SUCCESS"):CRB.getBundleValue("common","LBL_TRAN_FAILURE");
			text = String.format(text,referenceNo);
			var successDialog = new iportal.Dialog({
				dialogType:"ERROR",
				title : "Confirmation Window", 
				message : text,
				okHandler : function(){
					successDialog.close();
					if(window.transactionComplete){
						window.dispatchEvent(window.transactionComplete);
						return true;
					}
					else{
						CBXFORMCONTAINER.exit(config);
						if(fm.additionalConfig['widgetObj']){
							widget = fm.additionalConfig['widgetObj'];
							widget.refreshWidgetData();
						}
					}
				}
			});
			successDialog.show();
		
		}
	});
	CBXFORMCONTAINER.getWindow("CONTAINER_FUND_TRANSFER",config);
});
CABR.registerHandler('DELETE','PAYMENTS_FORM_CONT_DEL', function (config){
	var fm = config.formObj;
	var refNo = fm.additionalConfig['reference_no'];
	var ajaxParams = {
				"INPUT_ACTION"			: "DELETE_TXN",
				"INPUT_FUNCTION_CODE"	: "VSBLTY",
				"INPUT_PRODUCT"			: "CUSER",
				"INPUT_SUB_PRODUCT"		: "CUSER",
				"PAGE_CODE_TYPE"		: "DELETE_TXN",
				"PRODUCT_NAME"			: "CUSER",
				"REFERENCE_NO"			: refNo
	};
	cbx.ajax({
		params : ajaxParams,
		success : function(response){
			var referenceNo = response.REFERENCE_NO;
			var text = response.STATUS=="SUCCESS"?CRB.getBundleValue("common","LBL_DEL_SUCCESS"):CRB.getBundleValue("common","LBL_TRAN_FAILURE");
			text = String.format(text,referenceNo);
			var successDialog = new iportal.Dialog({
				dialogType:"ERROR",
				title : "Confirmation Window", 
				message : text,
				okHandler : function(){
					successDialog.close();
					if(window.transactionComplete){
						window.dispatchEvent(window.transactionComplete);
						return true;
					}
					else{
						CBXFORMCONTAINER.exit(config);
						if(fm.additionalConfig['widgetObj']){
							widget = fm.additionalConfig['widgetObj'];
							widget.refreshWidgetData();
						}
					}
				}
			});
			successDialog.show();
		}
	});
});
CABR.registerHandler('REJECT','PAYMENTS_CONT_REJECT', function (config){
	var fm = config.formObj;
	var refNo = fm.additionalConfig['reference_no'];
	var ajaxParams = {
				"INPUT_ACTION"			: "REJECT_TXN",
				"INPUT_FUNCTION_CODE"	: "VSBLTY",
				"INPUT_PRODUCT"			: "CUSER",
				"INPUT_SUB_PRODUCT"		: "CUSER",
				"PAGE_CODE_TYPE"		: "REJECT_TXN",
				"PRODUCT_NAME"			: "CUSER",
				"REFERENCE_NO"			: refNo
	};
	cbx.ajax({
		params : ajaxParams,
		success : function(response){
			var referenceNo = response.REFERENCE_NO;
			var text = response.STATUS=="SUCCESS"?CRB.getBundleValue("common","LBL_REJECTED_SUCCESS"):CRB.getBundleValue("common","LBL_TRAN_FAILURE");
			text = String.format(text,referenceNo);
			var successDialog = new iportal.Dialog({
				dialogType:"ERROR",
				title : "Confirmation Window", 
				message : text,
				okHandler : function(){
					successDialog.close();
					if(window.transactionComplete){
						window.dispatchEvent(window.transactionComplete);
						return true;
					}
					else{
						CBXFORMCONTAINER.exit(config);
						if(fm.additionalConfig['widgetObj']){
							widget = fm.additionalConfig['widgetObj'];
							widget.refreshWidgetData();
						}
					}
				}
			});
			successDialog.show();
		}
	});
});
CABR.registerHandler('AUTHORIZE','PAYMENTS_CONT_AUTHREJECT', function (config){
	var fm = config.formObj;
	var refNo = fm.additionalConfig['reference_no'];
	var ajaxParams = {
				"INPUT_ACTION"			: "AUTH_TXN",
				"INPUT_FUNCTION_CODE"	: "VSBLTY",
				"INPUT_PRODUCT"			: "CUSER",
				"INPUT_SUB_PRODUCT"		: "CUSER",
				"PAGE_CODE_TYPE"		: "AUTH_TXN",
				"PRODUCT_NAME"			: "CUSER",
				"REFERENCE_NO"			: refNo
	};
	cbx.ajax({
		params : ajaxParams,
		success : function(response){
			var referenceNo = response.REFERENCE_NO;
			var text = response.STATUS=="SUCCESS"?CRB.getBundleValue("common","LBL_AUTH_SUCCESS"):CRB.getBundleValue("common","LBL_TRAN_FAILURE");
			text = String.format(text,referenceNo);
			var successDialog = new iportal.Dialog({
				dialogType:"ERROR",
				title : "Confirmation Window", 
				message : text,
				okHandler : function(){
					successDialog.close();
					if(window.transactionComplete){
						window.dispatchEvent(window.transactionComplete);
						return true;
					}
					else{
						CBXFORMCONTAINER.exit(config);
						if(fm.additionalConfig['widgetObj']){
							widget = fm.additionalConfig['widgetObj'];
							widget.refreshWidgetData();
						}
					}
				}
			});
			successDialog.show();
		}
	});
});
CABR.registerHandler('CLOSE','PAYMENTS_CONT_AUTHREJECT', function (config){
	if(window.transactionComplete){
		window.dispatchEvent(window.transactionComplete);
		return true;
	}
	else{
		CBXFORMCONTAINER.exit(config);
	}
});