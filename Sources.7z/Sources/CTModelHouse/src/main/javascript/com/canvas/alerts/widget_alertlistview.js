Ext.ns("canvas.widget");

canvas.widget.AlertListWidget = Ext.extend(iportal.Widget, {
	constructor : function (config)
	{
		this.svcch = null;
		canvas.widget.AlertListWidget.superclass.constructor.call(this, config);
		Ext.apply(this, config);

		this.mv = new iportal.view.MultiView({
			id : 'WGT_ALERT',
			extraParamsHandler : this.extraParamsG,
			listeners : {
				'highlight' : this.highlightHandler,
				'viewchange' : this.viewChangeHandler,
				'cellclick' : this.cellHandler,
				'contextclick' : this.processContext,
				'bbuttonclick' : this.bButtonClick
			},
			services : {

			}
		});
		//this.rb = this.mv.bundle || CRB.getFWBundle();
	},

	highlightHandler : function (store, viewConfig)
	{

		Ext.apply(viewConfig, {
			getRowClass : function (record, rowIndex, rp, ds)
			{

				if (record.json.READ_INDICATOR == 'N')
				{
					return 'highlightMsg';
				} else
				{
					return '';
				}
			}
		});
	},

	bButtonClick : function (buttonId, record)
	{
		var commbun = CRB.getBundle("common");

		var grid = this.mvh.getGridCmp();

		if (buttonId == "BTN_DELETE")
		{
			if (grid != null)
			{
				var selectRowCount = grid.getSelectionModel().getCount();
				if (selectRowCount == 0)
				{
					var err_Dialog = new iportal.Dialog({
						dialogType : 'ERROR',
						title : commbun.LBL_ERROR_TITLE,
						message : commbun['LBL_ALERT_DEL'],// DIT_BA_047 Papiya
						okHandler : function ()
						{
							err_Dialog.close();
						}
					});
					err_Dialog.show();
				} else if (selectRowCount > 0)
				{
					var selectedRow = grid.getSelectionModel().getSelected();
					iportal.jsfiles.framework.alerts.deleteAlert(this, selectedRow);
				}
			}

		} else if (buttonId == "BTN_MANAGE_ALERTS")
		{
			 iportal.jsfiles.framework.alerts.manageAlerts();
		}

	},

	cellHandler : function (colId, colVal, record)
	{
		this.svcch ? this.svcch.processCellClick(this, record) : Ext.emptyFn;
	},
	processContext : function (domid, colId, colVal, record, evt)
	{
		this.svcch ? this.svcch.generateContext(this, record, evt) : Ext.emptyFn;
	},
	viewChangeHandler : function (svid, vdef)
	{
		var hander = ICCHF.getHandler(svid);
		if (hander)
		{
			this.svcch = new hander();
			if (Ext.isFunction(this.svcch.setMultiView))
			{
				this.svcch.setMultiView(this.mv);
			}
			if (Ext.isFunction(this.svcch.setVdf))
			{
				vdef.VIEW_MD.WIDGET_ID = 'WGT_ALERT';
				this.svcch.setVdf(vdef);
			} else
			{
				this.svcch = null;
			}

		}
	}
});
