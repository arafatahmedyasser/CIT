CMHR.registerHandler('INIT_PAY', function (config)
{
	CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getConstant('FORM_CONTAINER'), function (scope)
	{
		var today = new Date();
		var dd = today.getDate();
		var mm = window.transactionComplete ? today.getMonth() : today.getMonth() + 1; // January is 0!

		var yyyy = today.getFullYear();
		if (dd < 10)
		{
			dd = '0' + dd;
		}
		if (mm < 10)
		{
			mm = '0' + mm;
		}
		today = dd + '/' + mm + '/' + yyyy;

		var fm = new cbx.form.FormManager({
			formId : "CT_PAYMENT_FORM",
			additionalConfig : {
				"recordInfo" : config.record,
				"txnMode" : "INIT"
			},
			modelData : {
				'ACC_NO' : this.record.data['ACCOUNT_NO'],
				'ACC_CCY' : this.record.data['CURRENCY'],
				'ACC_TYPE' : this.record.data['ACCOUNT_TYPE'],
				'ACC_NAME' : this.record.data['ACCOUNT_NAME'] || "",
				"TRAN_DATE" : today
			}
		});
		CBXFORMCONTAINER.getWindowByFormObj(fm, "PAYMENTS_FORM_CONTAINER");
	}, 'js', config);
});
CWEH.registerHandler("WGT_PAYEE", CWEC.CONTEXT_CLICK, function ()
{
	CBXCONTEXTMENU.getContextMenu;
});

CMHR.registerHandler("DRAFT_VIEW_DELETE", function (config)
{
	deleteTransaction(config.record.data,(config.record.widObj||null));
});

CMHR.registerHandler("DRAFT_VIEW_EDIT", function (config)
{
	editTransaction(config.record.data,(config.record.widObj||null));
});
CMHR.registerHandler("REJECTED_VIEW_EDIT", function (config)
{
	editTransaction(config.record.data,(config.record.widObj||null));
});

CMHR.registerHandler("PENDING_VIEW_AUTH_REJECT", function (config)
{
	authorizeRejectTransaction(config.record.data,(config.record.widObj||null));
});

CMHR.registerHandler("PENDING_VIEW_REJECT", function (config)
{
		rejectTransaction(config.record.data,(config.record.widObj||null));
});



CMHR.registerHandler("READY_VIEW_VIEW", function (config)
{
	viewTransaction(config.record.data,(config.record.widObj||null));
});

viewTransaction = function (config,widObj)
{	
	CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getConstant('FORM_CONTAINER'), function (scope)
		{
		var fm = new cbx.form.FormManager({
			formId : "CT_PAYMENT_FORM",
			additionalConfig : {
				"reference_no" : config.REFERENCE_NO,
				"txnMode" : "view",
				"record": config,
				"widgetObj":widObj
			},
			modelData : {
				"TRAN_TYPE":config.TRAN_TYPE
			},
			mode:"view"
		});
		CBXFORMCONTAINER.getWindowByFormObj(fm, "PAYMENTS_FORM_CONTAINER_VW");
	}, 'js', config);
};
editTransaction = function (config,widObj)
{
	CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getConstant('FORM_CONTAINER'), function (scope)
				{
				var fm = new cbx.form.FormManager({
					formId : "CT_PAYMENT_FORM",
					additionalConfig : {
						"reference_no" : config.REFERENCE_NO,
						"txnMode" : "edit",
						"record": config,
						"widgetObj":widObj
					},
					modelData : {
						"TRAN_TYPE":config.TRAN_TYPE
					}
				});
				CBXFORMCONTAINER.getWindowByFormObj(fm, "PAYMENTS_FORM_CONTAINER");
			}, 'js', config);
};
deleteTransaction = function (config,widObj)
{
	CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getConstant('FORM_CONTAINER'), function (scope)
				{
				var fm = new cbx.form.FormManager({
					formId : "CT_PAYMENT_FORM",
					additionalConfig : {
						"reference_no" : config.REFERENCE_NO,
						"txnMode" : "view",
						"record": config,
						"widgetObj":widObj
					},
					modelData : {
						"TRAN_TYPE":config.TRAN_TYPE
					},
					mode:"view"
				});
				CBXFORMCONTAINER.getWindowByFormObj(fm, "PAYMENTS_FORM_CONT_DEL");
			}, 'js', config);
};
authorizeRejectTransaction = function (config,widObj)
{
	CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getConstant('FORM_CONTAINER'), function (scope)
				{
				var fm = new cbx.form.FormManager({
					formId : "CT_PAYMENT_FORM",
					additionalConfig : {
						"reference_no" : config.REFERENCE_NO,
						"txnMode" : "view",
						"record": config,
						"widgetObj":widObj
					},
					modelData : {
						"TRAN_TYPE":config.TRAN_TYPE
					},
					mode:"view"
				});
				CBXFORMCONTAINER.getWindowByFormObj(fm, "PAYMENTS_CONT_AUTHREJECT");
			}, 'js', config);
};
rejectTransaction = function (config,widObj)
{
	CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getConstant('FORM_CONTAINER'), function (scope)
				{
				var fm = new cbx.form.FormManager({
					formId : "CT_PAYMENT_FORM",
					additionalConfig : {
						"reference_no" : config.REFERENCE_NO,
						"txnMode" : "view",
						"record": config,
						"widgetObj":widObj
					},
					modelData : {
						"TRAN_TYPE":config.TRAN_TYPE
					},
					mode:"view"
				});
				CBXFORMCONTAINER.getWindowByFormObj(fm, "PAYMENTS_CONT_REJECT");
			}, 'js', config);
};


CMHR.registerCondition("PENDING_VIEW",function(config){
	if(config.data["AUTH_FLAG"]=="Y"){
		return ["PENDING_VIEW_AUTH_REJECT"];
	}
	else{
		return [];
	}
});