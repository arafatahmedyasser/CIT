Ext.ns("cbx.form.listeners");
cbx.form.listeners.MessageForm = Ext.extend(Ext.util.Observable, {
	constructor : function (config)
	{
		this.fm = config.fm;
		this.additionalConfig = config.fm.additionalConfig;
		cbx.form.listeners.MessageForm.superclass.constructor.call(this, config);
	},
	registerHandlers : function ()
	{

		var additionalConfig = this.fm.additionalConfig;
		this.fm.registerHandler("cbxpreinitialize", function (fm, event, fieldName, value)
		{

			var record = fm.additionalConfig.rec_data;
			fm.model.setValue("RECEIVED_AT_ITEM", record.ALERT_DATE_TIME_ID);
			fm.model.setValue("ALERT_SHORT_MES", record.SHORT_MESSAGE);
			fm.model.setValue("PRODUCT", record.ALERT_PRODUCT_ID);
			fm.model.setValue("DETAIL_MSG", record.DETAIL_MESSAGE);

		});

		CABR.registerHandler("ALERT_DELETE", "ALERT_FORM_CONTAINER", function (fm, event, fieldName, value)
		{

			var record = additionalConfig.record;
			var widObj = additionalConfig.widgetObj;
			Ext.WindowMgr.getActive().close();
			iportal.jsfiles.framework.alerts.deleteAlert(widObj, record);

		}

		);

		CABR.registerHandler("ALERT_CANCEL", "ALERT_FORM_CONTAINER", function (fm, event, fieldName, value)
		{

			var record = additionalConfig.record;
			var msg_id = record.data.MESSAGE_ID;
			var widObj = additionalConfig.widgetObj;

			updateReadIndicatorStatus(msg_id, widObj);

			Ext.WindowMgr.getActive().close();

		}

		);

	}

});

var updateReadIndicatorStatus = function (msgId, widObj)
{
	var param = {
		"PAGE_CODE_TYPE" : 'ALERT_CODE',
		"INPUT_ACTION" : 'UPDATE_REFRESH_ACTION',
		"PRODUCT_NAME" : 'ALERTS',
		"INPUT_FUNCTION_CODE" : 'VSBLTY',
		"INPUT_SUB_PRODUCT" : 'ALERTS',
		"IS_FILTER_FORM" : false,
		"MSG_ID" : msgId
	};
	Ext.Ajax.request({
		params : param,
		success : function (responseP, optionsP)
		{
			widObj.refreshWidgetData();
		}
	});
};

CFLR.registerListener("ALERTS_DETAIL_FORM", cbx.form.listeners.MessageForm);
