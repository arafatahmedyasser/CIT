cbx.ns("cbx.form.listeners");

CABR.registerHandler("PREF_SAVE", "UPDATE_PREF_FORM_CONTAINER", function (fm, event, fieldName, value)
{
	var config = {
		"PREFERENCES" : {}
	};
	var pref = config["PREFERENCES"];
	var formObj = fm.formObj;
	pref["AMOUNT"] = formObj.model.getValue("AMOUNT");
	pref["DATEFORMAT"] = formObj.model.getValue("DATEFORMAT");
	pref["TIMEZONE"] = formObj.model.getValue("TIMEZONE");
	pref["LANGUAGE"] = formObj.model.getValue("LANGUAGE");
	pref["FONTSIZE"] = formObj.model.getValue("FONTSIZE");
	pref["THEME"] = formObj.model.getValue("THEME");
	pref["USER_ROLE"] = formObj.model.getValue("USER_ROLE");
	pref["TIMEFORMAT"] = formObj.model.getValue("TIMEFORMAT");
	CBXFORMCONTAINER.getActiveFormContainer().close();
	if (canvas.env.network.getState() == 'ACTIVE'){
	canvas.preferences.updatePreferences(config);
	}
});
CABR.registerHandler("PREF_CANCEL", "UPDATE_PREF_FORM_CONTAINER", function (fm, event, fieldName, value)
{

	//canvas.activeWindowClose();
	CBXFORMCONTAINER.getActiveFormContainer().close();

});

CABR.registerHandler("PREF_SAVE_TEMP", "UPDATE_PREF_FORM_CONTAINER", function (fm, event, fieldName, value)
{

	var config = {
		"PREFERENCES" : {}
	};
	var pref = config["PREFERENCES"];
	var formObj = fm.formObj;
	pref["AMOUNT"] = formObj.model.getValue("AMOUNT");
	pref["DATEFORMAT"] = formObj.model.getValue("DATEFORMAT");
	pref["TIMEZONE"] = formObj.model.getValue("TIMEZONE");
	pref["LANGUAGE"] = formObj.model.getValue("LANGUAGE");
	pref["FONTSIZE"] = formObj.model.getValue("FONTSIZE");
	pref["THEME"] = formObj.model.getValue("THEME");
	pref["USER_ROLE"] = formObj.model.getValue("USER_ROLE");
	pref["TIMEFORMAT"] = formObj.model.getValue("TIMEFORMAT");
	CBXFORMCONTAINER.getActiveFormContainer().close();
	if (canvas.env.network.getState() == 'ACTIVE'){
	canvas.preferences.temporaryPreferences(config);
	}

});

cbx.form.listeners.UPDATE_PREF_FORM = Class(cbx.Observable, {
	constructor : function (config)
	{
		this.fm = config.fm;
	},
	registerHandlers : function ()
	{

		this.fm.registerHandler("cbxpreinitialize", function (fm, event, fieldName, value)
		{

			var successHandler = function (response)
			{

				this.model.setValue("AMOUNT", response["AMOUNT"]);
				this.model.setValue("LANGUAGE", response["LANGUAGE"]);
				this.model.setValue("THEME", response["THEME"]);
				this.model.setValue("DATEFORMAT", response["DATEFORMAT"]);
				this.model.setValue("FONTSIZE", response["FONTSIZE"]);
				this.model.setValue("TIMEZONE", response["TIMEZONE"]);
				this.model.setValue("USER_ROLE", response["USER_ROLE"]);
				this.model.setValue("TIMEFORMAT", response["TIMEFORMAT"]);

			};

			var failureHandler = function (response)
			{

			};

			var PREFERENCES = {
				PREFERENCE_TYPES : []
			};
			PREFERENCES.PREFERENCE_TYPES.push("AMOUNT");
			PREFERENCES.PREFERENCE_TYPES.push("LANGUAGE");
			PREFERENCES.PREFERENCE_TYPES.push("THEME");
			PREFERENCES.PREFERENCE_TYPES.push("DATEFORMAT");
			PREFERENCES.PREFERENCE_TYPES.push("FONTSIZE");
			PREFERENCES.PREFERENCE_TYPES.push("TIMEZONE");
			PREFERENCES.PREFERENCE_TYPES.push("USER_ROLE"); 
			PREFERENCES.PREFERENCE_TYPES.push("TIMEFORMAT");
			canvas.preferences.initPreferences(PREFERENCES, fm, successHandler, failureHandler);

		});

	}

});
CFLR.registerListener("UPDATE_PREF_FORM", cbx.form.listeners.UPDATE_PREF_FORM);
