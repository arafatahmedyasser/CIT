IWMH.registerHandler("CT_CHILD_MENU1", IWMC.EVENT_CLICK, function (config)
{

	CBXDOWNLOADMGR.requestScripts("WSPACE_ALERT_NOTIFY", function ()
	{

		// CHG_ALERTS_WIDGETIZATION starts

		var config = {
			compId : 'WGT_ALERT_NOT_MSG_MULTI',
			height : 285,
			selectedIndex : 0,
			indexPosition : 'left',
			loadDefaultActions : true,
			mergeWidgetActions : true,
			loadDefaultPositiveButtons : function ()
			{
				return null;
			},
			loadDefaultNegativeButtons : function ()
			{
				var negativeActions = null;
				var rb = CRB.getFWBundle();
				if (this.loadDefaultActions == true)
				{
					var multiWidgetExpPanel = this;
					negativeActions = [];
					var cancelButton = {
						xtype : 'button',
						// Geetha.john DIT_1313 starts
						text : rb.LBL_CLOSE,

						// Geetha.john DIT_1313 ends
						cls : 'portal_neg_btn',
						handler : function ()
						{
							multiWidgetExpPanel.ownerCt.ownerCt.close();
						}
					};
					negativeActions.push(cancelButton);

				}
				return negativeActions;

			}

		};
		var txnWidget = new iportal.widget.MultiWidget(config);
		new iportal.widget.IndexedMultiWidgetWindow(txnWidget);

	});

 });

IWMH.registerHandler("CT_STACK_WSPACE2", IWMC.EVENT_CLICK, function (config){
	
});

//CT_PREFERENCES STARTS

IWMH.registerHandler("CT_PREFERENCE_MENU", IWMC.EVENT_CLICK, function (config)
{

	// CT_PREFERENCES STARTS
	CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getMergedArray(["FORM_CONTAINER","WSPACE_PREF_FORMS"]), function ()
	{
		var fm = new cbx.form.FormManager({
			formId : "UPDATE_PREF_FORM"

		});

		CBXFORMCONTAINER.getWindowByFormObj(fm, "UPDATE_PREF_FORM_CONTAINER", null);
	});

 });

//CT_PREFERENCES ENDS
IWMH.registerHandler('INIT_PAY',IWMC.EVENT_CLICK, function (config)
			{
				CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getConstant('FORM_CONTAINER'), function (scope)
				{
					var today = new Date();
					var dd = today.getDate();
					var mm = window.transactionComplete ? today.getMonth() : today.getMonth() + 1; // January is 0!

					var yyyy = today.getFullYear();
					if (dd < 10)
					{
						dd = '0' + dd;
					}
					if (mm < 10)
					{
						mm = '0' + mm;
					}
					today = dd + '/' + mm + '/' + yyyy;
					var fm = new cbx.form.FormManager({
						formId : "CT_PAYMENT_FORM",
						additionalConfig : {
							"txnMode" : "INIT"
						},
						modelData : {
							"TRAN_DATE" : today
						}
					});
					CBXFORMCONTAINER.getWindowByFormObj(fm, "PAYMENTS_FORM_CONTAINER");
				}, 'js', config);
});
IWMH.registerHandler("MESSAGES", IWMC.EVENT_LOAD, function (config){
	config.srcObj.setText("Loading...");
	var	param_obj = {
		"INPUT_ACTION" :  "GET_UNREAD_ALERT_COUNT",
		"INPUT_FUNCTION_CODE" :  "VSBLTY",
		"INPUT_SUB_PRODUCT": "CANVAS" ,
		"PAGE_CODE_TYPE" :  "ALERTSUMMARY_LIST_VIEW",
		"PRODUCT_NAME" :  "CANVAS"
	};
	Ext.Ajax.request({
		params : param_obj,
		success: function(responseP,optionsP){
			var alertJSONRecords = Ext.decode(responseP.responseText);
			var alertData = Number(alertJSONRecords.value[0]['NUM_ALERTS']);
			var alertLabel = alertData != 1?iportal.jsutil.getTextFromBundle("canvas-default","LBL_NUM_ALERTS") : iportal.jsutil.getTextFromBundle("canvas-default","LBL_NUM_ALERT");
			var alertObj= iportal.menuitems.metadata.getMenuToolById("MESSAGES");
			var countLabel = "<span class='alert-count'>"+alertData+"</span>";
			alertLabel = countLabel+alertLabel;
			if(alertObj!=null && alertObj.setText){
				alertObj.setText(alertLabel);
				//Ext.getCmp('ALERT_COUNT').update('<div class="alerts_up"></div><div class="information_alerts_high_up"><a href="#" onclick="iportal.listview.alertListDisplay();">'+alertJSONRecords.response.value.TOTAL_COUNT[0].NUM_ALERTS+' Alerts</a></div>')
			}
			/*Ext.each(alertData,function(severityCountMap){
				switch(severityCountMap.SEVERITY){
					case 'Medium' :
						if(!isNaN(severityCountMap.NUM_ALERTS)){
							if(Ext.get('Normal_Alerts_Count_ID')){
								var currentCount = Ext.get('Normal_Alerts_Count_ID').dom.innerHTML;
								if(severityCountMap.NUM_ALERTS!=currentCount){
									Ext.get('Normal_Alerts_Count_ID').update(severityCountMap.NUM_ALERTS);
								}
							}
						}
						break;
					case 'High':	
						if(!isNaN(severityCountMap.NUM_ALERTS)){
							if(Ext.get('Urgent_Alerts_Count_ID')){
								var currentCount = Ext.get('Urgent_Alerts_Count_ID').dom.innerHTML;
								if(severityCountMap.NUM_ALERTS!=currentCount){
									Ext.get('Urgent_Alerts_Count_ID').update(severityCountMap.NUM_ALERTS);
								}
							}
						}
						//that.checkForHighUnPoppedupAlertsSuceess.createDelegate(that,[response,options])();
						break;
				}
			});*/
           
			iportal.util.ajaxPiggyback.isPiggyBackInprocess=false;
		
		
		
		}
	}); 
});
IWMH.registerHandler("MESSAGES", IWMC.EVENT_CLICK, function (config){
	CBXDOWNLOADMGR.requestScripts(cbx.downloadProvider.getConstant("FORM_FRAMEWORK"),function(){
		cbx.AppContainerUtil.displayAppInAWindow("WGT_ALERT",Ext.EventObject);
	});
});