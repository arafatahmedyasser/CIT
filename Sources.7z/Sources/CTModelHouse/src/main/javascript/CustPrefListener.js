/**************************************************************************

 * These materials are confidential and proprietary to Intellect Design Arena Limited
 
 *  and no part of these materials should be reproduced, 

 * published, transmitted or distributed  in any form or by any means, 

 * electronic, mechanical, photocopying, recording or otherwise, or 

 * stored in any information storage or retrieval system of any nature 

 * nor should the materials be disclosed to third parties or used in any 

 * other manner for which this is not authorized, without the prior express 

 * written authorization of Intellect Design Arena Limited.

 *

 * Copyright 2010. Intellect Design Arena Limited. All rights reserved.
 * 
 * @author suman.debnath
 */
/**
 * DEPLOY_MODULE_ID: TODO: <Check with your lead for correct value>
 */


cbx.ns("canvas");

//canvas.custPref = Class(cbx.Observable, {
canvas.custPref = Ext.extend(Ext.util.Observable, {
	constructor : function(config) {
		this.fm = config.fm;
		//cbx.core.extend(this, config);
		canvas.custPref.superclass.constructor.call(this, config);
	},
	registerHandlers : function() {	
		var that=this;
		that.ix=0;
		this.fm.registerHandler("cbxpreinitialize",function(fm) {
		
		});

	   this.fm.registerHandler("cbxpremodelload",function(fm) {

	   });
       this.fm.registerHandler("cbxpostmodelload",function(fm,record) {

       });

       this.fm.registerHandler("cbxchange", "SMA_PERIODS", function (fm, event, fieldName,value){
    	   
       });
		this.fm.registerHandler("cbxchange", "WMA_PERIODS", function (fm, event, fieldName,value){
			 var noOfPeriods= fm.model.getValue("WMA_PERIODS");
			 var md=fm.model.getModelData();
			 if(noOfPeriods>22){
				 noOfPeriods=22;
				 fm.markInvalid("WMA_PERIODS","No. of Periods cannot be more than 22");
				 fm.model.setValue("WMA_PERIODS",noOfPeriods);
			 }
			 
			 var fieldList=[];
			 var showList=[];
			 var hideList=[];
			 for(var idx=0;idx<=22;idx++){
				 fieldList.push("WMA_WTD_PERIOD_"+idx);
			 }			 
			 
			 for(var idx=0;idx<=noOfPeriods;idx++){
				 showList.push("WMA_WTD_PERIOD_"+idx);
			 }
			
			 for(var f in fieldList){
				 if(fieldList[f]!=showList[f]){
					 hideList[f]=fieldList[f];
				 }
			 }
			 
			 
			 fm.setVisibleFields(showList,true);
			 
			 fm.setVisibleFields(hideList,false);
			 
			 
			 
			 
		 });
		this.fm.registerHandler("cbxchange", "ES_PERIODS", function (fm, event, fieldName,value){
			   
		});
		
		this.fm.registerHandler("cbxchange", "WMA_WTD_PERIOD", function (fm, event, fieldName,value, index, mformid){
			   
		});	
	
		this.fm.registerHandler("cbxclick","BTN_SUBMIT", function(fm,event,fieldname,params) {
			
			});
		
		
		CABR.registerHandler('CUST_PREF_SUBMIT', 'CANVAS_FORM_CUST_PREF', function(config) {
			alert("ready to execute ajax request");
			var fm=config.formObj;
			var fmData=fm.getModelData();
			
			var params = {
						
						'INPUT_ACTION' : 'SUBMIT_CUSTOMER_PREFS',
						'INPUT_FUNCTION_CODE' : 'VSBLTY',
						'INPUT_PRODUCT' : 'CUSER',
						'INPUT_SUB_PRODUCT' : 'CUSER',
						'PRODUCT_NAME' : 'CUSER',
						'SUB_PRODUCT_NAME':'CUSER',
						'PAGE_CODE_TYPE':'CUST_PREF_PAGE',
						'CUST_DATA': fmData
						
					};
						
			cbx.ajax({
				params : params,
				beforeLoad: function(){
					alert("beforeLoad");
				},						
				afterLoad: function(){
					alert("afterLoad");
				},						
				success : function (resp){
					alert("AJAX_SUCCESS");
					alert(Ext.encode(resp));
				},
				failure: function(resp){
					alert("AJAX_FAILURE");
					console.log(resp);
					alert(Ext.encode(resp));
				},
				error : function() {
					alert("error");
				}
			});
			
			//createAjaxRequest(params,submitCustPrefSuccessHandler,submitCustPrefFailureHandler, fm,fmData);
			//return params;	
		});

	
	}

});

CFLR.registerListener("FORM_CUST_PREF", canvas.custPref);



