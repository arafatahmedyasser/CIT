/**
 * This file should be used to override default chart properties
 * provided by the framework.canvas.env.chart.option is a canvas environment variable
 * which should be used to override chart properties.   
 */

//canvas.env.chart.option.setChartLibFor("LINE","UD");

canvas.env.chart.options.setDefaults({
	defaultChartLib : 'FUSION',
	gestures : [],
	overrides : [{
		chartType : 'COLUMN2D',
		chartLib : "FUSION",
		legendPosition : 'bottom',
		paletteColors :"#6793C2",
		gestures: [{
			intent : "contextclick",
			gesture : "drilldown"
		},{
			intent : "drilldown",
			gesture : "contextclick"
		}
		]
	},
	{
		chartType : 'area2d',
		chartLib : "FUSION",
		legendPosition : 'bottom',
		gestures: [{
			intent : "contextclick",
			gesture : "drilldown"
		}]
	}]
});
function chartClickHandler(obj)
{
	alert(obj.graphViewId+canvas.env.chart.options.getIntentForGesture("drilldown","area2d"));
}

//canvas.env.chart.option.setIntentForGesture("singleClick","contextclick")
CWEH.registerHandler("REC_DUEDATE_CHART_WGT","contextclick",chartClickHandler);
CWEH.registerHandler("DAILY_SPEND_SUMM_WGT","contextclick",function(obj){
	alert(obj.graphViewId + canvas.env.chart.options.getIntentForGesture("drilldown","COLUMN2D"));
});

/**
 * This configuration sets the library to be used for rendering LINE chart.
 * With this configuration, the framework renders LINE chart using UD chart library.
 */

 