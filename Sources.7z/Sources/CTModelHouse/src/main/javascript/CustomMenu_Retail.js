/** These materials are confidential and proprietary to Intellect Design Arena Limited
 
 *  and no part of these materials should be reproduced, 

 * published, transmitted or distributed  in any form or by any means, 

 * electronic, mechanical, photocopying, recording or otherwise, or 

 * stored in any information storage or retrieval system of any nature 

 * nor should the materials be disclosed to third parties or used in any 

 * other manner for which this is not authorized, without the prior express 

 * written authorization of Intellect Design Arena Limited.

 * Copyright 2010. Intellect Design Arena Limited. All rights reserved.

 * Added for displaying Bulletin board message in FO.
 * 
 */
/**
 *
 <pre>
 -----------------------------------------------------------------------------------------------------
 CHANGE CODE		AUTHOR					DESCRIPTION								DATE
 -----------------------------------------------------------------------------------------------------
 CHG034_67641		Prabhakaran.D 		Buttetin Message scroll based on direction 			18-12-2013
 -----------------------------------------------------------------------------------------------------
</pre>
 */
Ext.namespace('iportal.workspace');
CMSHR.registerHandler(function() {	
	return new Ext.Panel({
		items : [ 
		         {
		        	 xtype: "panel",
		        	 html:"<div style='padding-top:0px;width:"+Math.floor((screen.availWidth/2)-10)+"px'>&nbsp;</div>",
		        	listeners :{
		        	'afterrender':function(){	
		   		    			var param = {
      						        "PRODUCT_CODE" : "CUSER",
		    						"PAGE_CODE_TYPE" : "BLTN",
		    						"INPUT_PRODUCT" : "CUSER",
		    						"INPUT_FUNCTION_CODE" : "VSBLTY",
		    						"INPUT_SUB_PRODUCT" : "CUSER",
		    						"PRODUCT_NAME" : "CUSER",
		    						"INPUT_ACTION" : "GET_BLTN_MSG"


		    		};
		   		    		//CHG034_67641 starts
		   		    		var marqueeDirection= 'left';	
		   		    		var rtlDirection = iportal.preferences.isLangDirectionRTL();
		   		    		if(rtlDirection){
		   		    			marqueeDirection= 'right';
		   		    		}
		   		    		//CHG034_67641 ends
		    				
		    				var that = this;
		    				Ext.Ajax.request({
		    					params : param,
		    					
		    					success : function(responseP, optionsP) {
		    					   var jsondataResponse = Ext.decode(responseP.responseText);
		    					   count=jsondataResponse.COUNT;
		    					   msgList =jsondataResponse.BULLETINMESSAGELIST;
		    						if (count != 0) {
		    							var msg="";
		    							for(var i=0;i<msgList.length;i++)
		    								{
		    								msg=msg+"<span class='marqueestar' >***</span>"+"&nbsp;"+msgList[i].WELCOMEMESSAGE+"&nbsp;"+"<span class='marqueestar' >***</span>"+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
		    								}
		    							that.el.dom.innerHTML="<div style='padding-top:0px;width:"+Math.floor((screen.availWidth/2)-10)+"px'><marquee direction='"+marqueeDirection+"'><span class='marqueetext'>"+msg+"</span></marquee></div>"; //CHG034_67641
		    						}
		    								    						
		    					},
		    					failure:function(resp)
		    					{
		    						
		    					}
		    				});
        		
		        		}
		        		
		        		
		        	}
		         },{
		        	 xtype: "panel",
		        	 cls:'zologCenter',
				 	 items : [new cbx.zologsearch.zologSearchBar().getSearchComp()]
		         }
		]
	});
}
);