/**
 * Copyright 2014. Intellect Design Arena Limited. All rights reserved. 
 * 
 * These materials are confidential and proprietary to Intellect Design Arena 
 * Limited and no part of these materials should be reproduced, published, transmitted
 * or distributed in any form or by any means, electronic, mechanical, photocopying, 
 * recording or otherwise, or stored in any information storage or retrieval system 
 * of any nature nor should the materials be disclosed to third parties or used in any 
 * other manner for which this is not authorized, without the prior express written 
 * authorization of Intellect Design Arena Limited.
 * 
 */

Ext.namespace('applnlayout.excard.header');
var viewWidth = Ext.getBody().getViewSize().width;
var scrollPanelWidth = 450;
if (viewWidth > 800) {
	scrollPanelWidth = parseInt(viewWidth) - 515;
}
canvas.applnlayout.excard.header.dock = function (){
				return new Ext.Panel({
				xtype : 'panel',
				height : 75,
				layout : 'table',
				cls : 'excardheaderworkspace',
				layoutConfig : {
					columns : 1,
					align : 'center',
					pack : 'center',
					align : 'middle'
				},
				width : scrollPanelWidth,
				items : [new cbx.panel.ButtonScrollingPanel({
					amountOfxScroll : 100,
					ButtonIndicator : false,
					width : scrollPanelWidth,
					height : 80,
					autoScroll : false,
					scrollCmp : [{
						xtype : 'excard-master-screen'
					}]
					})
					]
				});
};

//Ext.reg('excardheaderdock',canvas.applnlayout.excard.header.dock);
CLCR.registerCmp({"COMPONENT":"excardheaderdock","LAYOUT":"EXCARD"},canvas.applnlayout.excard.header.dock); 