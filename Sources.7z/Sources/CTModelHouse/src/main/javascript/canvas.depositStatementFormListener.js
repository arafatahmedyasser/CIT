cbx.ns("cbx.form.listeners");
cbx.form.listeners.CT_DEPOSIT_STAT_FORM = Class(cbx.Observable, {
	constructor : function(config) {
		this.fm = config.fm;
	},
	registerHandlers : function() {
		
		this.fm.registerHandler("cbxpreinitialize", function(fm,event,fieldName,value) {
			if(cbx.isEmpty(fm.getModelData())){
			return{			
				'DEPOSIT_ACC_NO':{
					value:'XXXXXX00143'
				},'ACCOUNT_NAME':{
					value:'Wal Mart Stores'
				},
				'DEPOSIT_TYPE':{
					value:'Call Deposit'
				},'BILYET_NO':{
					value:'12354'
				},
				'BRANCH':{
					value:'SAO PAULO'
				},'CURRENT_PRIN_AMT':{
					value:'400000.0'
				},
				'CURRENCY':{
					value:'USD'
				},'INTEREST_RATE':{
					value:'5%'
				},
				'MATURITY_DATE':{
					value:'09/12/2016'
				},'STATUS':{
					value:'Active'
				},
				'TENOR':{
					value:'24 Months'
				},'VALUE_DATE':{
					value:'09/12/2014'
				}	
				
			};
			}
			
		});
	}
		
	});
CFLR.registerListener("CT_DEPOSIT_STAT_FORM", cbx.form.listeners.CT_DEPOSIT_STAT_FORM);