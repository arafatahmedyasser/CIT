/**************************************************************************

 * These materials are confidential and proprietary to Intellect Design Arena Limited
 
 *  and no part of these materials should be reproduced, 

 * published, transmitted or distributed  in any form or by any means, 

 * electronic, mechanical, photocopying, recording or otherwise, or 

 * stored in any information storage or retrieval system of any nature 

 * nor should the materials be disclosed to third parties or used in any 

 * other manner for which this is not authorized, without the prior express 

 * written authorization of Intellect Design Arena Limited.

 *

 * Copyright 2010. Intellect Design Arena Limited. All rights reserved.

 * 
 * @author suman.debnath
 */
/**
 * DEPLOY_MODULE_ID: TODO: <Check with your lead for correct value>
 */


cbx.ns("canvas");

//canvas.appShortcut = Class(cbx.Observable, {
canvas.appShortcut = Ext.extend(Ext.util.Observable, {
	constructor : function(config) {
		this.fm = config.fm;
		//cbx.core.extend(this, config);
		canvas.appShortcut.superclass.constructor.call(this, config);
	},
	registerHandlers : function() {	
	var that=this;
	that.ix=0;
		this.fm.registerHandler("cbxpreinitialize",function(fm) {
			
		});

	   this.fm.registerHandler("cbxpremodelload",function(fm) {

	   });
       this.fm.registerHandler("cbxpostmodelload",function(fm,record) {

       });

	this.fm.registerHandler("cbxchange","ACC_TYPE",function(fm, event, fieldname, value){
	
	});
	
	this.fm.registerHandler("cbxclick","BTN_DEL", function(fm,event,fieldname,index,multiformId){
		
		try{
			var idx=that.ix;
			idx--;
		   	that.ix=idx;
		fm.removeAt(index,multiformId);
   	    }catch(e){
   	    }
   	   
	});
	
	this.fm.registerHandler("cbxclick","BTN_SUBMIT", function(fm,event,fieldname,params) {
 	   var accType= fm.model.getValue("ACC_TYPE");
 	  // var currDate =fm.model.getValue("CURR_DATE");
 	   var accNo=fm.model.getValue("ACC_NO");
 	   var accCur=fm.model.getValue("ACC_CCY");
 	   var txnTyp=fm.model.getValue("TXN_TYPE");
 	  var txnAmnt=fm.model.getValue("TXN_AMT");
 	  var txnDate=fm.model.getValue("TXN_DATE");
 	   var txnRef=fm.model.getValue("TXN_REF");
 	 var idx=that.ix;
 	  
 	  var md=fm.model.getModelData();
 	  if(md.MULTI_FORM_TXNDTLS){
 		  var multiData=md.MULTI_FORM_TXNDTLS;
 		 if(multiData['ACC_NO_MULTI'].length>0){
 			 idx=multiData['ACC_NO_MULTI'].length;
 		 }
 	  }else{
 		 fm.addNext("MULTI_FORM_TXNDTLS");
 	  }
 		
 	  
 	   if(idx>0){
 		  fm.addNext("MULTI_FORM_TXNDTLS"); 		  
 	   }
 	   fm.model.setValue("ACC_TYPE_MULTI",accType, "Y",idx,"MULTI_FORM_TXNDTLS");
 	   fm.model.setValue("ACC_NO_MULTI",accNo, "Y",idx,"MULTI_FORM_TXNDTLS");
 	   fm.model.setValue("ACC_CCY_MULTI",accCur, "Y",idx,"MULTI_FORM_TXNDTLS");
 	   fm.model.setValue("TXN_TYPE_MULTI",txnTyp, "Y",idx,"MULTI_FORM_TXNDTLS");
 	   fm.model.setValue("TXN_AMT_MULTI",txnAmnt, "Y",idx,"MULTI_FORM_TXNDTLS");
 	   fm.model.setValue("TXN_DATE_MULTI",txnDate, "Y",idx,"MULTI_FORM_TXNDTLS");
 	   fm.model.setValue("TXN_REF_MULTI",txnRef, "Y",idx,"MULTI_FORM_TXNDTLS");
 	  idx++;
 	  that.ix=idx;
 	  var clearList=["ACC_TYPE","ACC_NO","ACC_CCY","TXN_TYPE","TXN_AMT","TXN_DATE","TXN_REF"];
 	  for(var c=0; c<clearList.length; c++){
 		  fm.model.setValue(clearList[c],"");
 	  }
 	   
 	
    });
	
	CABR.registerHandler('MNL_TXN_SUBMIT', 'CANVAS_FORM_CNTNR_MANL_TXN', function(config) {
		//alert("ready to execute ajax request");
		var fm=config.formObj;
		var fmData=getFormttedModelData(fm.getModelData());
		
		
		
		var params = {
					
					'INPUT_ACTION' : 'SUBMIT_MANUAL_TXN',
					'INPUT_FUNCTION_CODE' : 'VSBLTY',
					'INPUT_PRODUCT' : 'CUSER',
					'INPUT_SUB_PRODUCT' : 'CUSER',
					'PRODUCT_NAME' : 'CUSER',
					'SUB_PRODUCT_NAME':'CUSER',
					'PAGE_CODE_TYPE':'MANUAL_TXN_PAGE',
					'JSON_TO_HASH_MAP_SUPPORT_FLAG':'JSON_DATA',
					'JSON_DATA':Ext.encode(fmData)
					
				};
					
			cbx.ajax({
				params : params,
										
				success : function (resp){
				var res66p=resp;
				},
				failure: function(resp){
					
					console.log(resp);
				
				}
			});
		});
	}

});

CFLR.registerListener("FORM_MANUAL_TXN", canvas.appShortcut);

var getFormttedModelData=function(modelData){
	
	
	var len=modelData.MULTI_FORM_TXNDTLS.ACC_NO_MULTI.length;
	var i=0;
	var formMd=[];
	for(i=0;i<len;i++){
		
		var Json={
					   'ACC_TYPE':modelData.MULTI_FORM_TXNDTLS.ACC_TYPE_MULTI[i],
				 	   'ACC_NO':modelData.MULTI_FORM_TXNDTLS.ACC_NO_MULTI[i],
				 	   'ACC_CCY':modelData.MULTI_FORM_TXNDTLS.ACC_CCY_MULTI[i],
				 	   'TXN_TYPE':modelData.MULTI_FORM_TXNDTLS.TXN_TYPE_MULTI[i],
				 	   'TXN_AMT':modelData.MULTI_FORM_TXNDTLS.TXN_AMT_MULTI[i],
				 	   'TXN_DATE':modelData.MULTI_FORM_TXNDTLS.TXN_DATE_MULTI[i],
				 	   'TXN_REF':modelData.MULTI_FORM_TXNDTLS.TXN_REF_MULTI[i]
					
		     };
		formMd.push(Json);
		}
	return formMd;
	
};


