/**
 * Copyright 2014. Intellect Design Arena Limited Limited. All rights reserved. 
 * 
 * These materials are confidential and proprietary to Intellect Design Arena Limited 
 * Limited and no part of these materials should be reproduced, published, transmitted
 * or distributed in any form or by any means, electronic, mechanical, photocopying, 
 * recording or otherwise, or stored in any information storage or retrieval system 
 * of any nature nor should the materials be disclosed to third parties or used in any 
 * other manner for which this is not authorized, without the prior express written 
 * authorization of Intellect Design Arena Limited Limited.
 * 
 */
package com.intellectdesign.modelhouse;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.intellectdesign.canvas.alert.handler.AlertConstants;
import com.intellectdesign.canvas.common.ExtReplyObject;
import com.intellectdesign.canvas.common.ReplyObject;
import com.intellectdesign.canvas.constants.common.JSPIOConstants;
import com.intellectdesign.canvas.database.DatabaseException;
import com.intellectdesign.canvas.event.Event;
import com.intellectdesign.canvas.event.EventDispatcher;
import com.intellectdesign.canvas.event.EventHandlerFrameworkConstants;
import com.intellectdesign.canvas.event.handler.HandlerException;
import com.intellectdesign.canvas.event.handler.IData;
import com.intellectdesign.canvas.exceptions.common.OnlineException;
import com.intellectdesign.canvas.exceptions.common.ProcessingErrorException;
import com.intellectdesign.canvas.handler.SimpleRequestHandler;
import com.intellectdesign.canvas.logger.Logger;
import com.intellectdesign.canvas.logging.PerformanceTimer;
import com.intellectdesign.canvas.properties.reader.PropertyReader;
import com.intellectdesign.canvas.value.CanvasRequestVO;
import com.intellectdesign.modelhouse.txn.PaymentInstruction;
import com.intellectdesign.modelhouse.txn.TxnData;

/**
 * 
 * @Version 1.0
 */
public class TxnRequestHandler extends SimpleRequestHandler {

	private static PropertyReader mReader = new PropertyReader("txn_properties");
	private static PropertyReader eventReader = new PropertyReader(
			"CTevent_properties");

	public ReplyObject process(CanvasRequestVO request)
			throws ProcessingErrorException {
		logger.ctinfo("CTTXN0006");
		PerformanceTimer perfTimer = new PerformanceTimer();

		ExtReplyObject reply = new ExtReplyObject();

		logger.ctdebug("CTTXN0007");
		// Vector inputVector = (Vector) obj;

		String action = request.getActionCode();
		// reply.headerMap = new HashMap();
		// String gcifNo = (String)
		// inputVector.get(TIConstants.GCIF_INDEX_IN_VECTOR);
		String userNo = request.getUserContext().getUserNumber();
		HashMap map = (HashMap) request.getRequestData();

		PaymentInstruction paymentInstruction = new PaymentInstruction();
		if ("SUBMIT".equals(action) || "DRAFT".equals(action)) {
			logger.ctdebug("CTTXN0008");
			boolean isRefNoAvailable = false;

			String refNo = (String) map.get(REF_NO);
			if (refNo != null && !refNo.isEmpty()) {
				map.put(REF_NO, refNo);
				isRefNoAvailable = true;
			} else {
				refNo = getNewRefNumber();
				map.put(REF_NO, refNo);
			}
			map.put("USER_NO", userNo);
			TxnData txnData = (TxnData) formatTxnData(map, action);
			// txnData.setUserNo(userNo);
			try {

				logger.ctdebug("CTTXN0009");

				if (isRefNoAvailable) {
					paymentInstruction.saveTxnData(txnData, refNo);
				} else {
					paymentInstruction.insertTxnData(txnData);
				}
				if ("SUBMIT".equalsIgnoreCase(action)) {
					callRaiseEvent(request, map);
				}
				HashMap successMap = new HashMap();
				successMap.put("STATUS", "SUCCESS");
				successMap.put(REF_NO, refNo);

				reply = constructSuccessReply(successMap);

				logger.ctdebug("CTTXN0010");
			} catch (DatabaseException dbException) {
				logger.cterror("CTTXN0011", dbException,
						mReader.retrieveProperty("TXN0001"));
				throw new ProcessingErrorException("TXN0001",
						mReader.retrieveProperty("TXN0001"));
			}

		} else if ("REJECT_TXN".equals(action) || "AUTH_TXN".equals(action)) {
			logger.ctdebug("CTTXN0032");
			String refNo = (String) map.get("REFERENCE_NO");
			if (refNo != null && !refNo.isEmpty()) {
				map.put(REF_NO, refNo);
			} else {
				logger.cterror("CTTXN0011", new DatabaseException(),
						mReader.retrieveProperty("TXN0006"));
				throw new ProcessingErrorException("TXN0006",
						mReader.retrieveProperty("TXN0006"));
			}
			boolean isUpdated = false;
			try {
				if ("REJECT_TXN".equals(action))
					isUpdated = paymentInstruction.rejectTxn(map);
				else
					isUpdated = paymentInstruction.authorizeTxn(map);
				if (isUpdated) {
					callRaiseEvent(request, map);
					HashMap successMap = new HashMap();
					successMap.put("STATUS", "SUCCESS");
					successMap.put(REF_NO, refNo);
					reply = constructSuccessReply(successMap);
				}
			} catch (DatabaseException dbException) {
				logger.cterror("CTTXN0011", dbException,
						mReader.retrieveProperty("TXN0006"));
				throw new ProcessingErrorException("TXN0006",
						mReader.retrieveProperty("TXN0006"));
			}
			logger.ctdebug("CTTXN0033");

		} else if ("DELETE_TXN".equals(action)) {
			logger.ctdebug("CTTXN0039");
			String refNo = (String) map.get("REFERENCE_NO");
			if (refNo == null || refNo.trim().length() < 1) {
				logger.cterror("CTTXN0039", new DatabaseException(),
						mReader.retrieveProperty("TXN0008"));
				throw new ProcessingErrorException("TXN0008",
						mReader.retrieveProperty("TXN0008"));
			}
			boolean isUpdated = false;
			try {
				isUpdated = paymentInstruction.deleteTxn(refNo);
				if (isUpdated) {
					HashMap successMap = new HashMap();
					successMap.put("STATUS", "SUCCESS");
					successMap.put(REF_NO, refNo);
					reply = constructSuccessReply(successMap);
				}
			} catch (DatabaseException dbException) {
				logger.cterror("CTTXN0039", dbException,
						mReader.retrieveProperty("TXN0008"));
				throw new ProcessingErrorException("TXN0008",
						mReader.retrieveProperty("TXN0008"));
			}
			logger.ctdebug("CTTXN0040");
		} else if ("GET_BENE_DTLS".equals(action)) {

			logger.ctdebug("CTTXN0030");
			String beneAccNo = (String) map.get("BENE_ACC_NO");

			HashMap beneDtlsMap = null;
			try {
				beneDtlsMap = paymentInstruction.getBeneDtls(beneAccNo);
				if (beneDtlsMap != null) {
					reply = constructSuccessReply((HashMap) ((List) beneDtlsMap
							.get("BENE_ACC_NO")).get(0));

				}
			} catch (DatabaseException dbException) {
				logger.cterror("CTTXN0011", dbException,
						mReader.retrieveProperty("TXN0004"));
				throw new ProcessingErrorException("TXN0004",
						mReader.retrieveProperty("TXN0004"));
			}

			logger.ctdebug("CTTXN0031");

		} else if ("GET_ACC_DTLS".equals(action)) {

			logger.ctdebug("CTTXN0032");
			String accNo = (String) map.get("ACCOUNT_NO");

			HashMap accDtlsMap = null;

			try {
				accDtlsMap = paymentInstruction.getAccDtls(accNo);
				if (accDtlsMap != null) {
					reply = constructSuccessReply((HashMap) ((List) accDtlsMap
							.get("ACCOUNT_NO")).get(0));
				}
			} catch (DatabaseException dbException) {
				logger.cterror("CTTXN0011", dbException,
						mReader.retrieveProperty("TXN0005"));
				throw new ProcessingErrorException("TXN0005",
						mReader.retrieveProperty("TXN0005"));
			}
		} else if ("GET_TXN".equals(action)) {

			logger.ctdebug("CTTXN0041");
			String refNo = (String) map.get("REFERENCE_NO");

			if (refNo == null || refNo.trim().length() < 1) {
				logger.cterror("CTTXN0042", new DatabaseException(),
						mReader.retrieveProperty("TXN0009"));
				throw new ProcessingErrorException("TXN0009",
						mReader.retrieveProperty("TXN0009"));
			}

			HashMap accDtlsMap = null;
			try {
				accDtlsMap = (HashMap) paymentInstruction.getTxnDtls(refNo);
				if (accDtlsMap != null) {
					reply = constructSuccessReply(accDtlsMap);
				}
			} catch (DatabaseException dbException) {
				logger.cterror("CTTXN0043", dbException,
						mReader.retrieveProperty("TXN0010"));
				throw new ProcessingErrorException("TXN0010",
						mReader.retrieveProperty("TXN0010"));
			}
		}
		perfTimer.endTimer();

		logger.ctinfo("CTTXN0044");
		return reply;
	}

	private ExtReplyObject constructSuccessReply(HashMap respMap) {

		ExtReplyObject reply = new ExtReplyObject();
		reply.headerMap = new HashMap();

		reply.headerMap.put("REPLY_TYPE", "SUCCESS");

		if (respMap != null) {
			reply.headerMap.put("JSON_MAP", respMap);
		}

		return reply;
	}

	/*
	 * private ExtReplyObject constructErrorReply(final String errorCode,final
	 * String errorMsg){
	 * 
	 * ExtReplyObject reply = new ExtReplyObject(); reply.headerMap = new
	 * HashMap();
	 * 
	 * reply.headerMap.put("ERR_CODE", errorCode);
	 * reply.headerMap.put("REPLY_TYPE","ERROR");
	 * reply.headerMap.put("ERR_MESS", errorMsg); reply.headerMap.put("SUCCESS",
	 * false);
	 * 
	 * return reply; }
	 */

	/**
	 * Helper method to get the new reference number from the db sequence.
	 * 
	 * @return long the newly generated Reference number
	 * @exception OnlineException
	 *                Thrown if any error occurs while fetching the next valye
	 *                from sequence
	 */
	protected String getNewRefNumber()  {

		String refNo = null;
		logger.ctinfo("CTTXN0015");
		// refNo = UUID.randomUUID().toString();
		refNo = "T".concat(String.valueOf(new Date().getTime()));
		logger.ctinfo("CTTXN0016", refNo);
		return refNo;
	}

	protected IData formatTxnData(HashMap mapData, String action) {
		logger.ctinfo("CTTXN0013");
		TxnData txnData = new TxnData();

		String refNo = (String) mapData.get("REFERENCE_NO");
		txnData.setReferenceNo(refNo);

		txnData.setAccNo((String) mapData.get("ACC_NO"));
		txnData.setAccType((String) mapData.get("ACC_TYPE"));
		txnData.setAccCcy((String) mapData.get("ACC_CCY"));
		txnData.setAccName((String) mapData.get("ACC_NAME"));
		txnData.setAccBranch((String) mapData.get("ACC_BRANCH"));

		// BigDecimal transactionAmt = new BigDecimal((Float)
		// (mapData.get("TRANSFERED_AMT"))).setScale(2, RoundingMode.HALF_UP);
		txnData.setTransactionAmt((String) mapData.get("TRANSACTION_AMT"));
		String tansactionType = (String) mapData.get("TRAN_TYPE") != null ? (String) mapData
				.get("TRAN_TYPE") : "Domestic Fund Transfer";
		txnData.setTranType(tansactionType);
		txnData.setTranDate((String) mapData.get("TRAN_DATE"));
		txnData.setCreateDate((String) mapData.get("CREATED_DATE"));
		txnData.setCreatedBy((String) mapData
				.get(JSPIOConstants.INPUT_USER_NAME));
		txnData.setBeneAccNo((String) mapData.get("BENE_ACC_NO"));
		txnData.setBeneCcy((String) mapData.get("BENE_CCY"));
		txnData.setBeneName((String) mapData.get("BENE_NAME"));
		txnData.setBeneBank((String) mapData.get("BENE_BANK"));
		txnData.setBeneCity((String) mapData.get("BENE_CITY"));
		txnData.setBeneBranch((String) mapData.get("BENE_BRANCH"));
		txnData.setBeneAddress((String) mapData.get("BENE_ADDRESS"));
		if ("SUBMIT".equals(action)) {
			txnData.setStatus("RA");
		} else if ("DRAFT".equals(action)) {
			txnData.setStatus("DR");
		}
		txnData.setUdf("");
		txnData.setUserNo((String) mapData.get("USER_NO"));
		// String channelId = ChannelUtils.getDeviceType((String)
		// mapData.get("deviceType"));
		// txnData.setChannelId(channelId);
		logger.ctinfo("CTTXN0014");
		return txnData;
	}

	private void callRaiseEvent(CanvasRequestVO request, HashMap inputMap) throws ProcessingErrorException{
		HashMap<String, Object> alertData = new HashMap<String, Object>();
		HashMap<String, Object> eventData = new HashMap<String, Object>();
		String action = request.getActionCode();
		Event event;
		event = Event.getEventFor("CUSER","CUSER","VSBLTY",action);
		logger.ctdebug("CTVDF00155", event);

		alertData.put(EventHandlerFrameworkConstants.FLD_GCIF, request
				.getUserContext().getOwningGCIF());
		alertData.put(EventHandlerFrameworkConstants.FLD_USER_NO, request
				.getUserContext().getUserNumber());
		alertData.put(JSPIOConstants.INPUT_CHANNEL_ID, request
				.getSessionContext().getChannelId());
		alertData.put(REF_NO, inputMap.get(REF_NO));
		List recipientList = new ArrayList();
		if ("SUBMIT".equalsIgnoreCase(action)) {
			recipientList = getRecipientList((String) inputMap
					.get("REFERENCE_NO"));
		} else if ("AUTH_TXN".equalsIgnoreCase(action)
				|| "REJECT_TXN".equalsIgnoreCase(action)) {
			recipientList.add(getMakerUserNo((String) inputMap
					.get("REFERENCE_NO")));
		}
		Set set = new HashSet();
		set.addAll(recipientList);
		List recipients = new ArrayList();
		recipients.addAll(set);
		alertData.put(AlertConstants.RECIPIENTS_KEY, recipients);
		eventData.putAll(alertData);
		eventData.put(AlertConstants.ALERT_DATA_MAP, alertData);
		eventData.put(AlertConstants.LOCALE_KEY, "en_US");
		EventDispatcher eventDispatcher = EventDispatcher.getInstance();
		try {
			eventDispatcher.raiseEvent(event, eventData);
			logger.ctinfo("CTTXN0014");
		} catch (HandlerException e) {
			String propName = "TXN0011";
			if ("SUBMIT".equalsIgnoreCase(action)) {
				propName = "TXN0012";
			} else if ("AUTH_TXN".equalsIgnoreCase(action)) {
				propName = "TXN0013";
			}
			if ("REJECT_TXN".equalsIgnoreCase(action)) {
				propName = "TXN0014";
			}
			logger.cterror("CTTXN0011", e, mReader.retrieveProperty(propName));
			throw new ProcessingErrorException(propName,mReader.retrieveProperty(propName));
		}
	}

	/**
	 * This method fetch the all the user-no's except the maker
	 * 
	 * @param refNo
	 * @return
	 * @throws OnlineException
	 */
	private List getRecipientList(String refNo) throws ProcessingErrorException {
		PaymentInstruction paymentInstruction = new PaymentInstruction();
		List recepientList = null;
		try {
			List tempList = paymentInstruction.getRecipients(refNo);
			recepientList = new ArrayList();
			String key = "OD_USER_NO";
			for (int i = 0; i < tempList.size(); i++) {
				Map tmpMap = (HashMap) tempList.get(i);
				recepientList.add(tmpMap.get(key));
			}
		} catch (DatabaseException dbException) {
			logger.cterror("CTTXN0039", dbException,
					mReader.retrieveProperty("TXN0015"));
			throw new ProcessingErrorException("TXN0015",
					mReader.retrieveProperty("TXN0015"));
		}
		return recepientList;
	}

	private String getMakerUserNo(String refNo) throws ProcessingErrorException {
		String maker = null;
		PaymentInstruction paymentInstruction = new PaymentInstruction();
		try {
			Map makerMap = paymentInstruction.getMaker(refNo);
			maker = (String) makerMap.get("USER_NO");
		} catch (DatabaseException dbException) {
			logger.cterror("CTTXN0039", dbException,
					mReader.retrieveProperty("TXN0016"));
			throw new ProcessingErrorException("TXN0015",
					mReader.retrieveProperty("TXN0016"));
		}
		return maker;
	}

	private static final String REF_NO = "REFERENCE_NO";
	private static final int DEVICETYPE_INDEX_IN_VECTOR = 10;
	private static final Logger logger = Logger
			.getLogger(TxnRequestHandler.class);

}
