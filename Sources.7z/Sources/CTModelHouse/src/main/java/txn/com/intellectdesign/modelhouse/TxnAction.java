package com.intellectdesign.modelhouse;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.intellectdesign.canvas.action.PortletAction;
import com.intellectdesign.canvas.common.ReplyObject;
import com.intellectdesign.canvas.constants.common.FrameworkConstants;
import com.intellectdesign.canvas.exceptions.action.OrbiActionException;
import com.intellectdesign.canvas.exceptions.common.ProcessingErrorException;
import com.intellectdesign.canvas.logger.Logger;
import com.intellectdesign.canvas.login.sessions.SessionInfo;
import com.intellectdesign.canvas.web.config.ActionMap;



public class TxnAction extends PortletAction
{

	/**
	 * Transaction's action an implemention.
	 * 
	 * @param action - The action string associated with this request
	 * @param sessionInfo - The SessionInfo object
	 * @param actionMap - The ActionMap object
	 * @param requestParams - This is a map which has the values passes from the request converted to a map using the
	 *            RequestParamsHandler class
	 * @param request - The request itself
	 * @return ReplyObject - the response for the action
	 * @throws OrbiActionException
	 */
	@Override
	public ReplyObject executePortletActionUsing(String action, SessionInfo sessionInfo, ActionMap actionMap,
			Map requestParams, HttpServletRequest request) throws OrbiActionException
	{
		logger.ctinfo("CTTXN0001");
		
		ReplyObject reply = null;
		try
		{
			logger.ctdebug("CTTXN0002");

			/*if ("SUBMIT".equals(action) || "DRAFT".equals(action))
			{*/				
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);
			/*}*/

			logger.ctdebug("CTTXN0003");
			
		} catch (ProcessingErrorException procExcep)
		{
			logger.cterror("CTTXN0004");

			throw new OrbiActionException(FrameworkConstants.ERROR_SYSTEM_ERROR,
					"Received processing error while handling action - '" + action + "in TxnAction action",
					procExcep);
		}

		logger.ctinfo("CTTXN0005");
		return reply;
	}

	private static final Logger logger = Logger.getLogger(TxnAction.class);
}
