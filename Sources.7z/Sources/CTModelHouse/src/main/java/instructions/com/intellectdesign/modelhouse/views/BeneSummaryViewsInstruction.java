package com.intellectdesign.modelhouse.views;

import java.util.HashMap;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.ListViewsInstruction;

public class BeneSummaryViewsInstruction extends ListViewsInstruction
{

	@Override
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException
	{
		HashMap<String, String> mapViewSpecificFilter = new HashMap<String, String>();

		return mapViewSpecificFilter;
	}

	@Override
	protected String getUniqueSortFieldName()
	{
		// TODO Auto-generated method stub
		return "BENE_ID";
	}

	@Override
	protected String getUniqueSortFieldOrder()
	{
		// TODO Auto-generated method stub
		return "DESC";
	}
	protected String getUniqueSortColumnName(){
		return "BENE_ID";
	}
	@Override
	protected HashMap<String, String> getSortColumnMap()
	{
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		sortColumnReturnMap.put("BENE_ID", "BENE_ID");
		sortColumnReturnMap.put("BENE_NAME", "BENE_NAME");
		sortColumnReturnMap.put("BENE_BENE_ACC_NO", "BENE_ACC_NO");
		sortColumnReturnMap.put("CURRENCY", "CURRENCY");
		sortColumnReturnMap.put("BANK_NAME", "BANK_NAME");
		sortColumnReturnMap.put("PAYMENT_TYPE", "PAYMENT_TYPE");
		sortColumnReturnMap.put("BRANCH_NAME", "BRANCH_NAME");
		return sortColumnReturnMap;
	}
	
}
