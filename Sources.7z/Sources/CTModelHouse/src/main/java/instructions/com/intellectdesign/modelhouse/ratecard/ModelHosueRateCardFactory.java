/**
 * Copyright 2014. Intellect Design Arena Limited Limited. All rights reserved. 
 * 
 * These materials are confidential and proprietary to Intellect Design Arena Limited 
 * Limited and no part of these materials should be reproduced, published, transmitted
 * or distributed in any form or by any means, electronic, mechanical, photocopying, 
 * recording or otherwise, or stored in any information storage or retrieval system 
 * of any nature nor should the materials be disclosed to third parties or used in any 
 * other manner for which this is not authorized, without the prior express written 
 * authorization of Intellect Design Arena Limited Limited.
 * 
 */
package com.intellectdesign.modelhouse.ratecard;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.exceptions.common.BaseException;
import com.intellectdesign.canvas.ratecard.IRateCard;
import com.intellectdesign.canvas.ratecard.IRateCardFactory;

/**
 *
 * @Version 1.0
 */
/**
 * This is a factory that helps create a Rate Card instance for the given rate card details. The rate card is provided
 * as an instance of IRateCard interface.
 */
public class ModelHosueRateCardFactory implements IRateCardFactory 
{
	/**
	 * The default constructor for this class.
	 */
	public ModelHosueRateCardFactory()
	{

	}

	/**
	 * This is the factory method for getting the list of all rate cards that are present in the system. This includes
	 * all bank rate cards as well as any customer defined rate cards.
	 * 
	 * @param userNo The user number of the user for whom the list is required
	 * @param gcif The GCIF of the user for whom the list is required
	 * @return The array of all rate cards. The order of rate cards is the System rate cards first and then any customer
	 *         defined ones
	 */
	public IRateCard[] getAllRateCards(String userNo, String gcif) throws BaseException
	{
		IRateCard[] allRateCards = null;

		//TODO : Need to wrtie logic to get the rate cards.
		
		return allRateCards;
	}

	/**
	 * This is the factory method that helps create a rate card for the given rate card id If the rate card Id is same
	 * as the GCIF, this means that this is a customer rate card. So the Rate card instance provided is that from
	 * customer rate card.
	 * 
	 * @param rateCardId The rate card id for which rate card needs to be created
	 * @param userNo The user number
	 * @param gcif The GCIF to which the user belongs to
	 * @param targetCurrency The Currency to which all conversions are to be done.
	 * @return The rate card for the rate card id provided. If rate card is not found, then this returns null.
	 */
	public IRateCard getRateCard(String rateCardId, String userNo, String gcif, String targetCurrency)
			throws BaseException
	{
		LOGGER.info("getRateCard called with RateCard ID: " + rateCardId);
		IRateCard rateCard = null;
		if (rateCardId == null)
		{
			LOGGER.error("Invalid Input provided to factory. RateCard ID cannot be null");
			throw new IllegalArgumentException("rateCardId cannot be null");
		}

		//TODO : Need to write the 
		
		return rateCard;
	}

	/**
	 * This is the factory method that helps create a rate card for the given rate card id If the rate card Id is same
	 * as the GCIF, this means that this is a customer rate card. So the Rate card instance provided is that from
	 * customer rate card.
	 * 
	 * @param rateCardId The rate card id for which rate card needs to be created
	 * @param userNo The user number
	 * @param gcif The GCI	F to which the user belongs to
	 * @param targetCurrency The Currency to which all conversions are to be done.
	 * @return The rate card for the rate card id provided. If rate card is not found, then this returns null.
	 */
	public IRateCard getDefaultRateCard()
	{
		String rateCardId = "BR0001";
		LOGGER.info("getDefaultBankRateCard(): Default rate card configured is : '" + rateCardId + "'");
		IRateCard rateCard = new ModelHouseRateCard();

		return rateCard;
	}
	
	private static Logger LOGGER = Logger.getLogger(ModelHosueRateCardFactory.class);
}
