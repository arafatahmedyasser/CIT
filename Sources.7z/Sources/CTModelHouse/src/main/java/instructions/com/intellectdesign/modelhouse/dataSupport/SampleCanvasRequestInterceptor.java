package com.intellectdesign.modelhouse.dataSupport;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.intellectdesign.canvas.action.ICanvasRequestInterceptor;
import com.intellectdesign.canvas.exceptions.common.ProcessingErrorException;
import com.intellectdesign.canvas.login.sessions.SessionInfo;


public class SampleCanvasRequestInterceptor implements ICanvasRequestInterceptor
{

	@Override
	public Map interceptRequest(HttpServletRequest request, SessionInfo sessionInfo, String txnCode, Map requestParams)
			throws ProcessingErrorException
	{
		/**
		 * UDF1 to UDF10 and GEO_LOCATION values are need to be set by the implementation team
		 * UDF - User defined field
		 */
		requestParams.put("UDF1", "Custom Values");
		return requestParams;
	}

}
