
/**
COPYRIGHT NOTICE

Copyright 2012 Intellect Design Arena Limited. All rights reserved.

These materials are confidential and proprietary to
Intellect Design Arena Limited and no part of these materials should
be reproduced, published, transmitted or distributed in any form or
by any means, electronic, mechanical, photocopying, recording or
otherwise, or stored in any information storage or retrieval system
of any nature nor should the materials be disclosed to third parties
or used in any other manner for which this is not authorized, without
the prior express written authorization of Intellect Design Arena Limited.
*/

package com.intellectdesign.modelhouse.views;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.tree.ITreeNode;
/**
 * @author papiya.bhowmik
 * This class is responsible for setting the values for tree view
 */
public class TreeNode implements ITreeNode {
/**
 * setting serialVersionUID as 1L.
 */
private static final long serialVersionUID = 1L;
/**
 * declaring String reportId.
 */
private String itemId;
/**
 * declaring String reportName.
 */
private String itemDesc;
/**
 * declaring String parentReportId.
 */
private String text;
//IR_ENHANCEMENTS_001 Starts
/**
 * declaring String reportProdCode.
 */
private String parent_id;
/**
 * declaring List childNodes.
 */
private List<TreeNode> childNodes;
/**
 * creating instance of ReportTreeNode.
 */
public TreeNode() {
childNodes = new ArrayList<TreeNode>();
}

/**
 * @param map Map<String, String>
 * This method sets the value of the tree nodes.
 */
public TreeNode(final Map<String, String> map) {
	 
	setItemId(map.get("ITEM_ID"));
	setItemDesc(map.get("ITEM_DESC"));
	setData(map.get("DATA"));
	setParent_id(map.get("PARENT_ID"));
    childNodes = new ArrayList<TreeNode>();
	 
}

/**
 * @return the itemId
 */
public String getItemId()
{
	return itemId;
}
/**
 * @param itemId the itemId to set
 */
public void setItemId(String itemId)
{
	this.itemId = itemId;
}
/**
 * @return the itemDesc
 */
public String getItemDesc()
{
	return itemDesc;
}
/**
 * @param itemDesc the itemDesc to set
 */
public void setItemDesc(String itemDesc)
{
	this.itemDesc = itemDesc;
}
/**
 * @return the data
 */
public String getData()
{
	return text;
}
/**
 * @param data the data to set
 */
public void setData(String text)
{
	this.text = text;
}
/**
 * @return the parent_id
 */
public String getParent_id()
{
	return parent_id;
}
/**
 * @param parent_id the parent_id to set
 */
public void setParent_id(String parent_id)
{
	this.parent_id = parent_id;
}
public HashMap getTreeNodeAsMap(){
	 
	HashMap treeMenu = new HashMap();
	treeMenu.put("id", getItemId());
	treeMenu.put("ID", getItemId());
	treeMenu.put("detail", getItemDesc());
	treeMenu.put("text", getData());
	treeMenu.put("NAME", getData());
	treeMenu.put("PARENT_ID", getParent_id());
	List childMap = new ArrayList();
	if (childNodes != null && !childNodes.isEmpty()){
		for (TreeNode mNode : childNodes)
		{
			childMap.add(mNode.getTreeNodeAsMap());
		}
	}
	treeMenu.put("CHILDREN", childMap);
	treeMenu.put("children", childMap);
	 
	return treeMenu;	
}
/**
 * @return sb.toString()
 * This method is responsible for appending child nodes to its parent node
 */
public final String toJSONString() {
	 
	StringBuffer sb = new StringBuffer();
	
	
	StringBuffer sb1 = new StringBuffer();
	sb1.append("itemId:"+getItemId() +",");
	sb1.append("itemDesc:"+getItemDesc() +",");
	sb1.append("text:"+getData() +",");
	sb1.append("parentId:"+getParent_id() +",");
	for (TreeNode mn : childNodes) {
		sb1.append(mn.toJSONString() + ",");
	}
	String nodes = sb1.toString();
	if (nodes.length() > 0) {
		nodes = nodes.substring(0, nodes.length() - 1);
	}
	sb.append("children:" + "[" + nodes + "]");
	 
	return "{" + sb.toString() + "}";
}
/**
 * @param mn ReportTreeNode
 */
public final void addChildNode(final TreeNode mn) {
    childNodes.add(mn);
}
/**
 * @return childNodes
 */

public List<TreeNode> getChildNodes() {
	return childNodes;
}
/**
 * @param childnodes List<ReportTreeNode>
 */
public void setChildNodes(List<TreeNode> childNodes) {
	this.childNodes = childNodes;
}
private Logger logger = Logger.getLogger(TreeNode.class);
}
