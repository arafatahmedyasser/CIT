package com.intellectdesign.modelhouse.alerts;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.constants.listviews.ListViewConstants;
import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.logging.PerformanceTimer;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionConstants;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;

public class AlertViewInstruction extends AlertsAndNotificationsListViewInstruction
{
	private Logger logger = Logger.getLogger(AlertViewInstruction.class);

	/**
	 * This method gives the channel name
	 * 
	 * @return The channel name
	 */
	protected String getChannel()
	{
		return "INBOX";
	}

	/**
	 * This method provides the map of the sortable columns to the view definition columns.
	 * 
	 * @return strListViewColumnMap
	 */
	protected HashMap<String, String> getSortColumnMap()
	{
		HashMap<String, String> strListViewColumnMap = new HashMap<String, String>();
		strListViewColumnMap.put(AlertListView.ALERT_MESSAGES, AlertListView.ALERT_MESSAGES);
		strListViewColumnMap.put(AlertListView.STR_MESSAGE_DURATION, AlertListView.STR_MESSAGE_DURATION);
		strListViewColumnMap.put(AlertListView.SEVERITY, AlertListView.SEVERITY);
		strListViewColumnMap.put(AlertListView.SUB_PRODUCT_CODE, AlertListView.SUB_PRODUCT_CODE);
		strListViewColumnMap.put(AlertListView.ACTION, AlertListView.ACTION);
		strListViewColumnMap.put(AlertListView.STR_MESSAGE_TS, AlertListView.STR_MESSAGE_TS); // CBXQ313U11
		strListViewColumnMap.put(AlertListView.SUB_PRODUCT_CODE_DISPVAL, AlertListView.SUB_PRODUCT_CODE_DISPVAL); // CBXQ313U11

		return strListViewColumnMap;
	}

	/**
	 * This method provides the unique sort field name for this view instruction class.
	 * 
	 * @return The unique sort field name for this view
	 */
	protected String getUniqueSortFieldName()
	{
		return AlertListView.DEFAULT_SORTING_FIELD_ALERT;
	}

	/**
	 * This method provides sorting order for the unique sort field name.
	 * 
	 * @return The sort order for the unique sort field name.
	 */
	protected String getUniqueSortFieldOrder()
	{
		return AlertListView.DEFAULT_SORTING_ORDER;
	}

	/**
	 * This method forms the view specific filters from the input params
	 * 
	 * @param hmInputParams input params in HashMap
	 * @param dataEntitlements
	 * @return alertListViewSpecificFilter view specific filters set.
	 * @throws ViewDefinitionException Exception
	 */
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException
	{

		HashMap alertListViewSpecificFilter = null;

		PerformanceTimer perfTimer = new PerformanceTimer();
		perfTimer.startTimer("AlertViewInstruction.getViewSpecificFilters - for entitled and header account");

		alertListViewSpecificFilter = new HashMap();

		alertListViewSpecificFilter.put(ListViewConstants.INPUT_USER_NO,
				hmInputParams.get(ListViewConstants.INPUT_USER_NO));
		alertListViewSpecificFilter.put(ListViewConstants.INPUT_GCIF, hmInputParams.get(ListViewConstants.INPUT_GCIF));
		alertListViewSpecificFilter.put(ListViewConstants.INPUT_LANGUAGE_ID,
				hmInputParams.get(ListViewConstants.INPUT_LANGUAGE_ID));
		alertListViewSpecificFilter.put(IS_NOTIFICATION, ViewDefinitionConstants.VAL_BOOL_NO);

		perfTimer.endTimer();

		return alertListViewSpecificFilter;

	}

	public static String IS_NOTIFICATION = "IS_NOTIFICATION";
}
