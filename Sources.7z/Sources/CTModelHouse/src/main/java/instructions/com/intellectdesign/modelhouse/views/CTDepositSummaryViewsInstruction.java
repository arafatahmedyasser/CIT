/**
    COPYRIGHT NOTICE

    Copyright 2011 Intellect Design Arena Limited. All rights reserved.

    These materials are confidential and proprietary to 
    Intellect Design Arena Limited and no part of these materials should
    be reproduced, published, transmitted or distributed in any form or
    by any means, electronic, mechanical, photocopying, recording or 
    otherwise, or stored in any information storage or retrieval system
    of any nature nor should the materials be disclosed to third parties
    or used in any other manner for which this is not authorized, without
    the prior express written authorization of Intellect Design Arena Limited.
*/
package com.intellectdesign.modelhouse.views;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinition;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.ListViewsInstruction;

/**
 * @author prabhakaran.d
 *
 */
public class CTDepositSummaryViewsInstruction extends ListViewsInstruction
{
	public CTDepositSummaryViewsInstruction(){
		LOGGER.debug("CTDepositSummaryViewsInstruction created...");
		
	} 
	/**
	 * Intended to frame the filters for the VDF
	 * 
	 * @param HashMap -- hminputParams
	 * @param DataEntitlements -- dataEntitlements
	 * @return HashMap
	 * @throws ViewDefinitionException 
	 * 
	 */
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException {
		
		HashMap<String, String> mapViewSpecificFilter = new HashMap<String, String>();
		
		

		return mapViewSpecificFilter;
	}

	/**
	 * Creates a map for the view metadata
	 */
	protected HashMap<String, String> getSortColumnMap() {
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		sortColumnReturnMap.put("DEPOSIT_ACC_NO", "DEPOSIT_ACC_NO");
		sortColumnReturnMap.put("ACCOUNT_NAME", "ACCOUNT_NAME");
		sortColumnReturnMap.put("BRANCH", "BRANCH");
		sortColumnReturnMap.put("BILYET_NO", "BILYET_NO");
		sortColumnReturnMap.put("DEPOSIT_TYPE", "DEPOSIT_TYPE");
		sortColumnReturnMap.put("VALUE_DATE", "VALUE_DATE");
		sortColumnReturnMap.put("MATURITY_DATE", "MATURITY_DATE");
		sortColumnReturnMap.put("CURRENCY", "CURRENCY");
		sortColumnReturnMap.put("CURRENT_PRIN_AMT", "CURRENT_PRIN_AMT");
		sortColumnReturnMap.put("TENOR", "TENOR");
		sortColumnReturnMap.put("INTEREST_RATE", "INTEREST_RATE");
		sortColumnReturnMap.put("STATUS", "STATUS");
		
		return sortColumnReturnMap;
	}

	/**
	 * Returns the field name for sorting
	 */
	protected String getUniqueSortFieldName() {
		return "DEPOSIT_ACC_NO";
	}

	/**
	 * Returns the sorting order
	 */
	protected String getUniqueSortFieldOrder() {
		return "DESC";
	}

	
	protected String getUniqueSortColumnName(){
		return "DEPOSIT_ACC_NO";
	}
	
	
	protected Map<String,String> retrieveColumnDisplayMap(List listViewData, ViewDefinition viewDefinition, HashMap mapInputParams){
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		
		sortColumnReturnMap.put("DEPOSIT_ACC_NO","Deposit Account Number");
		
		return sortColumnReturnMap;				
	}
	
	
	/**
	 * Instance for Logger
	 */

	static final Logger LOGGER = Logger.getLogger(CTDepositSummaryViewsInstruction.class);
}
