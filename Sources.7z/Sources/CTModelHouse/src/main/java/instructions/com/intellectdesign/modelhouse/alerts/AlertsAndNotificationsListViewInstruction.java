package com.intellectdesign.modelhouse.alerts;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.alert.inbox.InboxUtility;
import com.intellectdesign.canvas.constants.listviews.ListViewConstants;
import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinition;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.ListViewsInstruction;

public abstract class AlertsAndNotificationsListViewInstruction extends ListViewsInstruction

{

	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * 
	 * 
	 * @see com.intellectdesign.cib.viewdefinition.IViewInstruction#getViewSpecificFilters(java.util.HashMap,
	 * 
	 * com.intellectdesign.cib.viewdefinition.DataEntitlements)
	 */

	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)

	throws ViewDefinitionException

	{

		// TODO Auto-generated method stub

		return null;

	}

	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * 
	 * 
	 * @see com.intellectdesign.cib.viewdefinition.SimpleViewDefinitionInstruction#getUniqueSortFieldName()
	 */

	@Override
	protected String getUniqueSortFieldName()

	{

		// TODO Auto-generated method stub

		return null;

	}

	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * 
	 * 
	 * @see com.intellectdesign.cib.viewdefinition.SimpleViewDefinitionInstruction#getUniqueSortFieldOrder()
	 */

	@Override
	protected String getUniqueSortFieldOrder()

	{

		// TODO Auto-generated method stub

		return null;

	}

	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * 
	 * 
	 * @see com.intellectdesign.cib.viewdefinition.SimpleViewDefinitionInstruction#getSortColumnMap()
	 */

	@Override
	protected HashMap<String, String> getSortColumnMap()

	{

		// TODO Auto-generated method stub

		return null;

	}

	protected abstract String getChannel();

	protected HashMap processResponse(List listViewData, ViewDefinition viewDefinition, HashMap mapInputParams)

	throws ViewDefinitionException

	{

		HashMap hmReturnMap = null;

		// Call the base class to get the packaged response

		HashMap mapMessage = null;

		InboxUtility inboxUtility = new InboxUtility();

		for (int i = 0; i < listViewData.size(); ++i)

		{

			mapMessage = (HashMap) listViewData.get(i);

			mapMessage = inboxUtility.formMessage(mapMessage,

			(String) mapInputParams.get(ListViewConstants.INPUT_LANGUAGE_ID), getChannel());

		}

		hmReturnMap = super.processResponse(listViewData, viewDefinition, mapInputParams);

		LOGGER.debug("stmt Detail Instruction >> " + hmReturnMap);

		return hmReturnMap;

	}

	private Logger LOGGER = Logger.getLogger(AlertsAndNotificationsListViewInstruction.class);

}
