package com.intellectdesign.modelhouse.alerts;

public class AlertListView
{

	public static final String ALERT_MESSAGES = "ALERT_MESSAGES";
	public static final String STR_MESSAGE_DURATION = "STR_MESSAGE_DURATION";
	public static final String SEVERITY = "SEVERITY";
	public static final String SUB_PRODUCT_CODE = "SUB_PRODUCT_CODE";
	public static final String ACTION = "ACTION";
	public static final String GET_DETAILS_ALERT = "GET_DETAILS_ALERT";
	public static final String DEFAULT_SORTING_ORDER = "DESC";
	public static final String DEFAULT_SORTING_FIELD_ALERT = "STR_MESSAGE_TS";

	public static final String NOTIFICATION_MESSAGES = "NOTIFICATION_MESSAGES";
	public static final String STR_MESSAGE_TS = "STR_MESSAGE_TS";
	public static final String GET_DETAILS_NOTIFY = "GET_DETAILS_NOTIFY";
	public static final String DEFAULT_SORTING_FIELD_NOTIFY = "STR_MESSAGE_TS";

	public static final String DATE = "DATE";
	public static final String REFERENCE_NO = "REFERENCE_NO";
	public static final String SUBJECT = "SUBJECT";
	public static final String MAIL_ID = "MAIL_ID";
	public static final String OD_MAIL_BODY = "OD_MAIL_BODY";
	public static final String OD_MAIL_SUBPRODUCT = "OD_MAIL_SUBPRODUCT";
	public static final String OD_STATUS = "OD_STATUS";
	// public static final String DEFAULT_SORTING_FIELD_INBOX = "MESSAGE_STR";
	public static final String DEFAULT_SORTING_FIELD_INBOX = "OD_MAIL_DATE";
	public static final String MESSAGE_STR = "MESSAGE_STR_TS";
	public static final String OD_MAIL_DATE = "OD_MAIL_DATE";
	public static final String USER_ID = "USER_ID";

	public static final String GET_DETAILS_SENT_MAIL = "GET_DETAILS_SENT_MAIL";
	// public static final String DEFAULT_SORTING_FIELD_SENTMAIL = "MESSAGE_STR";
	public static final String DEFAULT_SORTING_FIELD_SENTMAIL = "OD_MAIL_DATE";

	public static final String GET_DETAILS_TRASH = "GET_DETAILS_TRASH";
	// public static final String DEFAULT_SORTING_FIELD_TRASH = "MESSAGE_STR";
	public static final String DEFAULT_SORTING_FIELD_TRASH = "OD_MAIL_DATE";

	public static final String SUB_PRODUCT_CODE_DISPVAL = "SUB_PRODUCT_CODE_DISPVAL";

}
