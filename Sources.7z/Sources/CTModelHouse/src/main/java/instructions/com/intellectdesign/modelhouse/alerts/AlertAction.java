package com.intellectdesign.modelhouse.alerts;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.intellectdesign.canvas.action.PortletAction;
import com.intellectdesign.canvas.common.ReplyObject;
import com.intellectdesign.canvas.constants.common.FrameworkConstants;
import com.intellectdesign.canvas.data.conversion.util.JSONObjectBuilderForExtJs;
import com.intellectdesign.canvas.exceptions.action.OrbiActionException;
import com.intellectdesign.canvas.exceptions.common.ProcessingErrorException;
import com.intellectdesign.canvas.login.sessions.SessionInfo;
import com.intellectdesign.canvas.web.config.ActionMap;

public class AlertAction extends PortletAction
{

	/**
	 * This method displays the error message
	 * 
	 * @param action
	 * @param actionMap
	 * @param sessionInfo
	 * @param requestParams
	 * @return request
	 * @throws OrbiActionException
	 */
	@Override
	public ReplyObject executePortletActionUsing(String action, SessionInfo sessionInfo, ActionMap actionMap,
			Map requestParams, HttpServletRequest request) throws OrbiActionException
	{
		ReplyObject reply = null;
		JSONObjectBuilderForExtJs builder = new JSONObjectBuilderForExtJs();
		try
		{

			if ("GET_ALL_ALERT_MESSAGES".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_READ_ALERT_MESSAGES".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_UNREAD_ALERT_MESSAGES".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_ALL_ALERT_MESSAGES_FOR_STATUS".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_ALL_ALERT_MESSAGES_FOR_SEVERITY".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_ALL_ALERT_MESSAGES_FOR_DATE".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_ALL_ALERT_MESSAGES_FOR_SUBPROD".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("MARK_ALERT_MSG_AS_READ".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_ALERT_MSG_COUNT".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_UNREAD_ALERT_MSG_COUNT".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("DELETE_ALERT_MESG".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_UNREAD_ALERT_MSG_FOR_STATUS".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_UNREAD_ALERT_MSG_FOR_SEVERITY".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_UNREAD_ALERT_MSG_FOR_DATE".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("GET_UNREAD_ALERT_MSG_FOR_SUBPROD".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			}

			else if ("GET_ALERT_DETAIL_MESSAGE".equals(action))
			{
				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("UPDATE_REFRESH_ACTION".equals(action))
			{

				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			} else if ("DELETE_ACTION".equals(action))
			{

				reply = executeHostRequest(sessionInfo, actionMap.getHostCode(), requestParams,request);

			}
		} catch (ProcessingErrorException procExcep)
		{

			throw new OrbiActionException(FrameworkConstants.ERROR_SYSTEM_ERROR,
					"Received processing error while handling action - '" + action + "in ViewDefinition action",
					procExcep);
		}

		return reply;
	}

}
