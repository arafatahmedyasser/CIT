package com.intellectdesign.modelhouse.dataSupport;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.intellectdesign.canvas.database.DatabaseConstants;
import com.intellectdesign.canvas.database.DatabaseException;
import com.intellectdesign.canvas.database.DatabaseRequest;
import com.intellectdesign.canvas.database.DatabaseResult;
import com.intellectdesign.canvas.formdefinition.FormDefinitionException;
import com.intellectdesign.canvas.formdefinition.FormItemDefinition;
import com.intellectdesign.canvas.formdefinition.addinfo.AdditionalDataCodeValue;
import com.intellectdesign.canvas.formdefinition.addinfo.IAdditionalDataSupport;
import com.intellectdesign.canvas.value.IUserValue;

public class PaymentDataSupport implements IAdditionalDataSupport
{

	@Override
	public ArrayList<AdditionalDataCodeValue> getAdditionalDataFor(FormItemDefinition itemDefn, IUserValue userValue,
			HashMap inputParams) throws FormDefinitionException
	{
		ArrayList<AdditionalDataCodeValue> resultList = null;
		DatabaseRequest dbRequest = null;
		DatabaseResult dbResult   = null;
		List tmpList = null;
		String key = null;
		try{
			dbRequest  = new DatabaseRequest(); 
			dbResult   = new DatabaseResult();
			tmpList = new ArrayList();
			resultList = new ArrayList<AdditionalDataCodeValue>();
			dbRequest.setDataSource(DatabaseConstants.DEFAULT_DATASOURCE);
			
			if (itemDefn.getItemId().equals("ACC_NO")){
				dbRequest.setOperation(DatabaseConstants.SELECT);
				dbRequest.setDataAccessMapKey("FUNDTRANS");
				dbRequest.setOperationExtension("ACC_NO");
				dbResult 	= dbRequest.execute();
				key = "ACCOUNT_NO";
				tmpList 	= dbResult.getReturnedList();
				
			}
			else if(itemDefn.getItemId().equals("BENE_ACC_NO")){
				dbRequest.setOperation(DatabaseConstants.SELECT);
				dbRequest.setDataAccessMapKey("FUNDTRANS");
				dbRequest.setOperationExtension("BENE_NO");
				dbResult 	= dbRequest.execute();
				key = "BENE_ACC_NO"; 
				tmpList 	= dbResult.getReturnedList();
			}
			for(int i=0;i<tmpList.size();i++){
				Map tmpMap = (HashMap)tmpList.get(i);
				resultList.add(new AdditionalDataCodeValue((String)tmpMap.get(key), (String)tmpMap.get(key)));
			}
		}catch(DatabaseException dbExcep){
			throw new FormDefinitionException(dbExcep);
		}
		return resultList;
	}

}
