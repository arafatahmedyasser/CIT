package com.intellectdesign.modelhouse.views;

import java.util.HashMap;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.ListViewsInstruction;

public class StructureListViewsInstruction extends ListViewsInstruction
{

	@Override
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException
	{
		HashMap<String, String> mapViewSpecificFilter = new HashMap<String, String>();

		return mapViewSpecificFilter;
	}

	@Override
	protected String getUniqueSortFieldName()
	{
		// TODO Auto-generated method stub
		return "STR_ID";
	}

	@Override
	protected String getUniqueSortFieldOrder()
	{
		// TODO Auto-generated method stub
		return "DESC";
	}
	protected String getUniqueSortColumnName(){
		return "STR_ID";
	}
	@Override
	protected HashMap<String, String> getSortColumnMap()
	{
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		sortColumnReturnMap.put("STR_ID", "STR_ID");
		sortColumnReturnMap.put("STR_NAME", "STR_NAME");
		sortColumnReturnMap.put("INSTR_ID", "INSTR_ID");
		sortColumnReturnMap.put("INSTR_START_DATE", "INSTR_START_DATE");
		sortColumnReturnMap.put("INSTR_END_DATE", "INSTR_END_DATE");
		sortColumnReturnMap.put("SWEEP_TYPE", "SWEEP_TYPE");
		sortColumnReturnMap.put("EXEC_FREQ", "EXEC_FREQ");
		sortColumnReturnMap.put("CONTRA_ACC_NO", "CONTRA_ACC_NO");
		sortColumnReturnMap.put("CONTRA_ACC_CCY", "CONTRA_ACC_CCY");
		sortColumnReturnMap.put("CONTROL_ACC_NO", "CONTROL_ACC_NO");
		sortColumnReturnMap.put("CONTROL_ACC_CCY", "CONTROL_ACC_CCY");
		sortColumnReturnMap.put("AMOUNT", "AMOUNT");
		sortColumnReturnMap.put("NEXT_EXEC_DATE", "NEXT_EXEC_DATE");
		sortColumnReturnMap.put("STATUS", "STATUS");
		sortColumnReturnMap.put("STR_TYPE", "STR_TYPE");


		return sortColumnReturnMap;
	}

}

