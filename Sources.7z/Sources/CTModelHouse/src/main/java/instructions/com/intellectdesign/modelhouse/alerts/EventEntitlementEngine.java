package com.intellectdesign.modelhouse.alerts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.entitlement.EntitlementEngineException;
import com.intellectdesign.canvas.entitlement.IEntitlementEngine;
import com.intellectdesign.canvas.event.Event;

public class EventEntitlementEngine implements IEntitlementEngine
{

	/*
	 * The below function is not provided by IEntitlementEngine interface, hence removed.
	 */
	/**
	 * API to get the entitlement Criteria for the given user number. Here entitlement criteria is event id
	 * (product+subproduct+function) list.
	 * 
	 * @param userNo the user number of the user.
	 * @return ArrayList of entitlement event ids.
	 */
	/*
	 * public final List<String> getEntitlementCriteria(final String userNo) {
	 * 
	 * String cname = "EventEntitlementEngine.getEntitlementCriteria"; logger.log(ENTRYLevel.ENTRY, "Entered into" +
	 * cname + "method"); logger.debug("userNo " + userNo); List<String> entlEventsList = new ArrayList<String>();
	 * AlertSubscriptionInstruction alertSubInstr = new AlertSubscriptionInstruction(); try { entlEventsList =
	 * alertSubInstr.getEntitledEventList(userNo); } catch (AlertSubscriptionException asEx) {
	 * logger.error("AlertSubscriptionException occured :" + asEx); } logger.debug("returned events list is : " +
	 * entlEventsList); logger.log(EXITLevel.EXIT, "Exiting from" + cname + "method"); return entlEventsList; }
	 */

	/**
	 * @see com.intellectdesign.iportal.as.entitlement.IEntitlementEngine#getEntitledUsers(com.intellectdesign.od.shared.event.Event,
	 *      java.util.HashMap)
	 */
	public ArrayList<String> getEntitledUsers(Event event, Map dataMap) throws EntitlementEngineException
	{
		throw new UnsupportedOperationException();
	}

	/**
	 * @see com.intellectdesign.iportal.as.entitlement.IEntitlementEngine#isUserEntitled(com.intellectdesign.od.shared.event.Event,
	 *      java.lang.String, java.util.HashMap)
	 */
	public boolean isUserEntitled(Event event, String sUserNo, HashMap Data) throws EntitlementEngineException
	{
		throw new UnsupportedOperationException();
	}

	/**
	 * @see com.intellectdesign.iportal.as.entitlement.IEntitlementEngine#getEntitlementCriteria(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public ArrayList<String> getEntitlementCriteria(String userNo, String gcif, String sProduct, String sSubProduct,
			String sFunction) throws EntitlementEngineException
	{
		throw new UnsupportedOperationException();
	}

	/**
	 * @see com.intellectdesign.iportal.as.entitlement.IEntitlementEngine#getEntitlementCriteria(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String)
	 */
	public ArrayList<String> getEntitlementCriteria(String userNo, String gcif, String sProduct, String sSubProduct)
			throws EntitlementEngineException
	{
		throw new UnsupportedOperationException();
	}

	/***
	 * API to get the entitlement Criteria for the combination of parameters passed. Here entitlement criteria is event
	 * id (product+subproduct+function) list.
	 * 
	 * @param userNo : the user number of the user.
	 * @param gcif : the gcif number of the user.
	 * @param sProduct the product code associated. This parameter is not used in this implementation.
	 * @return ArrayList of event ids.
	 * @throws EntitlementEngineException for any exception caught.
	 */
	public ArrayList<String> getEntitlementCriteria(String userNo, String gcif, String sProduct)
			throws EntitlementEngineException
	{

		String cname = "EventEntitlementEngine.getEntitlementCriteria";

		logger.debug("userNo " + userNo + "gcif " + gcif);
		ArrayList<String> entlEventsList = null;
	/*	AlertSubscriptionInstruction alertSubInstr = new AlertSubscriptionInstruction();
		try
		{
			entlEventsList = (ArrayList) alertSubInstr.getEntitledEventList(userNo, gcif);
		} catch (AlertSubscriptionException asEx)
		{
			logger.error("AlertSubscriptionException occured :", asEx);
			throw new EntitlementEngineException(asEx);
		}*/
		logger.debug("returned events list is : " + entlEventsList);
		return entlEventsList;
	}

	/**
	 * @see com.intellectdesign.iportal.as.entitlement.IEntitlementEngine#getEntitlementCriteria(java.lang.String,
	 *      java.lang.String, com.intellectdesign.od.shared.event.Event)
	 */
	public ArrayList<String> getEntitlementCriteria(String userNo, String gcif, Event event)
			throws EntitlementEngineException
	{
		throw new UnsupportedOperationException();
	}

	private Logger logger = Logger.getLogger(EventEntitlementEngine.class);
}
