package com.intellectdesign.modelhouse.views;

import java.util.HashMap;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.ListViewsInstruction;

public class ActivitySummaryViewsInstruction extends ListViewsInstruction
{

	@Override
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException
	{
		HashMap<String, String> mapViewSpecificFilter = new HashMap<String, String>();
		
		if("PENDING_VIEW".equals(hmInputParams.get("VIEW_ID"))){
			mapViewSpecificFilter.put("USER_NO",(String) hmInputParams.get("INPUT_USER_NO"));
			mapViewSpecificFilter.put("ASW_FILTER_STATUS", "RA");
		}else if("DRAFT_VIEW".equals(hmInputParams.get("VIEW_ID"))){
			mapViewSpecificFilter.put("ASW_FILTER_STATUS", "DR");
		}else if("READY_VIEW".equals(hmInputParams.get("VIEW_ID"))){
			mapViewSpecificFilter.put("ASW_FILTER_STATUS", "AO");
		}else if("REJECTED_VIEW".equals(hmInputParams.get("VIEW_ID"))){
			mapViewSpecificFilter.put("ASW_FILTER_STATUS", "RO");
		}
		return mapViewSpecificFilter;
	}

	@Override
	protected String getUniqueSortFieldName()
	{
		// TODO Auto-generated method stub
		return "REFERENCE_NO";
	}

	@Override
	protected String getUniqueSortFieldOrder()
	{
		// TODO Auto-generated method stub
		return "DESC";
	}
	protected String getUniqueSortColumnName(){
		return "REFERENCE_NO";
	}
	@Override
	protected HashMap<String, String> getSortColumnMap()
	{
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		sortColumnReturnMap.put("REFERENCE_NO", "REFERENCE_NO");
		sortColumnReturnMap.put("TRAN_TYPE", "TRAN_TYPE");
		sortColumnReturnMap.put("ACC_NO", "ACC_NO");
		sortColumnReturnMap.put("TRANSACTION_AMT", "TRANSACTION_AMT");
		sortColumnReturnMap.put("ACC_CCY", "ACC_CCY");
		sortColumnReturnMap.put("CREATED_BY", "CREATED_BY");
		sortColumnReturnMap.put("CREATE_DATE", "CREATE_DATE");
		sortColumnReturnMap.put("AUTH_FLAG", "AUTH_FLAG");		
		return sortColumnReturnMap;
	}

}
