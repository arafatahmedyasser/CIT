package com.intellectdesign.modelhouse.alerts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.intellectdesign.canvas.alert.handler.AlertConstants;
import com.intellectdesign.canvas.alert.handler.IMessage;
import com.intellectdesign.canvas.alert.handler.Message;
import com.intellectdesign.canvas.alert.inbox.DefaultInboxAlertViewHandler;
import com.intellectdesign.canvas.common.ExtReplyObject;
import com.intellectdesign.canvas.constants.util.TIConstants;
import com.intellectdesign.canvas.database.DatabaseException;
import com.intellectdesign.canvas.exceptions.common.OnlineException;
import com.intellectdesign.canvas.handler.SimpleRequestHandler;

public class AlertHandler extends SimpleRequestHandler
{
	public Object processRequest(Object obj) throws OnlineException

	{

		ExtReplyObject reply = new ExtReplyObject();

		if (obj instanceof Vector)
		{
			Vector inputVector = (Vector) obj;
			String action = (String) inputVector.get(TIConstants.INPUT_ACTION_INDEX_IN_VECTOR);
			DefaultInboxAlertViewHandler def = new DefaultInboxAlertViewHandler();
			reply.headerMap = new HashMap();
			String gcifNo = (String) inputVector.get(TIConstants.GCIF_INDEX_IN_VECTOR);
			String userNo = (String) inputVector.get(TIConstants.USER_NO_INDEX_IN_VECTOR);
			HashMap map = (HashMap) inputVector.get(inputVector.size() - 1);

			if ("GET_ALL_ALERT_MESSAGES".equals(action))
			{
				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				try
				{
					List<IMessage> allMessageList = def.fetchAlertMessages(gcifNo, userNo, null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_READ_ALERT_MESSAGES".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				try
				{
					List<IMessage> allMessageList = def.fetchReadAlertMessages(gcifNo, userNo, null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_UNREAD_ALERT_MESSAGES".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				try
				{
					List<IMessage> allMessageList = def
							.fetchUnReadAlertMessages(gcifNo, userNo, null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_ALL_ALERT_MESSAGES_FOR_STATUS".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String status = (String) map.get("STATUS");
				try
				{
					List<IMessage> allMessageList = def.getAllAlertMessagesForStatus(gcifNo, userNo, status, null,
							null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_ALL_ALERT_MESSAGES_FOR_SEVERITY".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String severity = (String) map.get("SEVERITY");
				try
				{
					List<IMessage> allMessageList = def.getAllAlertMessagesForSeverity(gcifNo, userNo, severity, null,
							null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_ALL_ALERT_MESSAGES_FOR_DATE".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String cmp = (String) map.get("CMP");
				String date1 = (String) map.get("DATE1");
				String date2 = (String) map.get("DATE2");
				try
				{
					List<IMessage> allMessageList = def.getAllAlertMessagesForDate(gcifNo, userNo, date1, date2, cmp,
							null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_ALL_ALERT_MESSAGES_FOR_SUBPROD".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String subprod = (String) map.get("SUBPROD");
				try
				{
					List<IMessage> allMessageList = def.getAllAlertMessagesForSubProdCode(gcifNo, userNo, subprod,
							null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("MARK_ALERT_MSG_AS_READ".equals(action))
			{
				try
				{

					String messageId = (String) map.get("MESSAGE_ID");
					boolean updateStatus = def.markAlertMessageAsRead(messageId, gcifNo, userNo);
					HashMap hm = new HashMap();
					hm.put("UPDATE_STATUS", updateStatus);
					reply.headerMap.put("JSON_MAP", hm);

				} catch (Exception e)
				{

				}
			} else if ("GET_ALERT_MSG_COUNT".equals(action))
			{
				try
				{

					int count = def.getAlertMessageCounts(gcifNo, userNo);
					HashMap hm = new HashMap();
					hm.put("ALERT_COUNT", count);
					reply.headerMap.put("JSON_MAP", hm);

				} catch (Exception e)
				{

				}

			} else if ("GET_UNREAD_ALERT_MSG_COUNT".equals(action))
			{
				try
				{

					int count = def.getUnreadAlertMessageCounts(gcifNo, userNo);
					HashMap hm = new HashMap();
					hm.put("ALERT_COUNT", count);
					reply.headerMap.put("JSON_MAP", hm);

				} catch (Exception e)
				{

				}

			} else if ("DELETE_ALERT_MESG".equals(action))
			{

				try
				{
					ArrayList arrLst = new ArrayList();
					arrLst = (ArrayList) map.get("MESSAGE_ID");

					boolean status = def.deleteAlertMessage(gcifNo, userNo, arrLst);
					HashMap hm = new HashMap();
					hm.put("STATUS", status);
					reply.headerMap.put("JSON_MAP", hm);

				} catch (Exception e)
				{

				}

			} else if ("GET_UNREAD_ALERT_MSG_FOR_STATUS".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String status = (String) map.get("STATUS");
				try
				{
					List<IMessage> allMessageList = def.getUnreadAlertMessagesForStatus(gcifNo, userNo, status, null,
							null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_UNREAD_ALERT_MSG_FOR_SEVERITY".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String severity = (String) map.get("SEVERITY");
				try
				{
					List<IMessage> allMessageList = def.getUnreadAlertMessagesForSeverity(gcifNo, userNo, severity,
							null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_UNREAD_ALERT_MSG_FOR_DATE".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String date1 = (String) map.get("DATE1");
				String date2 = (String) map.get("DATE2");
				String cmp = (String) map.get("CMP");
				try
				{
					List<IMessage> allMessageList = def.getUnreadAlertMessagesForDate(gcifNo, userNo, date1, date2,
							cmp, null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_UNREAD_ALERT_MSG_FOR_SUBPROD".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String subProd = (String) map.get("SUBPROD");
				try
				{
					List<IMessage> allMessageList = def.getUnreadAlertMessagesForSubProdCode(gcifNo, userNo, subProd,
							null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			}

			else if ("GET_ALERT_DETAIL_MESSAGE".equals(action))
			{
				HashMap returnMap = new HashMap();
				HashMap replyMap = new HashMap();

				String langCode = (String) inputVector.get(12);
				String message_id = (String) map.get("MESSAGE_ID");

				try
				{
					Message message = (Message) def.readAlertMessage(message_id, userNo, langCode, null);
					returnMap.put("DETAIL_MESSAGE", message.getDetailedMessage());
					returnMap.put("SHORT_MESSAGE", message.getShortMessage());
					// UAT_ALERT_FIX Starts
					/*
					 * String key_prpt = message.getAlertId() + "_" + message.getFunctionCode(); String trans_type =
					 * MessageManager.getMessage("productsfunctions", key_prpt, langCode); if (trans_type.equals("?" +
					 * key_prpt + "?")) { returnMap.put("ALERT_MESSAGE_TYPE_ID",
					 * MessageManager.getMessage("productsfunctions", "LBL_" + message.getFunctionCode(), langCode)); }
					 * else { returnMap.put("ALERT_MESSAGE_TYPE_ID", trans_type); }
					 */
					// SIT_302
					returnMap.put("ALERT_MESSAGE_TYPE_ID", (String) message.getProductDispval());
					// UAT_ALERT_FIX Ends
					returnMap.put("ALERT_PRODUCT_ID", message.getProductCode());
					returnMap.put("ALERT_DATE_TIME_ID", message.getStrMessageTimeStamp());
					returnMap.put("ALERT_SEVERITY", message.getSeverity());

					if (message.getSender() != null && "".equals(message.getSender()))
					{
						returnMap.put("ALERT_USERNAME", "");
						returnMap.put("ALERT_USER_ID", "");
					} else
					{
						// AlertListViewData alertListViewData = new AlertListViewData();
						// HashMap userData = alertListViewData.getUserDetails(message.getSender());
						// logger.debug("The User Name and Login id " + userData);
						// Extract the login id and user name and set it to the key that we need.
						// returnMap.put("ALERT_USERNAME", userData.get("OD_USER_NAME"));
						// returnMap.put("ALERT_USER_ID", userData.get("OD_LOGIN_ID"));
						returnMap.put("ALERT_USERNAME", message.getSender());
						returnMap.put("ALERT_USER_ID", message.getSender());
					}
					// Add the new enriched keys coming for this alert.
					returnMap.put(AlertConstants.KEY_ENRICH_BANK_NAME, message.getEnrichBankName());
					returnMap.put(AlertConstants.KEY_ENRICH_BRANCH_NAME, message.getEnrichBranchName());
					returnMap.put(AlertConstants.KEY_ENRICH_CCY, message.getEnrichCcy());
					returnMap.put(AlertConstants.KEY_ENRICH_COUNTRY_NAME, message.getEnrichCountryName());
					returnMap.put(AlertConstants.KEY_ENRICH_SUBPROD_DESC, message.getEnrichSubProduct());

					String statusCode = null;
					/**
					 * If the message is already read, then the status should be displayed as 'Done'. Else 'Active'.
					 */
					if (message.isRead())
					{
						statusCode = "Done";
					} else
					{
						statusCode = "Active";
					}
					returnMap.put("ALERT_STATUS_ID", statusCode);
					replyMap.put("ALL_RECORDS", returnMap);

					reply.headerMap.put("JSON_MAP", replyMap);
					// String seq = message.getRawMessageData().get("ATTACHMENT_REF");
				} catch (DatabaseException e)
				{
				}

			}

			else if ("UPDATE_REFRESH_ACTION".equals(action))
			{

				String sMsgId = (String) map.get("MSG_ID");

				HashMap replyMap = new HashMap();

				try
				{

					def.markAlertMessageAsRead(sMsgId, userNo, gcifNo);
					replyMap.put("STATUS", "SUCCESS");
					reply.headerMap.put("JSON_MAP", replyMap);
				} catch (DatabaseException e)
				{

				}
			}

			else if ("DELETE_ACTION".equals(action))
			{

				ArrayList arrMsgIdList = new ArrayList();
				String sMsgId = (String) map.get("MSG_ID");
				arrMsgIdList.add(sMsgId);

				String severitySelected = (String) map.get(AlertConstants.SEVERITY_SELECTED);

				try
				{

					def.deleteAlertMessage(gcifNo, userNo, arrMsgIdList);
					HashMap replyMap = new HashMap();
					replyMap.put("STATUS", "SUCCESS");
					reply.headerMap.put("JSON_MAP", replyMap);

				} catch (DatabaseException e)
				{

				}

			}

		}
		return reply;
	}

}
