/**
 * Copyright 2014. Intellect Design Arena Limited Limited. All rights reserved. 
 * 
 * These materials are confidential and proprietary to Intellect Design Arena Limited 
 * Limited and no part of these materials should be reproduced, published, transmitted
 * or distributed in any form or by any means, electronic, mechanical, photocopying, 
 * recording or otherwise, or stored in any information storage or retrieval system 
 * of any nature nor should the materials be disclosed to third parties or used in any 
 * other manner for which this is not authorized, without the prior express written 
 * authorization of Intellect Design Arena Limited Limited.
 * 
 */
package com.intellectdesign.modelhouse.ratecard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.intellectdesign.canvas.ratecard.IRateCard;


/**
 *
 * @Version 1.0
 */
public class ModelHouseRateCard implements IRateCard
{
	private String sRateCard = "BR0001";
	List<String>  ccyList= new ArrayList<String>();
	/**
	 * The default constructor.
	 */
	public ModelHouseRateCard()
	{
		// Nothing to be done here
	}
	@Override
	public double getConversionRateFor(String sourceCurrency, String targetCurrency)
	{
		// TODO Auto-generated method stub
		return 5;
	}
	@Override
	public String getRateCardId()
	{
		return sRateCard;
	}
	@Override
	public String getRateCardDescription()
	{
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getCardCurrency()
	{
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<String> getAllCurrencies()
	{
		ccyList.add("USD");
		ccyList.add("AED");
		ccyList.add("INR");
		ccyList.add("EUR");
		ccyList.add("JPY");
		ccyList.add("BHD");
		ccyList.add("KWD");
		ccyList.add("GBP");
		ccyList.add("SGD");
		return ccyList;
	}
	@Override
	public boolean isInitialized()
	{
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public List<HashMap> getAllConversionRates()
	{
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean isBankRateCard()
	{
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public String getBaseCurrency(){
		return "USD";
	}

}
