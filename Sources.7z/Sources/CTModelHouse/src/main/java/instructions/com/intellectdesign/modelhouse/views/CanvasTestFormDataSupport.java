package com.intellectdesign.modelhouse.views;

import java.util.ArrayList;
import java.util.HashMap;

import com.intellectdesign.canvas.formdefinition.FormDefinitionException;
import com.intellectdesign.canvas.formdefinition.FormItemDefinition;
import com.intellectdesign.canvas.formdefinition.addinfo.AdditionalDataCodeValue;
import com.intellectdesign.canvas.formdefinition.addinfo.IAdditionalDataSupport;
import com.intellectdesign.canvas.value.IUserValue;

public class CanvasTestFormDataSupport implements IAdditionalDataSupport
{


    public CanvasTestFormDataSupport()
    {
    }

    public ArrayList getAdditionalDataFor(FormItemDefinition itemDefn, IUserValue userValue, HashMap inputParams)
        throws FormDefinitionException
    {
        ArrayList dataList = null;
        if(itemDefn.getItemId().equals("FORM_COMBO") || itemDefn.getItemId().equals("Combo_box"))
        {
            dataList = new ArrayList();
            dataList.add(new AdditionalDataCodeValue("INV_SUM", "Invoice Summary"));
            dataList.add(new AdditionalDataCodeValue("INV_DET", "Invoice Details"));
        }
        return dataList;
    }

}
