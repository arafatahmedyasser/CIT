package com.intellectdesign.modelhouse.views;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinition;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.ListViewsInstruction;

/**
 * @author dinesh.v
 *
 */
public class CTMapsViewsInstruction extends ListViewsInstruction
{

	@Override
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException
	{
HashMap<String, String> mapViewSpecificFilter = new HashMap<String, String>();
		
		

		return mapViewSpecificFilter;
	}
	/**
	 * Creates a map for the view metadata
	 */

	
	protected HashMap<String, String> getSortColumnMap() {
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		sortColumnReturnMap.put("LATITUDE", "LATITUDE");
		sortColumnReturnMap.put("LONGITUDE","LONGITUDE");
		sortColumnReturnMap.put("ADDRESS","ADDRESS");
		
		
		return sortColumnReturnMap;
	}
	


	@Override
	protected String getUniqueSortFieldName()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected String getUniqueSortFieldOrder()
	{
		// TODO Auto-generated method stub
		return null;
	}

	

}
