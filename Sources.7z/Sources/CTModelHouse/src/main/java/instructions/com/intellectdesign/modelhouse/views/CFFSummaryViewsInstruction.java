package com.intellectdesign.modelhouse.views;

import java.util.HashMap;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.ListViewsInstruction;

public class CFFSummaryViewsInstruction extends ListViewsInstruction
{

	@Override
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException
	{
		HashMap<String, String> mapViewSpecificFilter = new HashMap<String, String>();
		mapViewSpecificFilter.put("USER_PREFEERENCE_DATE_FORMAT",(String) hmInputParams.get("USER_PREFEERENCE_DATE_FORMAT"));
		return mapViewSpecificFilter;
	}

	@Override
	protected String getUniqueSortFieldName()
	{
		// TODO Auto-generated method stub
		return "ACC_NO";
	}

	@Override
	protected String getUniqueSortFieldOrder()
	{
		// TODO Auto-generated method stub
		return "DESC";
	}
	protected String getUniqueSortColumnName(){
		return "ACC_NO";
	}
	@Override
	protected HashMap<String, String> getSortColumnMap()
	{
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		sortColumnReturnMap.put("ACC_NO", "ACC_NO");
		sortColumnReturnMap.put("PERIOD2", "PERIOD2");
		sortColumnReturnMap.put("PERIOD1", "PERIOD1");
		sortColumnReturnMap.put("PERIOD3", "PERIOD3");
		sortColumnReturnMap.put("PERIOD5", "PERIOD5");
		sortColumnReturnMap.put("PERIOD4", "PERIOD4");
		sortColumnReturnMap.put("PERIOD6", "PERIOD6");
		sortColumnReturnMap.put("PERIOD7", "PERIOD7");
		
		return sortColumnReturnMap;
	}
	
}
