package com.intellectdesign.modelhouse.alerts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.intellectdesign.canvas.alert.handler.IMessage;
import com.intellectdesign.canvas.alert.handler.Message;
import com.intellectdesign.canvas.alert.inbox.DefaultInboxNotificationViewHandler;
import com.intellectdesign.canvas.common.ExtReplyObject;
import com.intellectdesign.canvas.constants.util.TIConstants;
import com.intellectdesign.canvas.database.DatabaseException;
import com.intellectdesign.canvas.exceptions.common.OnlineException;
import com.intellectdesign.canvas.handler.SimpleRequestHandler;

public class NotificationHandler extends SimpleRequestHandler
{
	public Object processRequest(Object obj) throws OnlineException

	{

		ExtReplyObject reply = new ExtReplyObject();

		if (obj instanceof Vector)
		{
			Vector inputVector = (Vector) obj;
			String action = (String) inputVector.get(TIConstants.INPUT_ACTION_INDEX_IN_VECTOR);
			DefaultInboxNotificationViewHandler def = new DefaultInboxNotificationViewHandler();
			reply.headerMap = new HashMap();
			String gcifNo = (String) inputVector.get(TIConstants.GCIF_INDEX_IN_VECTOR);
			String userNo = (String) inputVector.get(TIConstants.USER_NO_INDEX_IN_VECTOR);
			HashMap map = (HashMap) inputVector.get(inputVector.size() - 1);

			if ("GET_ALL_NOTIFICATION_MESSAGES".equals(action))
			{
				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				try
				{
					List<IMessage> allMessageList = def.fetchNotificationMessages(gcifNo, userNo, null, null, null,
							null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_READ_NOTIFICATION_MESSAGES".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				try
				{
					List<IMessage> allMessageList = def.fetchReadNotificationMessages(gcifNo, userNo, null, null, null,
							null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_UNREAD_NOTIFICATION_MESSAGES".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				try
				{
					List<IMessage> allMessageList = def.fetchUnReadNotificationMessages(gcifNo, userNo, null, null,
							null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_ALL_NOTIFICATION_MESSAGES_FOR_STATUS".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String status = (String) map.get("STATUS");
				try
				{
					List<IMessage> allMessageList = def.getAllNotificationMessagesForStatus(gcifNo, userNo, status,
							null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_ALL_NOTIFICATION_MESSAGES_FOR_SEVERITY".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String severity = (String) map.get("SEVERITY");
				try
				{
					List<IMessage> allMessageList = def.getAllNotificationMessagesForSeverity(gcifNo, userNo, severity,
							null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_ALL_NOTIFICATION_MESSAGES_FOR_DATE".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String cmp = (String) map.get("CMP");
				String date1 = (String) map.get("DATE1");
				String date2 = (String) map.get("DATE2");
				try
				{
					List<IMessage> allMessageList = def.getAllNotificationMessagesForDate(gcifNo, userNo, date1, date2,
							cmp, null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_ALL_NOTIFICATION_MESSAGES_FOR_SUBPROD".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String subprod = (String) map.get("SUBPROD");
				try
				{
					List<IMessage> allMessageList = def.getAllNotificationMessagesForSubProdCode(gcifNo, userNo,
							subprod, null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("MARK_NOTIFICATION_MSG_AS_READ".equals(action))
			{
				try
				{

					String messageId = (String) map.get("MESSAGE_ID");
					boolean updateStatus = def.markNotificationMessageAsRead(messageId, gcifNo, userNo);
					HashMap hm = new HashMap();
					hm.put("UPDATE_STATUS", updateStatus);
					reply.headerMap.put("JSON_MAP", hm);

				} catch (Exception e)
				{

				}
			} else if ("GET_NOTIFICATION_MSG_COUNT".equals(action))
			{
				try
				{

					int count = def.getNotificationMessageCounts(gcifNo, userNo);
					HashMap hm = new HashMap();
					hm.put("Notification_COUNT", count);
					reply.headerMap.put("JSON_MAP", hm);

				} catch (Exception e)
				{

				}

			} else if ("GET_UNREAD_NOTIFICATION_MSG_COUNT".equals(action))
			{
				try
				{

					int count = def.getUnreadNotificationMessageCounts(gcifNo, userNo);
					HashMap hm = new HashMap();
					hm.put("Notification_COUNT", count);
					reply.headerMap.put("JSON_MAP", hm);

				} catch (Exception e)
				{

				}

			} else if ("DELETE_NOTIFICATION_MESG".equals(action))
			{

				try
				{
					ArrayList arrLst = new ArrayList();
					arrLst = (ArrayList) map.get("MESSAGE_ID");

					boolean status = def.deleteNotificationMessage(gcifNo, userNo, arrLst);
					HashMap hm = new HashMap();
					hm.put("STATUS", status);
					reply.headerMap.put("JSON_MAP", hm);

				} catch (Exception e)
				{

				}

			} else if ("GET_UNREAD_NOTIFICATION_MSG_FOR_STATUS".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String status = (String) map.get("STATUS");
				try
				{
					List<IMessage> allMessageList = def.getUnreadNotificationMessagesForStatus(gcifNo, userNo, status,
							null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_UNREAD_NOTIFICATION_MSG_FOR_SEVERITY".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String severity = (String) map.get("SEVERITY");
				try
				{
					List<IMessage> allMessageList = def.getUnreadNotificationMessagesForSeverity(gcifNo, userNo,
							severity, null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_UNREAD_NOTIFICATION_MSG_FOR_DATE".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String date1 = (String) map.get("DATE1");
				String date2 = (String) map.get("DATE2");
				String cmp = (String) map.get("CMP");
				try
				{
					List<IMessage> allMessageList = def.getUnreadNotificationMessagesForDate(gcifNo, userNo, date1,
							date2, cmp, null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			} else if ("GET_UNREAD_NOTIFICATION_MSG_FOR_SUBPROD".equals(action))
			{

				ExtReplyObject reply1 = new ExtReplyObject();
				reply1.headerMap = new HashMap();
				String subProd = (String) map.get("SUBPROD");
				try
				{
					List<IMessage> allMessageList = def.getUnreadNotificationMessagesForSubProdCode(gcifNo, userNo,
							subProd, null, null, null, null);
					HashMap mse = new HashMap();
					Iterator itr = allMessageList.iterator();
					int i = 1;
					while (itr.hasNext())
					{
						Message msg = (Message) itr.next();
						mse.put("Message" + i, msg.getDetailedMessage());
						i++;
					}

					reply1.headerMap.put("JSON_MAP", mse);

				} catch (DatabaseException e)
				{

				}

				reply = reply1;

			}
		}
		return reply;
	}

}
