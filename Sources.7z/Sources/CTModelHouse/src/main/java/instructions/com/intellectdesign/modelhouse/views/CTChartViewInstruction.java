/**
    COPYRIGHT NOTICE

    Copyright 2011 Intellect Design Arena Limited. All rights reserved.

    These materials are confidential and proprietary to 
    Intellect Design Arena Limited and no part of these materials should
    be reproduced, published, transmitted or distributed in any form or
    by any means, electronic, mechanical, photocopying, recording or 
    otherwise, or stored in any information storage or retrieval system
    of any nature nor should the materials be disclosed to third parties
    or used in any other manner for which this is not authorized, without
    the prior express written authorization of Intellect Design Arena Limited.
*/
package com.intellectdesign.modelhouse.views;

import java.util.HashMap;
import java.util.List;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinition;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.GraphViewInstruction;

/**
 * @author harriesh.v
 *
 */
public class CTChartViewInstruction extends GraphViewInstruction
{
	/**
	 * Return the unique sort field name for this view
	 * 
	 * @see com.intellectdesign.cib.viewdefinition.SimpleViewDefinitionInstruction#getUniqueSortFieldName()
	 */
	@Override
	protected String getUniqueSortFieldName()
	{
		return "OD_MAKER_DATE";
	}

	/**
	 * Get the sort order for this unique sort field name for this view
	 * 
	 * @see com.intellectdesign.cib.viewdefinition.SimpleViewDefinitionInstruction#getUniqueSortFieldOrder()
	 */
	@Override
	protected String getUniqueSortFieldOrder()
	{
		return "ASC";
	}

	@Override
	protected HashMap<String, String> getSortColumnMap() {
		HashMap<String, String> listViewColumnMap = new HashMap<String, String>();

		listViewColumnMap.put("OD_MAKER_DATE", "OD_MAKER_DATE");
		listViewColumnMap.put("TRANSACTION_COUNT", "TRANSACTION_COUNT");
		listViewColumnMap.put("TRANS_COUNT", "TRANS_COUNT");
		listViewColumnMap.put("TRAN_COUNT", "TRAN_COUNT");
		listViewColumnMap.put("NO_OF_INSTRUCTION", "NO_OF_INSTRUCTION");
		return listViewColumnMap;
	}
	


	/**
	 * This method forms the view specific filters from the input params
	 * 
	 * @param hmInputParams, dataEntitlements
	 * @return mapViewSpecificFilter
	 */
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements) throws ViewDefinitionException
	{
		HashMap mapViewSpecificFilter = null;
		
		
		
		return mapViewSpecificFilter;
	}

	@Override
	protected HashMap processResponse(List listViewData,
			ViewDefinition viewDefinition, HashMap mapInputParams)
			throws ViewDefinitionException {

		
		return super.processResponse(listViewData, viewDefinition, mapInputParams);
	}	
}
