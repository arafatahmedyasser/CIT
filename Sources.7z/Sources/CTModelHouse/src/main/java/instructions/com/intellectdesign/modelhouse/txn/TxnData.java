package com.intellectdesign.modelhouse.txn;

import com.intellectdesign.canvas.event.handler.IData;

public class TxnData implements IData
{

	private static final long serialVersionUID = 5842671545066836864L;
	
	private String referenceNo= null;
	private String accNo= null;
	private String accType= null;
	private String accCcy= null;
	private String accName= null;
	private String accBranch= null;
	private String transactionAmt= null;
	private String tranType= null;
	private String tranDate= null;
	private String createDate= null;
	private String createdBy= null;
	private String beneAccNo= null;
	private String beneCcy= null;
	private String beneName= null;
	private String beneBank= null;
	private String beneCity= null;
	private String beneBranch= null;
	private String beneAddress= null;
	private String status= null;	
	private String udf= null;	
	private String userNo= null;
	private String channelId= null;

	/**
	 * String Representation of all values .
	 * 
	 * @return String
	 */
	public String toString()
	{
		return "REFERENCE_NO: " + referenceNo + ", ACC_NO: " + accNo + ", ACC_TYPE: " + accType ;
	}

	/**
	 * @return the referenceNo
	 */
	public String getReferenceNo()
	{
		return referenceNo;
	}

	/**
	 * @param referenceNo the referenceNo to set
	 */
	public void setReferenceNo(String referenceNo)
	{
		this.referenceNo = referenceNo;
	}

	/**
	 * @return the accNo
	 */
	public String getAccNo()
	{
		return accNo;
	}

	/**
	 * @param accNo the accNo to set
	 */
	public void setAccNo(String accNo)
	{
		this.accNo = accNo;
	}

	/**
	 * @return the accType
	 */
	public String getAccType()
	{
		return accType;
	}

	/**
	 * @param accType the accType to set
	 */
	public void setAccType(String accType)
	{
		this.accType = accType;
	}

	/**
	 * @return the accCcy
	 */
	public String getAccCcy()
	{
		return accCcy;
	}

	/**
	 * @param accCcy the accCcy to set
	 */
	public void setAccCcy(String accCcy)
	{
		this.accCcy = accCcy;
	}

	/**
	 * @return the accName
	 */
	public String getAccName()
	{
		return accName;
	}

	/**
	 * @param accName the accName to set
	 */
	public void setAccName(String accName)
	{
		this.accName = accName;
	}

	/**
	 * @return the accBranch
	 */
	public String getAccBranch()
	{
		return accBranch;
	}

	/**
	 * @param accBranch the accBranch to set
	 */
	public void setAccBranch(String accBranch)
	{
		this.accBranch = accBranch;
	}	

	/**
	 * @return the transactionAmt
	 */
	public String getTransactionAmt()
	{
		return transactionAmt;
	}

	/**
	 * @param transactionAmt the transactionAmt to set
	 */
	public void setTransactionAmt(String transactionAmt)
	{
		this.transactionAmt = transactionAmt;
	}

	/**
	 * @return the beneAccNo
	 */
	public String getBeneAccNo()
	{
		return beneAccNo;
	}

	/**
	 * @param beneAccNo the beneAccNo to set
	 */
	public void setBeneAccNo(String beneAccNo)
	{
		this.beneAccNo = beneAccNo;
	}

	/**
	 * @return the beneCcy
	 */
	public String getBeneCcy()
	{
		return beneCcy;
	}

	/**
	 * @param beneCcy the beneCcy to set
	 */
	public void setBeneCcy(String beneCcy)
	{
		this.beneCcy = beneCcy;
	}

	/**
	 * @return the beneName
	 */
	public String getBeneName()
	{
		return beneName;
	}

	/**
	 * @param beneName the beneName to set
	 */
	public void setBeneName(String beneName)
	{
		this.beneName = beneName;
	}

	/**
	 * @return the beneBank
	 */
	public String getBeneBank()
	{
		return beneBank;
	}

	/**
	 * @param beneBank the beneBank to set
	 */
	public void setBeneBank(String beneBank)
	{
		this.beneBank = beneBank;
	}

	/**
	 * @return the beneCity
	 */
	public String getBeneCity()
	{
		return beneCity;
	}

	/**
	 * @param beneCity the beneCity to set
	 */
	public void setBeneCity(String beneCity)
	{
		this.beneCity = beneCity;
	}

	/**
	 * @return the beneBranch
	 */
	public String getBeneBranch()
	{
		return beneBranch;
	}

	/**
	 * @param beneBranch the beneBranch to set
	 */
	public void setBeneBranch(String beneBranch)
	{
		this.beneBranch = beneBranch;
	}

	/**
	 * @return the beneAddress
	 */
	public String getBeneAddress()
	{
		return beneAddress;
	}

	/**
	 * @param beneAddress the beneAddress to set
	 */
	public void setBeneAddress(String beneAddress)
	{
		this.beneAddress = beneAddress;
	}

	/**
	 * @return the status
	 */
	public String getStatus()
	{
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status)
	{
		this.status = status;
	}

	/**
	 * @return the tranType
	 */
	public String getTranType()
	{
		return tranType;
	}

	/**
	 * @param tranType the tranType to set
	 */
	public void setTranType(String tranType)
	{
		this.tranType = tranType;
	}

	/**
	 * @return the tranDate
	 */
	public String getTranDate()
	{
		return tranDate;
	}

	/**
	 * @param tranDate the tranDate to set
	 */
	public void setTranDate(String tranDate)
	{
		this.tranDate = tranDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy()
	{
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy)
	{
		this.createdBy = createdBy;
	}

	/**
	 * @return the createDate
	 */
	public String getCreateDate()
	{
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate)
	{
		this.createDate = createDate;
	}

	/**
	 * @return the userNo
	 */
	public String getUserNo()
	{
		return userNo;
	}

	/**
	 * @param userNo the userNo to set
	 */
	public void setUserNo(String userNo)
	{
		this.userNo = userNo;
	}
	/**
	 * @return the udf
	 */
	public String getUdf()
	{
		return udf;
	}

	/**
	 * @param udf the udf to set
	 */
	public void setUdf(String udf)
	{
		this.udf = udf;
	}
	/**
	 * @param channelId
	 */
	public void setChannelId(String channelId){
		this.channelId = channelId;
	}
	
	/**
	 * @return the userNo
	 */
	public String getChannelId()
	{
		return channelId;
	}
}
