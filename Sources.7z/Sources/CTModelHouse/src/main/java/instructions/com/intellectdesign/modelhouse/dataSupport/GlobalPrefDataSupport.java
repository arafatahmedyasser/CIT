package com.intellectdesign.modelhouse.dataSupport;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.formdefinition.FormDefinitionException;
import com.intellectdesign.canvas.formdefinition.FormItemDefinition;
import com.intellectdesign.canvas.formdefinition.addinfo.AdditionalDataCodeValue;
import com.intellectdesign.canvas.formdefinition.addinfo.IAdditionalDataSupport;
import com.intellectdesign.canvas.pref.amount.AmountFormat;
import com.intellectdesign.canvas.pref.amount.AmountFormatRegistry;
import com.intellectdesign.canvas.pref.date.DateFormatConfig;
import com.intellectdesign.canvas.pref.date.DateFormatRegistry;
import com.intellectdesign.canvas.preferences.PreferenceManager;
import com.intellectdesign.canvas.spec.registry.ICanvasRegistryContent;
import com.intellectdesign.canvas.value.IUserValue;
import com.intellectdesign.canvas.value.ListValue;

public class GlobalPrefDataSupport implements IAdditionalDataSupport
{

	@Override
	public ArrayList<AdditionalDataCodeValue> getAdditionalDataFor(FormItemDefinition itemDefn, IUserValue userValue,
			HashMap inputParams) throws FormDefinitionException
	{
		Iterator<ICanvasRegistryContent> listIterator = null;
		AmountFormat amtFmt = null;
		DateFormatConfig dtFmt = null;
		ListValue[] lvalue = null;
		PreferenceManager prefMngr=new PreferenceManager();
		ArrayList<AdditionalDataCodeValue> dataList = new ArrayList<AdditionalDataCodeValue>();
		try{
			//Diplaying AmountFormat comboBox in USER PREFRENCES,getting from AmountFormatRegistry 			
			//not from PreferenceCacheBuilder cache
			if(itemDefn.getItemId().equalsIgnoreCase("AMOUNT")){
				AmountFormatRegistry amountFormatRegistry = AmountFormatRegistry.getInstance();	
				listIterator = amountFormatRegistry.registryIterator();
				while (listIterator.hasNext()){
					amtFmt =  (AmountFormat) listIterator.next();
					if(amtFmt.isEnabled()==true){
						dataList.add(new AdditionalDataCodeValue(amtFmt.getAmountId(),amtFmt.getDescription()));
					}else{
						//Nothing do here
					}
			
				}
							
			}else if(itemDefn.getItemId().equalsIgnoreCase("DATEFORMAT")){
				DateFormatRegistry dateFormatRegistry = DateFormatRegistry.getInstance();
				listIterator = dateFormatRegistry.registryIterator();
				while (listIterator.hasNext()){
					dtFmt =  (DateFormatConfig) listIterator.next();
					if(dtFmt.isEnabled()==true){
						dataList.add(new AdditionalDataCodeValue(dtFmt.getDateId(),dtFmt.getDescription()));
					}else{
						//Nothing do here
					}
				
				}
			}
			else{
				lvalue=prefMngr.getSystemPreferenceValues(itemDefn.getItemId(),userValue);
				for(int i=0;i<lvalue.length;i++)
				{
					dataList.add(new AdditionalDataCodeValue(lvalue[i].getCode(), lvalue[i].getDesc()));
					
				}
			}
		}
		catch(Exception e)
		{
			LOGGER.debug("The Exception caught during update the data list" , e);
			
		}
		return dataList;
		}
	private Logger  LOGGER =  Logger.getLogger(GlobalPrefDataSupport.class); 

}
