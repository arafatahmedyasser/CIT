package com.intellectdesign.modelhouse.ratecard;

import java.util.ArrayList;
import java.util.HashMap;

import com.intellectdesign.canvas.formdefinition.FormDefinitionException;
import com.intellectdesign.canvas.formdefinition.FormItemDefinition;
import com.intellectdesign.canvas.formdefinition.addinfo.AdditionalDataCodeValue;
import com.intellectdesign.canvas.formdefinition.addinfo.IAdditionalDataSupport;
import com.intellectdesign.canvas.value.IUserValue;

public class TrainingDataSupport implements IAdditionalDataSupport
{

	@Override
	public ArrayList<AdditionalDataCodeValue> getAdditionalDataFor(FormItemDefinition itemDefn, IUserValue userValue,
			HashMap inputParams) throws FormDefinitionException
	{

        ArrayList dataList = null;
        if(itemDefn.getItemId().equals("COMBO_TRAINING"))
        {
            dataList = new ArrayList();
            dataList.add(new AdditionalDataCodeValue("INV_SUM", "In1"));
            dataList.add(new AdditionalDataCodeValue("INV_DET", "In2"));
        }
        return dataList;
    
	}

}
