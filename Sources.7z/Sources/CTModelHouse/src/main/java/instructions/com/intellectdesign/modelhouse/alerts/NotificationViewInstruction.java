/**
    COPYRIGHT NOTICE

    Copyright 2011 Intellect Design Arena Limited. All rights reserved.

    These materials are confidential and proprietary to 
    Intellect Design Arena Limited and no part of these materials should
    be reproduced, published, transmitted or distributed in any form or
    by any means, electronic, mechanical, photocopying, recording or 
    otherwise, or stored in any information storage or retrieval system
    of any nature nor should the materials be disclosed to third parties
    or used in any other manner for which this is not authorized, without
    the prior express written authorization of Intellect Design Arena Limited.
 */
/**
 * <pre>
 * ============================================================================================
 * CHANGE CODE 		              AUTHOR 			   DESCRIPTION 				  DATE
 * CBXQ313U11              Nishant Rastogi           Alerts view change          12/12/2013
 * ============================================================================================
 * </pre>
 */
package com.intellectdesign.modelhouse.alerts;

/**
 * @author karthik.yedluri
 * This is the view instruction class for notifications view
 */

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.constants.listviews.ListViewConstants;
import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.logging.PerformanceTimer;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionConstants;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;

public class NotificationViewInstruction extends AlertsAndNotificationsListViewInstruction
{
	/**
	 * This method gives the channel name
	 * 
	 * @return The channel name
	 */
	protected String getChannel()
	{
		return "INBOX";
	}

	/**
	 * This method provides the map of the sortable columns to the view definition columns.
	 * 
	 * @return strListViewColumnMap
	 */
	protected HashMap<String, String> getSortColumnMap()
	{
		HashMap<String, String> strListViewColumnMap = new HashMap<String, String>();
		strListViewColumnMap.put(AlertListView.NOTIFICATION_MESSAGES, AlertListView.NOTIFICATION_MESSAGES);
		strListViewColumnMap.put(AlertListView.STR_MESSAGE_TS, AlertListView.STR_MESSAGE_TS);
		strListViewColumnMap.put(AlertListView.SEVERITY, AlertListView.SEVERITY);
		strListViewColumnMap.put(AlertListView.SUB_PRODUCT_CODE, AlertListView.SUB_PRODUCT_CODE);
		strListViewColumnMap.put(AlertListView.ACTION, AlertListView.ACTION);
		strListViewColumnMap.put(AlertListView.SUB_PRODUCT_CODE_DISPVAL, AlertListView.SUB_PRODUCT_CODE_DISPVAL); // CBXQ313U11

		return strListViewColumnMap;

	}

	/**
	 * This method provides the unique sort field name for this view instruction class.
	 * 
	 * @return The unique sort field name for this view
	 */
	protected String getUniqueSortFieldName()
	{
		return AlertListView.DEFAULT_SORTING_FIELD_NOTIFY;
	}

	/**
	 * This method provides sorting order for the unique sort field name.
	 * 
	 * @return The sort order for the unique sort field name.
	 */
	protected String getUniqueSortFieldOrder()
	{
		return AlertListView.DEFAULT_SORTING_ORDER;
	}

	/**
	 * This method forms the view specific filters from the input params
	 * 
	 * @param hmInputParams input params in HashMap
	 * @param dataEntitlements
	 * @return notificationListViewSpecificFilter view specific filters set.
	 */
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException
	{

		HashMap notificationListViewSpecificFilter = null;

		PerformanceTimer perfTimer = new PerformanceTimer();
		perfTimer.startTimer("NotificationViewInstruction.getViewSpecificFilters - for entitled and header account");

		notificationListViewSpecificFilter = new HashMap();

		notificationListViewSpecificFilter.put(ListViewConstants.INPUT_USER_NO,
				hmInputParams.get(ListViewConstants.INPUT_USER_NO));
		notificationListViewSpecificFilter.put(ListViewConstants.INPUT_GCIF,
				hmInputParams.get(ListViewConstants.INPUT_GCIF));
		notificationListViewSpecificFilter.put(ListViewConstants.INPUT_LANGUAGE_ID,
				hmInputParams.get(ListViewConstants.INPUT_LANGUAGE_ID));
		notificationListViewSpecificFilter.put(IS_NOTIFICATION, ViewDefinitionConstants.VAL_BOOL_YES);
		perfTimer.endTimer();

		return notificationListViewSpecificFilter;

	}

	private Logger logger = Logger.getLogger(NotificationViewInstruction.class);
	public static String IS_NOTIFICATION = "IS_NOTIFICATION";

}
