/**
    COPYRIGHT NOTICE

    Copyright 2011 Intellect Design Arena Limited. All rights reserved.

    These materials are confidential and proprietary to 
    Intellect Design Arena Limited and no part of these materials should
    be reproduced, published, transmitted or distributed in any form or
    by any means, electronic, mechanical, photocopying, recording or 
    otherwise, or stored in any information storage or retrieval system
    of any nature nor should the materials be disclosed to third parties
    or used in any other manner for which this is not authorized, without
    the prior express written authorization of Intellect Design Arena Limited.
*/
package com.intellectdesign.modelhouse.views;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.tree.ITreeNode;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.TreeGridInstruction;

/**
 * @author harriesh.v
 *
 */
public class CTTreeGridViewsInstruction extends TreeGridInstruction
{
	/**
	 * Intended to frame the filters for the VDF
	 * 
	 * @param HashMap -- hminputParams
	 * @param DataEntitlements -- dataEntitlements
	 * @return HashMap
	 * @throws ViewDefinitionException 
	 * 
	 */
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException {
		
		HashMap<String, String> mapViewSpecificFilter = new HashMap<String, String>();
		
		

		return mapViewSpecificFilter;
	}

	/**
	 * Creates a map for the view metadata
	 */
	protected HashMap<String, String> getSortColumnMap() {
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		sortColumnReturnMap.put("CT_LIST_VIEW1", "CT_LIST_VIEW1");
		sortColumnReturnMap.put("CT_LIST_VIEW2","CT_LIST_VIEW2");
		sortColumnReturnMap.put("CT_LIST_VIEW3","CT_LIST_VIEW3");
		sortColumnReturnMap.put("CT_LIST_VIEW4","CT_LIST_VIEW4");
		sortColumnReturnMap.put("CT_LIST_VIEW5","CT_LIST_VIEW5");
		
		return sortColumnReturnMap;
	}

	/**
	 * Returns the field name for sorting
	 */
	protected String getUniqueSortFieldName() {
		return "CT_LIST_VIEW1";
	}

	/**
	 * Returns the sorting order
	 */
	protected String getUniqueSortFieldOrder() {
		return "DESC";
	}

	
	protected String getUniqueSortColumnName(){
		return "CT_LIST_VIEW1";
	}

	/* (non-Javadoc)
	 * @see com.intellectdesign.canvas.instructions.viewdefinition.TreeListInstruction#getDataAsTreeStructure(java.util.ArrayList)
	 */
	@Override
	public ArrayList<ITreeNode> getDataAsTreeStructure(ArrayList<HashMap<String, String>> treeList, HashMap mapInputParams)
	{
		List<Map<String, String>> systemMenuList =(List)treeList;
		Map<String, Map> menuRefMap = new HashMap<String, Map>();
		Map mNode = null;
		List<Map> menuList = new ArrayList<Map>();
		for (Map<String, String> menuItem : systemMenuList) {
			if (menuItem != null && !menuItem.isEmpty()) {
				mNode = new HashMap(menuItem);
			menuRefMap.put((String) mNode.get("ITEM_ID"), mNode);
			if (mNode.get("PARENT_ID") == null
					|| mNode.get("PARENT_ID").equals("")) {
				menuList.add(mNode);
			}
			if (mNode.get("PARENT_ID") != null
					&& ((String) mNode.get("PARENT_ID")).length() > 0) {
				if (menuRefMap.get(mNode.get("PARENT_ID")) != null) {
					List child = new ArrayList();
					child.add(mNode);
					menuRefMap.get(mNode.get("PARENT_ID"))
							.put("children",child);
				}
			}
			
			}
		}
		
		ArrayList updatedMenuList = new ArrayList();
		for (Map newNode : menuList)
		{
			updatedMenuList.add(newNode);
		}
	
		return updatedMenuList;
	}

/*	@Override
	public ArrayList<ITreeNode> getDataAsTreeStructure(ArrayList<HashMap<String, Object>> treeList,
			HashMap mapInputParams)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<ITreeNode> getDataAsTreeStructure(ArrayList<HashMap<String, Object>> treeList,
			HashMap mapInputParams)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<ITreeNode> getDataAsTreeStructure(ArrayList<HashMap<String, Object>> treeList,
			HashMap mapInputParams)
	{
		// TODO Auto-generated method stub
		return null;
	}
	
*/
	/**
	 * Instance for Logger
	 */

}
