package com.intellectdesign.modelhouse.filters;

// Author:Nithish.G

import java.io.IOException;

import javax.servlet.http.*;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.intellectdesign.canvas.login.sessions.SessionInfo;
import com.intellectdesign.canvas.login.sessions.SessionManager;
 
public class SessionFilter implements Filter {
 
    public void doFilter(ServletRequest req, ServletResponse res,
            FilterChain chain) throws IOException, ServletException {
 
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response= (HttpServletResponse) res;
        SessionManager sessionMngr = SessionManager.getInstance();
        SessionInfo sSessionInfo = sessionMngr.getUserSessionInfo(request);
        if(sSessionInfo == null)
        {
        	request.setAttribute("ERROR_MESSAGE", "Secure Session has Expired. Please login Again.");
        	sessionMngr.routeToLoginPage(request, response);
        }
        else{
          chain.doFilter(req, res);
        }
         
      
    }
    public void init(FilterConfig config) throws ServletException {
         
       
    }
    public void destroy() {
    }
}
