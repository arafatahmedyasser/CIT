/**
    COPYRIGHT NOTICE

    Copyright 2011 Intellect Design Arena Limited. All rights reserved.

    These materials are confidential and proprietary to 
    Intellect Design Arena Limited and no part of these materials should
    be reproduced, published, transmitted or distributed in any form or
    by any means, electronic, mechanical, photocopying, recording or 
    otherwise, or stored in any information storage or retrieval system
    of any nature nor should the materials be disclosed to third parties
    or used in any other manner for which this is not authorized, without
    the prior express written authorization of Intellect Design Arena Limited.
*/
package com.intellectdesign.modelhouse.views;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinition;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.ListViewsInstruction;

/**
 * @author prabhakaran.d
 *
 */
public class CTInvestSummaryViewsInstruction extends ListViewsInstruction
{
	public CTInvestSummaryViewsInstruction(){
		LOGGER.debug("CTTransactionSummaryViewsInstruction created...");
		
	} 
	/**
	 * Intended to frame the filters for the VDF
	 * 
	 * @param HashMap -- hminputParams
	 * @param DataEntitlements -- dataEntitlements
	 * @return HashMap
	 * @throws ViewDefinitionException 
	 * 
	 */
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException {
		
		HashMap<String, String> mapViewSpecificFilter = new HashMap<String, String>();
		
		

		return mapViewSpecificFilter;
	}

	/**
	 * Creates a map for the view metadata
	 */
	protected HashMap<String, String> getSortColumnMap() {
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		sortColumnReturnMap.put("INVESTMENT_TYPE", "INVESTMENT_TYPE");
		sortColumnReturnMap.put("INVESTMENT_AMT", "INVESTMENT_AMT");		
		
		return sortColumnReturnMap;
	}

	/**
	 * Returns the field name for sorting
	 */
	protected String getUniqueSortFieldName() {
		return "INVESTMENT_TYPE";
	}

	/**
	 * Returns the sorting order
	 */
	protected String getUniqueSortFieldOrder() {
		return "DESC";
	}

	
	protected String getUniqueSortColumnName(){
		return "INVESTMENT_TYPE";
	}
	
	
	protected Map<String,String> retrieveColumnDisplayMap(List listViewData, ViewDefinition viewDefinition, HashMap mapInputParams){
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		
		sortColumnReturnMap.put("INVESTMENT_TYPE","Investment Type");
		
		return sortColumnReturnMap;				
	}
	
	
	/**
	 * Instance for Logger
	 */

	static final Logger LOGGER = Logger.getLogger(CTInvestSummaryViewsInstruction.class);
}
