/**
    COPYRIGHT NOTICE

    Copyright 2011 intellectdesign Software Lab Limited. All rights reserved.

    These materials are confidential and proprietary to 
    intellectdesign Software Lab Limited and no part of these materials should
    be reproduced, published, transmitted or distributed in any form or
    by any means, electronic, mechanical, photocopying, recording or 
    otherwise, or stored in any information storage or retrieval system
    of any nature nor should the materials be disclosed to third parties
    or used in any other manner for which this is not authorized, without
    the prior express written authorization of intellectdesign Software Lab Limited.
 */
package com.intellectdesign.modelhouse.views;

import java.util.HashMap;
import java.util.List;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinition;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.GraphViewInstruction;

public class MultiSeriesChartInstruction extends GraphViewInstruction
{
	/**
	 * Return the unique sort field name for this view
	 * 
	 * @see com.intellectdesign.cib.viewdefinition.SimpleViewDefinitionInstruction#getUniqueSortFieldName()
	 */
	@Override
	protected String getUniqueSortFieldName()
	{
		return "YEARS";
	}

	/**
	 * Get the sort order for this unique sort field name for this view
	 * 
	 * @see com.intellectdesign.cib.viewdefinition.SimpleViewDefinitionInstruction#getUniqueSortFieldOrder()
	 */
	@Override
	protected String getUniqueSortFieldOrder()
	{
		return "ASC";
	}

	@Override
	protected HashMap<String, String> getSortColumnMap()
	{
		HashMap<String, String> listViewColumnMap = new HashMap<String, String>();

		listViewColumnMap.put("YEARS", "YEARS");
		listViewColumnMap.put("REVENUE", "REVENUE");
		listViewColumnMap.put("PROFITS", "PROFITS");
		listViewColumnMap.put("PRE_PROFITS", "PRE_PROFITS");
		return listViewColumnMap;
	}
	

	/**
	 * This method forms the view specific filters from the input params
	 * 
	 * @param hmInputParams, dataEntitlements
	 * @return mapViewSpecificFilter
	 */
//	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
//			throws ViewDefinitionException
//	{
//		HashMap mapViewSpecificFilter = null;
//		mapViewSpecificFilter = new HashMap();
//		mapViewSpecificFilter.put("USER_PREFEERENCE_DATE_FORMAT",hmInputParams.get("USER_PREFEERENCE_DATE_FORMAT"));
//		
//		return mapViewSpecificFilter;
//	}

	@Override
	protected HashMap processResponse(List listViewData, ViewDefinition viewDefinition, HashMap mapInputParams)
			throws ViewDefinitionException
	{

		return super.processResponse(listViewData, viewDefinition, mapInputParams);
	}

	@Override
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException
	{
		// TODO Auto-generated method stub
		return null;
	}

	
}
