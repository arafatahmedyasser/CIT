/**
    COPYRIGHT NOTICE

    Copyright 2011 Intellect Design Arena Limited. All rights reserved.

    These materials are confidential and proprietary to 
    Intellect Design Arena Limited and no part of these materials should
    be reproduced, published, transmitted or distributed in any form or
    by any means, electronic, mechanical, photocopying, recording or 
    otherwise, or stored in any information storage or retrieval system
    of any nature nor should the materials be disclosed to third parties
    or used in any other manner for which this is not authorized, without
    the prior express written authorization of Intellect Design Arena Limited.
*/
package com.intellectdesign.modelhouse.views;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinition;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.ListViewsInstruction;

/**
 * @author prabhakaran.d
 *
 */
public class CTTransactionSummaryViewsInstruction extends ListViewsInstruction
{
	public CTTransactionSummaryViewsInstruction(){
		LOGGER.debug("CTTransactionSummaryViewsInstruction created...");
		
	} 
	/**
	 * Intended to frame the filters for the VDF
	 * 
	 * @param HashMap -- hminputParams
	 * @param DataEntitlements -- dataEntitlements
	 * @return HashMap
	 * @throws ViewDefinitionException 
	 * 
	 */
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException {
		
		HashMap<String, String> mapViewSpecificFilter = new HashMap<String, String>();
		
		

		return mapViewSpecificFilter;
	}

	/**
	 * Creates a map for the view metadata
	 */
	protected HashMap<String, String> getSortColumnMap() {
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		sortColumnReturnMap.put("TRANSACTION_REF_NO", "TRANSACTION_REF_NO");
		sortColumnReturnMap.put("DEBIT_ACC_NO", "DEBIT_ACC_NO");
		sortColumnReturnMap.put("INITIAT_DATE", "INITIAT_DATE");
		sortColumnReturnMap.put("BENE_ACC_NO", "BENE_ACC_NO");
		sortColumnReturnMap.put("BENE_NAME", "BENE_NAME");
		sortColumnReturnMap.put("PAYMENT_TYPE", "PAYMENT_TYPE");
		sortColumnReturnMap.put("PAYMENT_CCY", "PAYMENT_CCY");
		sortColumnReturnMap.put("PAYMENT_AMT", "PAYMENT_AMT");
		sortColumnReturnMap.put("CREATED_BY", "CREATED_BY");
		sortColumnReturnMap.put("REASON_FOR_REJECT", "REASON_FOR_REJECT");
		sortColumnReturnMap.put("STATUS", "STATUS");		
		return sortColumnReturnMap;
	}

	/**
	 * Returns the field name for sorting
	 */
	protected String getUniqueSortFieldName() {
		return "TRANSACTION_REF_NO";
	}

	/**
	 * Returns the sorting order
	 */
	protected String getUniqueSortFieldOrder() {
		return "DESC";
	}

	
	protected String getUniqueSortColumnName(){
		return "TRANSACTION_REF_NO";
	}
	
	
	protected Map<String,String> retrieveColumnDisplayMap(List listViewData, ViewDefinition viewDefinition, HashMap mapInputParams){
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		
		sortColumnReturnMap.put("TRANSACTION_REF_NO","Reference Number");
		
		return sortColumnReturnMap;				
	}
	
	
	/**
	 * Instance for Logger
	 */

	static final Logger LOGGER = Logger.getLogger(CTTransactionSummaryViewsInstruction.class);
}
