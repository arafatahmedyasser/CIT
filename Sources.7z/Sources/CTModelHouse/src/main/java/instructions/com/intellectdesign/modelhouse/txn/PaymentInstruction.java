/**
 * Copyright 2014. Intellect Design Arena Limited Limited. All rights reserved. 
 * 
 * These materials are confidential and proprietary to Intellect Design Arena Limited 
 * Limited and no part of these materials should be reproduced, published, transmitted
 * or distributed in any form or by any means, electronic, mechanical, photocopying, 
 * recording or otherwise, or stored in any information storage or retrieval system 
 * of any nature nor should the materials be disclosed to third parties or used in any 
 * other manner for which this is not authorized, without the prior express written 
 * authorization of Intellect Design Arena Limited Limited.
 * 
 */
package com.intellectdesign.modelhouse.txn;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.intellectdesign.canvas.database.DatabaseConstants;
import com.intellectdesign.canvas.database.DatabaseException;
import com.intellectdesign.canvas.database.DatabaseRequest;
import com.intellectdesign.canvas.database.DatabaseResult;
import com.intellectdesign.canvas.formdefinition.addinfo.AdditionalDataCodeValue;
import com.intellectdesign.canvas.logger.Logger;
import com.intellectdesign.canvas.properties.reader.PropertyReader;

/**
 *
 * @Version 1.0
 */
public class PaymentInstruction
{
	private static final Logger logger = Logger.getLogger(PaymentInstruction.class);
	
	
	
	public void insertTxnData(TxnData txnData) throws DatabaseException
	{
		// First prepare the hashmap for passing to the db layer.
		DatabaseRequest dbRequest = null;
		HashMap dataMap = new HashMap();

		logger.ctinfo("CTTXN0019");

		dataMap.put("REFERENCE_NO", txnData.getReferenceNo());
		dataMap.put("ACC_NO", txnData.getAccNo());
		dataMap.put("ACC_TYPE", txnData.getAccType());
		dataMap.put("ACC_CCY", txnData.getAccCcy());
		dataMap.put("ACC_NAME", txnData.getAccName());
		
		dataMap.put("ACC_BRANCH", txnData.getAccBranch());		
		dataMap.put("TRANSACTION_AMT", txnData.getTransactionAmt());
		dataMap.put("TRAN_TYPE", txnData.getTranType());
		dataMap.put("TRAN_DATE", txnData.getTranDate());
		dataMap.put("CREATED_DATE", txnData.getCreateDate());
		
		dataMap.put("CREATED_BY", txnData.getCreatedBy());		
		dataMap.put("BENE_ACC_NO", txnData.getBeneAccNo());
		dataMap.put("BENE_CCY", txnData.getBeneCcy());
		dataMap.put("BENE_NAME", txnData.getBeneName());
		dataMap.put("BENE_BANK", txnData.getBeneBank());
		
		dataMap.put("BENE_CITY", txnData.getBeneCity());
		dataMap.put("BENE_BRANCH", txnData.getBeneBranch());
		dataMap.put("BENE_ADDRESS", txnData.getBeneAddress());
		dataMap.put("STATUS", txnData.getStatus());
		dataMap.put("USER_NO", txnData.getUserNo());
		dataMap.put("UDF", "");
		dataMap.put("TXN_CHANNEL", txnData.getChannelId());
		logger.ctdebug("dataMap:"+dataMap);
		
		
		// Now execute the query.
		try
		{
			dbRequest = new DatabaseRequest();
			dbRequest.setDataSource(DatabaseConstants.DEFAULT_DATASOURCE);
			dbRequest.setDataAccessMapKey("TXN_MODELHOUSE_MNT");
			dbRequest.setOperation(DatabaseConstants.INSERT);
			dbRequest.setOperationExtension("TRASACTION");
			dbRequest.setData(dataMap);

			dbRequest.execute();
			logger.ctdebug("CTTXN0020");
		} catch (DatabaseException dbException)
		{
			logException(dbException, "TXN0001");
			throw dbException;
		} finally
		{
			logger.ctinfo("CTTXN0022");
		}
	}
	
	public void saveTxnData(TxnData txnData, String refNo) throws DatabaseException
	{
		logger.ctinfo("CTTXN0018");
		boolean isTxnDeleted = false;
		isTxnDeleted = deleteTxn(refNo);
		logger.ctdebug("CTTXN0040");
		if(isTxnDeleted){
			try{
				insertTxnData(txnData);	
			}catch (DatabaseException dbException)
			{
				logException(dbException, "TXN0003");
				throw dbException;
			}				
		}
		logger.ctinfo("CTTXN0019");
	}
	public boolean rejectTxn(Map paramMap) throws DatabaseException
	{
		logger.ctinfo("CTTXN0018");
		boolean isRejected = false;
		DatabaseRequest dbRequest = null;
		try
		{
			dbRequest = new DatabaseRequest();
			dbRequest.setDataSource(DatabaseConstants.DEFAULT_DATASOURCE);
			dbRequest.setDataAccessMapKey("TXN_MODELHOUSE_MNT");
			dbRequest.setOperation(DatabaseConstants.UPDATE);
			dbRequest.setOperationExtension("TRXN_REJECT");
			dbRequest.setData(paramMap);
			dbRequest.execute();
			isRejected = true;
			logger.ctdebug("CTTXN0020");
		} catch (DatabaseException dbException)
		{
			logException(dbException, "TXN0002");
			throw dbException;
		}		
		logger.ctinfo("CTTXN0019");
		return isRejected;
	}
	public boolean authorizeTxn(Map paramMap) throws DatabaseException
	{
		logger.ctinfo("CTTXN0036");
		boolean isAuthorized = false;
		DatabaseRequest dbRequest = null;
		try
		{
			dbRequest = new DatabaseRequest();
			dbRequest.setDataSource(DatabaseConstants.DEFAULT_DATASOURCE);
			dbRequest.setDataAccessMapKey("TXN_MODELHOUSE_MNT");
			dbRequest.setOperation(DatabaseConstants.UPDATE);
			dbRequest.setOperationExtension("TRXN_AUTHORIZE");
			dbRequest.setData(paramMap);
			dbRequest.execute();
			isAuthorized = true;
			logger.ctdebug("CTTXN0037");
		} catch (DatabaseException dbException)
		{
			logException(dbException, "TXN0007");
			throw dbException;
		}		
		logger.ctinfo("CTTXN0038");
		return isAuthorized;
	}
	public boolean deleteTxn(String refNo) throws DatabaseException
	{
		logger.ctinfo("CTTXN0036");
		boolean isTxnDeleted = false;
		DatabaseRequest dbRequest = null;
		try
		{
			dbRequest = new DatabaseRequest();
			dbRequest.setDataSource(DatabaseConstants.DEFAULT_DATASOURCE);
			dbRequest.setDataAccessMapKey("TXN_MODELHOUSE_MNT");
			dbRequest.setOperation(DatabaseConstants.DELETE);
			dbRequest.setOperationExtension("TRASACTION");
			dbRequest.addFilter("REFERENCE_NO", refNo);

			dbRequest.execute();
			isTxnDeleted = true;
			logger.ctdebug("CTTXN0037");
		} catch (DatabaseException dbException)
		{
			logException(dbException, "TXN0008");
			throw dbException;
		} 
			
		logger.ctinfo("CTTXN0038");
		return isTxnDeleted;
	}
	
	public HashMap getBeneDtls(String beneAccNo) throws DatabaseException{
		logger.ctinfo("CTTXN0024");
		DatabaseRequest dbReq = new DatabaseRequest();
		DatabaseResult dbResult = null;
		List returnedList = null;
		HashMap resultMap = new HashMap();
		try {
			dbReq.setDataSource(DatabaseConstants.DEFAULT_DATASOURCE);
			dbReq.setDataAccessMapKey("TXN_MODELHOUSE_MNT");
			dbReq.setOperation(DatabaseConstants.SELECT);
			dbReq.setOperationExtension("BENE_DATA");
			dbReq.addFilter("BENE_ACC_NO", beneAccNo);
			dbResult = dbReq.execute();
			returnedList = dbResult.getReturnedList();
			
			resultMap.put("BENE_ACC_NO", returnedList);
					
		} catch (DatabaseException dbException)
		{
			logException(dbException, "TXN0004");
			throw dbException;
		}
		logger.ctinfo("CTTXN0025");
		return resultMap;
	}
	
	public HashMap getAccDtls(String accNo) throws DatabaseException{
		logger.ctinfo("CTTXN0026");
		DatabaseRequest dbReq = new DatabaseRequest();
		DatabaseResult dbResult = null;
		List returnedList = null;
		HashMap resultMap = new HashMap();
		try {
			dbReq.setDataSource(DatabaseConstants.DEFAULT_DATASOURCE);
			dbReq.setDataAccessMapKey("TXN_MODELHOUSE_MNT");
			dbReq.setOperation(DatabaseConstants.SELECT);
			dbReq.setOperationExtension("ACCOUNT_DATA");
			dbReq.addFilter("ACCOUNT_NO", accNo);
			dbResult = dbReq.execute();
			returnedList = dbResult.getReturnedList();
			
			resultMap.put("ACCOUNT_NO", returnedList);
					
		} catch (DatabaseException dbException)
		{
			logException(dbException, "TXN0005");
			throw dbException;
		}
		logger.ctinfo("CTTXN0027");
		return resultMap;
	}
	
	public Map getTxnDtls(String refNo) throws DatabaseException{
		logger.ctinfo("CTTXN0026");
		DatabaseRequest dbReq = new DatabaseRequest();
		DatabaseResult dbResult = null;
		List returnedList = null;
		Map resultMap = new HashMap();
		try {
			dbReq.setDataSource(DatabaseConstants.DEFAULT_DATASOURCE);
			dbReq.setDataAccessMapKey("TXN_MODELHOUSE_MNT");
			dbReq.setOperation(DatabaseConstants.SELECT);
			dbReq.setOperationExtension("GET_PYMNT_ACC_DATA");	
			dbReq.addFilter("REFERENCE_NO", refNo);
			dbResult = dbReq.execute();
			returnedList = dbResult.getReturnedList();
			resultMap = (HashMap)returnedList.get(0);
		} catch (DatabaseException dbException)
		{
			logException(dbException, "TXN0005");
			throw dbException;
		}
		logger.ctinfo("CTTXN0027");
		return resultMap;
	}
	/**
	 * Helper method to log the exception
	 * 
	 * @param ex The exception to be logged
	 * @param errorCode The error code to
	 */
	private void logException(Exception ex, String errorCode)
	{
		logger.cterror("CTTXN0023", ex, ex.getMessage(), mReader.retrieveProperty(errorCode));
	}
	
	public List getRecipients(String refNo) throws DatabaseException {
		logger.ctinfo("CTTXN0026");
		DatabaseRequest dbReq = new DatabaseRequest();
		DatabaseResult dbResult = null;
		List returnedList = null;
		try {
			dbReq.setDataSource(DatabaseConstants.DEFAULT_DATASOURCE);
			dbReq.setDataAccessMapKey("TXN_MODELHOUSE_MNT");
			dbReq.setOperation(DatabaseConstants.SELECT);
			dbReq.setOperationExtension("GET_RECIPIENTS_DATA");	
			dbReq.addFilter("REFERENCE_NO", refNo);
			dbResult = dbReq.execute();
			returnedList = dbResult.getReturnedList();
		} catch (DatabaseException dbException)
		{
			logException(dbException, "TXN0005");
			throw dbException;
		}
		logger.ctinfo("CTTXN0027");
		return returnedList;
	}
	public Map getMaker(String refNo) throws DatabaseException {
		logger.ctinfo("CTTXN0026");
		DatabaseRequest dbReq = new DatabaseRequest();
		DatabaseResult dbResult = null;
		List returnedList = null;
		Map resultMap = null;
		try {
			dbReq.setDataSource(DatabaseConstants.DEFAULT_DATASOURCE);
			dbReq.setDataAccessMapKey("TXN_MODELHOUSE_MNT");
			dbReq.setOperation(DatabaseConstants.SELECT);
			dbReq.setOperationExtension("GET_MAKER_DATA");	
			dbReq.addFilter("REFERENCE_NO", refNo);
			dbResult = dbReq.execute();
			returnedList = dbResult.getReturnedList();
			resultMap = (HashMap)returnedList.get(0);
		} catch (DatabaseException dbException)
		{
			logException(dbException, "TXN0005");
			throw dbException;
		}
		logger.ctinfo("CTTXN0027");
		return resultMap;
	}
	private static PropertyReader mReader = new PropertyReader("txn_properties");
}
