package com.intellectdesign.modelhouse.views;

import java.util.HashMap;

import com.intellectdesign.canvas.entitlement.DataEntitlements;
import com.intellectdesign.canvas.viewdefinition.ViewDefinitionException;
import com.intellectdesign.canvas.viewdefinition.instruction.ListViewsInstruction;

public class StrucExecSummaryViewsInstruction extends ListViewsInstruction
{

	@Override
	public HashMap getViewSpecificFilters(HashMap hmInputParams, DataEntitlements dataEntitlements)
			throws ViewDefinitionException
	{
		HashMap<String, String> mapViewSpecificFilter = new HashMap<String, String>();

		return mapViewSpecificFilter;
	}

	@Override
	protected String getUniqueSortFieldName()
	{
		// TODO Auto-generated method stub
		return "STR_ID";
	}

	@Override
	protected String getUniqueSortFieldOrder()
	{
		// TODO Auto-generated method stub
		return "DESC";
	}
	protected String getUniqueSortColumnName(){
		return "STR_ID";
	}
	@Override
	protected HashMap<String, String> getSortColumnMap()
	{
		HashMap<String, String> sortColumnReturnMap = new HashMap<String, String>();
		sortColumnReturnMap.put("STR_ID", "STR_ID");
		sortColumnReturnMap.put("STR_NAME", "STR_NAME");
		sortColumnReturnMap.put("INSTR_ID", "INSTR_ID");
		sortColumnReturnMap.put("CONTRA_ACC_NO", "CONTRA_ACC_NO");
		sortColumnReturnMap.put("CONTRA_ACC_CCY", "CONTRA_ACC_CCY");
		sortColumnReturnMap.put("CONTROL_ACC_NO", "CONTROL_ACC_NO");
		sortColumnReturnMap.put("CONTROL_ACC_CCY", "CONTROL_ACC_CCY");
		sortColumnReturnMap.put("AMOUNT", "AMOUNT");
		sortColumnReturnMap.put("EXEC_DATE", "EXEC_DATE");
		sortColumnReturnMap.put("EXEC_STATUS", "EXEC_STATUS");
		sortColumnReturnMap.put("FAILURE_REASON", "FAILURE_REASON");
		sortColumnReturnMap.put("CR_DR", "CR_DR");
		sortColumnReturnMap.put("TXN_REF_NO", "TXN_REF_NO");
		sortColumnReturnMap.put("REVERSAL_STATUS", "REVERSAL_STATUS");
		return sortColumnReturnMap;
	}

}
