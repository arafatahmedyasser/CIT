/**
 * Copyright 2014. Intellect Design Arena Limited Limited. All rights reserved. 
 * 
 * These materials are confidential and proprietary to Intellect Design Arena Limited 
 * Limited and no part of these materials should be reproduced, published, transmitted
 * or distributed in any form or by any means, electronic, mechanical, photocopying, 
 * recording or otherwise, or stored in any information storage or retrieval system 
 * of any nature nor should the materials be disclosed to third parties or used in any 
 * other manner for which this is not authorized, without the prior express written 
 * authorization of Intellect Design Arena Limited Limited.
 * 
 */
package com.intellectdesign.modelhouse.task.initializer;

import java.util.HashMap;
import java.util.Map;

import com.intellectdesign.canvas.spec.registry.ICanvasRegistry;
import com.intellectdesign.canvas.spec.registry.ICanvasRegistryContent;
import com.intellectdesign.canvas.spec.registry.ICanvasRegistryIndexer;
import com.intellectdesign.canvas.web.config.ActionMap;

/**
 * This is the default Action Map indexer provided by the Canvas Platform. This indexer uses only Screen code as the
 * basis for the indexing. In case the provided action mapping in the registry has multiple entries for the same screen
 * code, then the most recent entry added to the registry will be returned when a lookup is done using this indexer
 * 
 * @Version 1.0
 */
public class ClassicalActionMapIndexer implements ICanvasRegistryIndexer
{
	private Map<String, ActionMap> localIndex = null;
	@SuppressWarnings("unused")
	private ICanvasRegistry actionRegistry = null;

	public ClassicalActionMapIndexer()
	{
		localIndex = new HashMap<String, ActionMap>();
	}

	/**
	 * Here, we update the index with the new content.
	 * 
	 * @param aContent The new content being added
	 * @see com.intellectdesign.canvas.spec.registry.ICanvasRegistryListener#contentAdded(com.intellectdesign.canvas.spec.registry.ICanvasRegistryContent)
	 */
	@Override
	public void contentAdded(ICanvasRegistryContent aContent)
	{
		if (aContent instanceof ActionMap)
		{
			ActionMap actionMap = (ActionMap) aContent;
			
			String prodindexKey = actionMap.getProductCode();
			
			String functionindexKey = actionMap.getFunctionCode();
			
			String screenindexKey = actionMap.getScreenCode();
			
			localIndex.put(prodindexKey+"_"+functionindexKey+"_"+screenindexKey, actionMap);
		}
	}

	/**
	 * @param aContent
	 * @see com.intellectdesign.canvas.spec.registry.ICanvasRegistryListener#contentRemoved(com.intellectdesign.canvas.spec.registry.ICanvasRegistryContent)
	 */
	@Override
	public void contentRemoved(ICanvasRegistryContent aContent)
	{
		if (aContent instanceof ActionMap)
		{
			ActionMap actionMap = (ActionMap) aContent;
			String indexKey = actionMap.getScreenCode();
			// If the content in index is same object as that passed, then remove the same.
			if (localIndex.containsValue(aContent))
				localIndex.remove(indexKey);
		}
	}

	/**
	 * @param oldContent
	 * @param newContent
	 * @return
	 * @see com.intellectdesign.canvas.spec.registry.ICanvasRegistryListener#contentReplacing(com.intellectdesign.canvas.spec.registry.ICanvasRegistryContent,
	 *      com.intellectdesign.canvas.spec.registry.ICanvasRegistryContent)
	 */
	@Override
	public boolean contentReplacing(ICanvasRegistryContent oldContent, ICanvasRegistryContent newContent)
	{
		contentRemoved(oldContent);
		contentAdded(newContent);
		return true;
	}

	/**
	 * The Default Parameter list
	 * screenCode, productCode, subProductCode, functionCode
	 * @param args
	 * @return
	 * @see com.intellectdesign.canvas.spec.registry.ICanvasRegistryIndexer#match(java.lang.Object[])
	 */
	@Override
	public ICanvasRegistryContent match(Object... args)
	{
		ICanvasRegistryContent matchItem = null;
		String functionindexKey = "";
		String prodindexKey = "";
		String screenindexKey = "";
		String indexKey = "";
		
		if (args.length > 0)
		{
			// Read only the first argument and that too is expected to be a String. Else convert the same to a String
			// and then search
			screenindexKey = args[0] != null ? args[0].toString() : "";
			prodindexKey = args[1] != null ? args[1].toString() : "";
			functionindexKey = args[3] != null ? args[3].toString() : "";
			
			indexKey = prodindexKey+"_"+functionindexKey+"_"+screenindexKey;
		}
		if (localIndex.containsKey(indexKey))
			matchItem = localIndex.get(indexKey);

		return matchItem;
	}

	/**
	 * @param parentRegistry
	 * @see com.intellectdesign.canvas.spec.registry.ICanvasRegistryIndexer#setRegistry(com.intellectdesign.canvas.spec.registry.ICanvasRegistry)
	 */
	@Override
	public void setRegistry(ICanvasRegistry parentRegistry)
	{
		actionRegistry = parentRegistry;
	}

}
