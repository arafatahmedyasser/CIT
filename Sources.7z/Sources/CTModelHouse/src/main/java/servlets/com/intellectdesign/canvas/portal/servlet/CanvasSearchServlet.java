/**
 * Copyright 2015. Intellect Design Arena Limited. All rights reserved. 
 * 
 * These materials are confidential and proprietary to Intellect Design Arena 
 * Limited and no part of these materials should be reproduced, published, transmitted
 * or distributed in any form or by any means, electronic, mechanical, photocopying, 
 * recording or otherwise, or stored in any information storage or retrieval system 
 * of any nature nor should the materials be disclosed to third parties or used in any 
 * other manner for which this is not authorized, without the prior express written 
 * authorization of Intellect Design Arena Limited.
 * 
 */
package com.intellectdesign.canvas.portal.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.intellectdesign.canvas.data.conversion.util.HashMapToJSONConverter;
import com.intellectdesign.canvas.database.DatabaseConstants;
import com.intellectdesign.canvas.database.DatabaseException;
import com.intellectdesign.canvas.database.DatabaseRequest;
import com.intellectdesign.canvas.utils.StringUtils;

/**
 * This is a search servlet that fetches the search result from within the Canvas. If the user is a guest user, then the
 * scope is restricted to only zolog
 */
public class CanvasSearchServlet extends HttpServlet
{

	/**
	 * Internal constant for serialization purposes
	 */
	private static final long serialVersionUID = -3756526267453906059L;

	/**
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		// First let us retrieve the search term.
		String searchterm = req.getParameter("keys");
		ArrayList<HashMap> searchResults = new ArrayList<HashMap>();
		if (!StringUtils.isEmpty(searchterm))
		{
			populateSearchResults( StringUtils.urlDecode(searchterm), searchResults);
		}
		// Convert the response into a JSON and stream it back.
		String responseJson = HashMapToJSONConverter.convertListToJSONFormat(searchResults);
		// Stream out the results
		resp.setContentType("application/json;charset=UTF-8");
		resp.setHeader("Cache-Control", "no-cache, must-revalidate, post-check=0, pre-check=0");
		resp.getWriter().write(responseJson);
	}

	/**
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		super.doGet(req, resp);
	}

	/**
	 * 
	 * @param searchTerm
	 * @param searchResults
	 */
	private void populateSearchResults(String searchTerm, ArrayList<HashMap> searchResults)
	{
		String urlPrefix = "http://hdfcdemo.intellect.co.in:20027/iportalweb/iportal/jsps/preAuth.jsp?APPID=";
		String[] allTokens = StringUtils.split(searchTerm, " ");
		StringBuilder sb = new StringBuilder();
		StringBuilder whereCond = new StringBuilder();
		int index = 1;
		for (String aToken : allTokens)
		{
			sb.append("case when lower(APP_SNIPPET_DESC) like '%").append(aToken.toLowerCase())
					.append("%' then 1 else 0 end ");
			whereCond.append("  lower(APP_SNIPPET_DESC) like '%").append(aToken.toLowerCase()).append("%' ");
			if (index < allTokens.length)
			{
				sb.append(" + ");
				whereCond.append(" or ");
			}
			index++;
		}

		DatabaseRequest dbRequest = new DatabaseRequest();
		dbRequest.setOperation(DatabaseConstants.SELECT);
		dbRequest.setDataAccessMapKey("SEARCH");
		dbRequest.addFilter("MATCH_SECTION", sb.toString());
		dbRequest.addFilter("WHERE_SECTION", whereCond.toString());

		try
		{
			List<HashMap> allResults = dbRequest.execute().getReturnedList();
			searchResults.addAll(allResults);
		} catch (DatabaseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
