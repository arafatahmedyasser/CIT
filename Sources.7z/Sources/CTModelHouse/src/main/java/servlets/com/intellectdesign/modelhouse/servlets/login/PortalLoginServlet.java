package com.intellectdesign.modelhouse.servlets.login;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.intellectdesign.canvas.common.UserValue;
import com.intellectdesign.canvas.login.sessions.SessionManager;
import com.intellectdesign.canvas.value.IUserValue;

/**
 * Sample simplified login servlet to demonstrate how a login sequence can be executed
 * 
 */
public class PortalLoginServlet extends HttpServlet
{
	private static final long serialVersionUID = 7863545661039880552L;

	public void doGet(HttpServletRequest pReq, HttpServletResponse pRes) throws ServletException
	{
		doPost(pReq, pRes);
	}

	/**
	 * Handles all the requests. In this sample application, the login page uses the below conventions -
	 * <ul>
	 * <li>transactionCode - Has 'logn' or 'logout' to indicate whether the ask is to login or logout</li>
	 * </ul>
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException
	{
		String transactionCode = request.getParameter("transactionCode");
		if ("logn".equals(transactionCode))
			handleLogin(request, response);
		else if ("logout".equals(transactionCode))
			handleLogout(request, response);
	}

	/**
	 * Handles the login sequence. Here we extract the login parameters from the request into a IUserValue and then pass
	 * it to Canvas's SessionManager to execute the login
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 */
	private void handleLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException
	{
		IUserValue userValue = extractLoginParameters(request);
		SessionManager sessManager = SessionManager.getInstance();
		try
		{
			sessManager.loginUser(request, response, userValue);
		} catch (IOException iex)
		{
			throw new ServletException(iex);
		}
	}

	/**
	 * Handles the logout sequence. Here we ask Canvas's SessionManager to execute the logout sequence
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 */
	private void handleLogout(HttpServletRequest request, HttpServletResponse response) throws ServletException
	{
		SessionManager sessManager = SessionManager.getInstance();
		try
		{
			sessManager.logoutUser(request, response);
		} catch (IOException iex)
		{
			throw new ServletException(iex);
		}
	}

	/**
	 * Helper method to extract the login related details. The key information that is required to be populated in the
	 * UserValue are -
	 * <ul>
	 * <li>loginId - This is the login Id provided by the user</li>
	 * <li>userPin - This is the first factor (static password) provided by the user</li>
	 * <li>rSAPin - This is the second factor password (the running token, etc) that is used to authenticate the user</li>
	 * <li>langId - This is the language selected by the user at the time of login</li>
	 * <li>simulated - This is a flag indicating whether this login is happening in simulation mode</li>
	 * <li>simulatingUserNo - This is the user Number of the user who is simulating the actual login Id provided</li>
	 * </ul>
	 * 
	 * @param request
	 * @return
	 */
	private IUserValue extractLoginParameters(HttpServletRequest request)
	{
		UserValue userValue = new UserValue();
		// Set the login Id into the User Value
		userValue.setLoginId(request.getParameter("loginID"));
		// Set the simulation model flag in the user Value
		String isSimulationMode = request.getParameter("isSimulated");
		if (isSimulationMode != null && "true".equals(isSimulationMode))
		{
			userValue.setSimulated(true);
			userValue.setSimulatingUserNo(request.getParameter("simulatingUserNo"));
		}
		// Set the password into the user value
		userValue.setUserPin(request.getParameter("loginPSW"));
		// Set the language used / preferred by user into the user value
		String langId = request.getParameter("language");
		userValue.setLangId(langId);
		// In case of a 2 factor (like running token / rsa pin, etc, set that value into the user value
		userValue.setRSAPin(request.getParameter("RSAPin"));

		return userValue;
	}

}