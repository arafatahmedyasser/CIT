package com.intellectdesign.modelhouse.task.initializer;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;

import com.intellectdesign.canvas.config.ConfigurationException;
import com.intellectdesign.canvas.config.ConfigurationManager;
import com.intellectdesign.canvas.deviceband.DeviceBand;
import com.intellectdesign.canvas.deviceband.DeviceBandRegistry;
import com.intellectdesign.canvas.deviceband.DeviceCategory;
import com.intellectdesign.canvas.deviceband.TargetedFramework;
import com.intellectdesign.canvas.exceptions.common.BaseException;
import com.intellectdesign.canvas.pref.amount.AmountFormatRegistry;
import com.intellectdesign.canvas.pref.date.DateFormatRegistry;
import com.intellectdesign.canvas.web.config.ActionMapRegistry;
import com.intellectdesign.canvas.web.themes.ThemesRegistry;

public class ModelHouseStartupListner implements ServletContextListener {
	/**
	 * this is ref to ServletContextEventDestory
	 * 
	 * @param contextEvent
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextDestroyed(ServletContextEvent contextEvent) {
		System.out.println("downnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
	}

	/**
	 * this is ref to intial ServletContextEventy
	 * 
	 * @param contextEvent
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextInitialized(ServletContextEvent contextEvent) {

		ConfigurationManager configMgr = ConfigurationManager.getInstance();
		configMgr.initializeFromBundle("MyImplementation");
		try {
			initializeForwardMappings();

			initializeDeviceBand();

			initializeThemes(contextEvent.getServletContext());// CT_THEME

			initializeAmountFormats();// Initialization of custom amount formats

			initializeDateFormats();// Initialization of custom date formats
		} catch (BaseException e) {
			throw new ConfigurationException("INIT_ERR_MODELHOUSE",
					e.getErrorMessage(), e);
		}
	}

	private void initializeDateFormats() throws BaseException {

		DateFormatRegistry dateFormatRegistry = DateFormatRegistry
				.getInstance();
		dateFormatRegistry.register("cuser-dateformats.xml");

	}

	/**
	 * This method initializes the custom Amount Formats. These Formats can be
	 * registered using the class AmountFormatRegistry.
	 */
	private void initializeAmountFormats() throws BaseException {
		AmountFormatRegistry amountFormatRegistry = AmountFormatRegistry
				.getInstance();
		amountFormatRegistry.register("cuser-amountformats.xml");

	}

	/**
	 * This methods loads the default actionmapping
	 * 
	 * Class<ICanvasRegistryIndexer> indexerClass =
	 * (Class<ICanvasRegistryIndexer>)
	 * ClassicalActionMapIndexer.class.getInterfaces()[0];
	 * ActionMapRegistry.setCustomInstanceIndexer(indexerClass);
	 * ActionMapRegistry actionMapRegistry =
	 * ActionMapRegistry.getCustomInstance();
	 * 
	 * ActionMap actionMap = (ActionMap) actionMapRegistry.lookup(screenCode,
	 * product, subproduct, functionCode);
	 * 
	 */
	private void initializeForwardMappings() throws BaseException {
		ActionMapRegistry
				.setCustomInstanceIndexer(ClassicalActionMapIndexer.class);
		ActionMapRegistry actionMapRegistry = ActionMapRegistry
				.getCustomInstance();
		actionMapRegistry.register("coresvs-forward.mapping");
		actionMapRegistry.register("alerts-forward.mapping");
		actionMapRegistry.register("cuser-forward.mapping");
	}

	// CT_THEME starts

	/**
	 * This method initializes the custom themes. These themes can be registered
	 * using the class ThemesRegistry.
	 */
	private void initializeThemes(ServletContext servContext)
			throws BaseException {

		ThemesRegistry themeRegistry = ThemesRegistry.getInstance();
		themeRegistry.register(servContext.getContextPath(),
				servContext.getRealPath("css/style/cssconfig.xml"));

	}

	// CT_THEME ends

	/**
	 * This methods loads the list of device bands available for the FW to
	 * render
	 * 
	 * 
	 * 
	 */

	private void initializeDeviceBand() throws BaseException {

		DeviceBandRegistry deviceBandRegistry = DeviceBandRegistry
				.getInstance();

		DeviceBand aBand = new DeviceBand("A");
		aBand.setResolutionInPixels(new int[] { -1, -1 });
		aBand.setBrowserFamily("ALL");
		aBand.setBrowserVersion("ALL");
		aBand.setOsVendor("ALL");
		aBand.setOsVersion("ALL");
		aBand.setOverridable(true);
		aBand.setTargetFramework(TargetedFramework.EXT_JS); // The framework
															// to use if
															// this device
															// band matches
		aBand.setDeviceCategory(DeviceCategory.ALL);
		deviceBandRegistry.register(aBand);

		aBand = new DeviceBand("M");
		aBand.setResolutionInPixels(new int[] { -1, -1 });
		aBand.setBrowserFamily("ALL");
		aBand.setBrowserVersion("ALL");
		aBand.setOsVendor("ALL");
		aBand.setOsVersion("ALL");
		aBand.setOverridable(true);
		aBand.setTargetFramework(TargetedFramework.JQUERY_MOBILE); // The
																	// framework
																	// to
																	// use
																	// if
																	// this
																	// device
																	// band
																	// matches
		aBand.setDeviceCategory(DeviceCategory.MOBILE);
		deviceBandRegistry.register(aBand);

		aBand = new DeviceBand("T");
		aBand.setResolutionInPixels(new int[] { -1, -1 });
		aBand.setBrowserFamily("ALL");
		aBand.setBrowserVersion("ALL");
		aBand.setOsVendor("ALL");
		aBand.setOsVersion("ALL");
		aBand.setOverridable(true);
		aBand.setTargetFramework(TargetedFramework.JQUERY_MOBILE); // The
																	// framework
																	// to
																	// use
																	// if
																	// this
																	// device
																	// band
																	// matches
		aBand.setDeviceCategory(DeviceCategory.TABLET);
		deviceBandRegistry.register(aBand);

		aBand = new DeviceBand("D");
		aBand.setResolutionInPixels(new int[] { -1, -1 });
		aBand.setBrowserFamily("ALL");
		aBand.setBrowserVersion("ALL");
		aBand.setOsVendor("ALL");
		aBand.setOsVersion("ALL");
		aBand.setOverridable(true);
		aBand.setTargetFramework(TargetedFramework.EXT_JS); // The framework
															// to use if
															// this device
															// band matches
		aBand.setDeviceCategory(DeviceCategory.DESKTOP_LAPTOP);
		deviceBandRegistry.register(aBand);

	}

	private static Logger LOGGER = Logger
			.getLogger(ModelHouseStartupListner.class);
}
